# تدريب الببغاء — Parrot Training

تطبيق Android أصلي (Kotlin + Jetpack Compose) لتدريب الببغاء على الكلام عبر خطة أسبوعية:
كل أسبوع له ملف صوتي واحد فقط، ويُشغَّل تلقائياً في أوقات محددة كل يوم — حتى لو كانت
الشاشة مقفلة أو التطبيق في الخلفية — باستخدام واجهات Android الرسمية فقط
(AlarmManager + Foreground Service)، بدون Root أو Shizuku أو WebView أو إنترنت.

An offline-first, native Android app (Kotlin + Jetpack Compose) that trains a parrot to
speak using a weekly plan: **one audio file per week**, played automatically at fixed
daily times — even with the screen locked or the app closed — using only official
Android background APIs (AlarmManager + a Foreground Service). No root, no Shizuku,
no WebView, no internet.

---

## 1. الفكرة الأساسية / Core idea

> **ONE WEEK = ONE AUDIO**

- الأسبوع 1 → الصوت 1 لكل جلسات ذلك الأسبوع.
- الأسبوع 2 → الصوت 2، وهكذا.
- لا يُخلط بين ملفين صوتيين داخل نفس الأسبوع إلا إذا غيّر المستخدم صوت الأسبوع يدوياً.

Week 1 always plays audio 1 for every session in that week; week 2 always plays audio 2;
and so on. Audio never changes mid-week unless the user manually reassigns that week's
audio from the **Plan** screen.

---

## 2. البنية / Architecture

```
app/src/main/java/com/parrottraining/app/
├── ParrotApp.kt                  # Application: creates channels, arms the first alarm
├── MainActivity.kt               # Compose host, bottom navigation, RTL
├── domain/                       # Pure Kotlin, no Android imports — fully unit-testable
│   ├── Models.kt                 # AudioItem, Settings, PlanState, SessionRecord...
│   ├── PlanEngine.kt             # Week math: current week, next session, skip/repeat...
│   ├── LogAnalyzer.kt            # Builds the per-week training log rows
│   ├── SessionGuard.kt           # Decides start / replace / reject when sessions collide
│   └── ListOps.kt                # Pure, testable list reordering (move up/down)
├── data/
│   ├── TrainingRepository.kt     # Single source of truth; safe from any process entry point
│   ├── AppStorage.kt             # SharedPreferences + JSON, no network, no account
│   ├── DataJson.kt               # (De)serialisation
│   ├── AudioUtils.kt             # Persistable URI permissions, duration, availability
│   └── BackupManager.kt          # Export / Import plan as JSON
├── scheduler/
│   └── TrainingScheduler.kt      # Keeps exactly ONE AlarmManager alarm armed
├── playback/
│   ├── TrainingPlaybackService.kt# Foreground service: loops audio for the session length
│   ├── NotificationHelper.kt     # Quiet notification channels + playback notification
│   └── PlaybackStateHolder.kt    # In-process bridge from the service to the UI
├── receivers/
│   ├── TrainingAlarmReceiver.kt  # Fires the due session, arms the next one
│   └── BootReceiver.kt           # BOOT_COMPLETED / TIME_SET / TIMEZONE_CHANGED
└── ui/                            # Jetpack Compose screens (Home, Plan, Voices, Log,
                                    # Settings, Readiness) + TrainingViewModel
```

**لماذا هذه البنية؟** كل منطق حساب الأسبوع/الجلسة موجود في `domain/PlanEngine.kt` وهو
كود Kotlin خالص بلا اعتماديات Android، لذلك يمكن اختباره مباشرة بوحدات اختبار JVM سريعة
(`app/src/test`) بدون محاكي. الجدولة تعتمد بالكامل على `AlarmManager` + `BroadcastReceiver`
+ `Foreground Service`، وليس على Timer/Coroutine داخل Activity — لذلك يستمر التدريب حتى
لو أُغلق التطبيق تماماً.

All week/session math lives in `domain/PlanEngine.kt`, pure Kotlin with zero Android
imports, so it's covered by fast JVM unit tests (`app/src/test`) with no emulator needed.
Scheduling relies entirely on `AlarmManager` + a `BroadcastReceiver` + a `Foreground
Service` — never an Activity-scoped Timer or coroutine — so training keeps working even
after the app is fully closed.

---

## 3. طريقة البناء / Building

### محلياً / Locally (Android Studio)
1. افتح المجلد في Android Studio (Jellyfish أو أحدث) واسمح له بمزامنة Gradle.
2. Build ▸ Build APK(s)، أو من الطرفية:
   ```bash
   ./gradlew :app:assembleDebug     # APK قابل للتثبيت فوراً للتجربة
   ./gradlew :app:assembleRelease   # APK للإصدار (بدون توقيع مخصص يُستخدم مفتاح debug)
   ```
   > ملاحظة: ملف `gradle/wrapper/gradle-wrapper.jar` الثنائي غير مُضمَّن في هذا التسليم
   > (تم توليد كل شيء آخر برمجياً بدون اتصال إنترنت). إن لم يكن لديك Gradle مثبتاً محلياً،
   > شغّل مرة واحدة: `gradle wrapper --gradle-version 8.9` لتوليده، أو افتح المشروع في
   > Android Studio الذي يتولى ذلك تلقائياً.

3. متطلبات: JDK 17، Android SDK مع `compileSdk 35`، `minSdk 26`.

### على Codemagic / On Codemagic
انظر القسم 8 أدناه — الملف `codemagic.yaml` جاهز بالكامل.

---

## 4. طريقة التشغيل / Running

1. ثبّت الـ APK وافتح التطبيق.
2. اذهب إلى شاشة **"الأصوات"** وأضف ملف MP3 أو WAV واحد على الأقل.
3. اذهب إلى شاشة **"الخطة"** واضغط **"بدء الخطة"** (أو من الشاشة الرئيسية).
4. من **"الإعدادات"** اضبط أوقات التدريب اليومية، مدة الجلسة، ومدة الأسبوع إذا رغبت.
5. تحقق من شاشة **"جاهزية التدريب"** للتأكد من تفعيل الإشعارات و Exact Alarm واستثناء
   التطبيق من تحسين البطارية.

---

## 5. طريقة إضافة الصوت / Adding audio

من شاشة **الأصوات**: اضغط **"إضافة صوت"** → اختر ملف MP3 أو WAV من مدير الملفات.
يحتفظ التطبيق بصلاحية دائمة للوصول للملف (`Persistable URI Permission`) بحيث يستمر
العمل بعد إعادة التشغيل. يمكنك معاينة الصوت، حذفه (مع تحذير إن كان مستخدَماً في الخطة
الحالية)، أو تغيير ترتيبه بالأسهم لأعلى/أسفل — والترتيب هو الذي يحدد أي أسبوع يستخدم
أي صوت.

From the **Voices** screen: tap **Add audio** → pick an MP3/WAV file. The app keeps a
persistable read permission so it keeps working after reboot. You can preview, delete
(with a warning if it's used in the current plan), or reorder audios — their order
determines which week uses which audio.

---

## 6. طريقة إنشاء الخطة / Creating the plan

الخطة تُبنى تلقائياً من ترتيب الأصوات: الصوت رقم 1 للأسبوع 1، رقم 2 للأسبوع 2... من
شاشة **الخطة** يمكنك: تغيير صوت أي أسبوع يدوياً، وتغيير تاريخ بداية الخطة. من الشاشة
الرئيسية يمكنك: تخطي الأسبوع الحالي، إعادة الأسبوع الحالي، إيقاف/استئناف الخطة مؤقتاً.

The plan is built automatically from the audio order (audio #1 → week 1, #2 → week 2...).
From **Plan** you can override any week's audio and change the plan's start date. From
**Home** you can skip the current week, repeat it, or pause/resume the whole plan.

---

## 7. الصلاحيات المطلوبة / Required permissions

| الصلاحية | الغرض |
|---|---|
| `POST_NOTIFICATIONS` | إظهار إشعار الجلسة أثناء التشغيل في الخلفية (Android 13+) |
| `FOREGROUND_SERVICE` / `FOREGROUND_SERVICE_MEDIA_PLAYBACK` | تشغيل الصوت في خدمة أمامية موثوقة |
| `RECEIVE_BOOT_COMPLETED` | إعادة جدولة الجلسة القادمة بعد إعادة تشغيل الهاتف |
| `WAKE_LOCK` | إبقاء المعالج يقظاً أثناء تشغيل الجلسة |
| `SCHEDULE_EXACT_ALARM` | تشغيل الجلسات في وقتها المحدد بدقة |

لا يطلب التطبيق أي صلاحية غير مرتبطة بوظيفته (لا وصول لجهات الاتصال، لا كاميرا، لا موقع).

No permission unrelated to this functionality is requested (no contacts, camera, or
location access).

---

## 8. قيود البطارية والخلفية / Battery & background limits

Android يفرض قيوداً رسمية على العمل في الخلفية (Doze Mode، App Standby، وقيود خاصة
ببعض الشركات المصنعة مثل ASUS/Xiaomi/Huawei). هذا التطبيق:
- يستخدم `setExactAndAllowWhileIdle` عندما يكون Exact Alarm متاحاً، ويتراجع تلقائياً
  إلى تنبيه غير دقيق (قد يتأخر قليلاً) إن لم يكن متاحاً — بدون أي حيلة غير رسمية.
- يوفر شاشة **"جاهزية التدريب"** تكشف عدم توفر Exact Alarm أو تفعيل تحسين البطارية،
  مع زر مباشر لفتح الإعدادات الصحيحة.
- **لا يضمن** عمل الجدولة 100% على كل الأجهزة إن فرضت الشركة المصنعة قيوداً إضافية
  خاصة بها خارج نطاق Android القياسي — هذا قيد حقيقي في نظام Android وليس خطأً في التطبيق.

Android enforces real background limits (Doze, App Standby, and OEM-specific battery
managers on some brands). This app uses `setExactAndAllowWhileIdle` when allowed and
falls back to an inexact alarm otherwise — no unofficial workaround. The **Readiness**
screen surfaces missing permissions with a direct link to the right Settings screen, but
cannot guarantee 100% background reliability on every device if the manufacturer adds
its own restrictions beyond stock Android.

---

## 9. كيفية اختبار التطبيق / Testing

- **اختبار سريع للصوت (تطبيق):** من الشاشة الرئيسية أو الإعدادات، زر **"اختبار جلسة
  (دقيقة واحدة)"** يشغّل صوت الأسبوع الحالي لمدة دقيقة فقط، دون التأثير على الخطة أو السجل.
- **اختبار صوت فردي:** من شاشة الأصوات، زر التشغيل ▶ بجانب كل ملف يعاين الصوت لثوانٍ قليلة.
- **اختبارات الوحدة (JVM):**
  ```bash
  ./gradlew :app:testDebugUnitTest
  ```
  تغطي: حساب الأسبوع الحالي، الانتقال بين الأسابيع، حساب الجلسة القادمة، تخطي/إعادة
  الأسبوع، إيقاف/استئناف الخطة، منع تداخل الجلسات، انتهاء الخطة، إعادة البرنامج تلقائياً،
  وترتيب الأصوات (`app/src/test/java/com/parrottraining/app/`).

- **In-app quick test:** the **"Test session (1 minute)"** button plays the current
  week's audio for one minute without touching the plan or the log.
- **Single-file preview:** the ▶ button next to each audio in **Voices** previews it
  briefly.
- **Unit tests:** `./gradlew :app:testDebugUnitTest` — covers current-week calculation,
  week transitions, next-session calculation, skip/repeat week, pause/resume, session
  overlap prevention, plan completion, auto-repeat, and audio reordering.

---

## 10. إعداد Codemagic / Codemagic setup

الملف `codemagic.yaml` في جذر المشروع يعرّف Workflow باسم **`android-release`**:

1. **يولّد `gradle-wrapper.jar`** أولاً عبر Gradle العام المتوفر على صور Codemagic
   (هذا الملف الثنائي غير مُضمَّن في المستودع عمداً — لم يكن بالإمكان تنزيله في بيئة
   بدون إنترنت أثناء إنشاء هذا المشروع).
2. يبني **Release APK** في `app/build/outputs/apk/release/app-release.apk`.
   - إن أضفت مجموعة `keystore_credentials` (متغيرات `CM_KEYSTORE`, `CM_KEYSTORE_PASSWORD`,
     `CM_KEY_ALIAS`, `CM_KEY_PASSWORD`) وربطتها في `android_signing`، يُوقَّع APK بمفتاحك.
   - بدون ذلك، يستخدم البناء مفتاح Debug تلقائياً فيبقى APK قابلاً للتثبيت والتجربة فوراً.
3. يبني أيضاً **Debug APK** كنسخة احتياطية دائماً قابلة للتثبيت.
4. يشغّل اختبارات الوحدة.
5. يرفع كل ملفات الـ APK كـ Artifacts.

The `codemagic.yaml` workflow **`android-release`**:
1. Regenerates `gradle-wrapper.jar` using Codemagic's globally installed Gradle (this
   binary file is intentionally not committed — it could not be downloaded in the
   network-restricted environment this project was generated in).
2. Builds a **release APK**. With a `keystore_credentials` variable group configured in
   `android_signing`, it's properly signed; without one, it falls back to the debug key
   so the APK always stays installable.
3. Also builds a plain **debug APK** as a guaranteed-installable fallback.
4. Runs unit tests.
5. Uploads all APKs as build artifacts.

---

## 11. ملاحظات أخيرة / Final notes

- لا تسجيل دخول، لا خادم، لا Firebase، لا اشتراك مدفوع — كل شيء محلي على الجهاز.
- عند نقل نسخة احتياطية (`Export`) إلى هاتف آخر، لن تعمل روابط ملفات الصوت (URI) تلقائياً؛
  سيطلب منك التطبيق إعادة اختيار كل ملف يدوياً بعد الاستيراد.
- الحد الأقصى الفعلي لعدد "التنبيهات" المجدولة في وقت واحد هو **واحد فقط** — الجلسة
  القادمة التالية دائماً، ما يحافظ على الأداء وعمر البطارية.

No login, no server, no Firebase, no paid subscription — everything is on-device. When
importing a backup on a different phone, audio file links (URIs) won't resolve
automatically; you'll be asked to re-pick each file. At any moment, only **one** alarm
is ever scheduled — the next due session — which keeps this lightweight and
battery-friendly.

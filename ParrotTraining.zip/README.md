# تدريب الببغاء — Parrot Training

تطبيق Android أصلي (Kotlin + Jetpack Compose) لتدريب الببغاء على الكلام عبر خطة أسبوعية:
كل أسبوع له ملف صوتي واحد فقط، ويُشغَّل تلقائياً في أوقات محددة كل يوم — حتى لو كانت
الشاشة مقفلة أو التطبيق في الخلفية — باستخدام واجهات Android الرسمية فقط
(AlarmManager + Foreground Service)، بدون Root أو Shizuku أو WebView أو إنترنت.

An offline-first, native Android app (Kotlin + Jetpack Compose) that trains a parrot to
speak using a weekly plan: **one audio file per week**, played automatically at fixed
daily times — even with the screen locked or the app closed — using only official
Android background APIs (AlarmManager + a Foreground Service). No root, no Shizuku,
no WebView, no internet.

---

## 1. الفكرة الأساسية / Core idea

> **ONE WEEK = ONE AUDIO (+ optional extra audios)**

من شاشة **الخطة** يمكنك إضافة أصوات إضافية لأي أسبوع (A ثم B ثم C): كل جلسة في ذلك الأسبوع تشغّل الأصوات بالتناوب حتى انتهاء مدة الجلسة.
From **Plan** you can add extra audios to any week (A, B, C): every session of that week cycles through them until the session time ends.

- الأسبوع 1 → الصوت 1 لكل جلسات ذلك الأسبوع.
- الأسبوع 2 → الصوت 2، وهكذا.
- لا يُخلط بين ملفين صوتيين داخل نفس الأسبوع إلا إذا غيّر المستخدم صوت الأسبوع يدوياً.

Week 1 always plays audio 1 for every session in that week; week 2 always plays audio 2;
and so on. Audio never changes mid-week unless the user manually reassigns that week's
audio from the **Plan** screen.

من **الإعدادات ▸ أوقات التدريب اليومية** تقدر تحدد مدة مستقلة لكل وقت (مثلاً الصباح 10 دقائق والظهر 5 دقائق).
In **Settings ▸ daily times** each time can have its own session length (e.g. morning 10 min, noon 5 min).

**فيديو (جدول مستقل):** أضف الفيديوهات من شاشة الأصوات (قسم 🎬 الفيديوهات). اختر فيديو كل أسبوع من شاشة الخطة (🎬 فيديو الأسبوع). من الإعدادات ▸ جدول الفيديو حدد أوقات الفيديو وأيام التشغيل (مثلاً 5 أيام فقط). وقت الفيديو تفتح شاشة بالطول (عمودية) فوق القفل، مناسبة لفيديوهات تيك توك وإنستغرام ويشتغل كل فيديو مرة واحدة بالترتيب حتى ينتهي، وتنتهي الجلسة بنهاية آخر فيديو (مدتها مجموع مدد الفيديوهات). لو تعذر فتح الشاشة يشتغل الصوت فقط. تأكد من الصلاحيات في شاشة الجاهزية.
**Video (own schedule):** add videos in the Voices screen, pick each week's video in Plan, then set video times and active days in Settings ▸ Video schedule. At those times a portrait (vertical) screen opens over the lock screen, made for TikTok / Instagram style videos; each video plays once, in order, and the session ends with the last one (its length is the sum of the videos); if the screen can't open only the sound plays. Check Readiness for permissions.

**تصوير الجلسات:** من الإعدادات ▸ تصوير الجلسات بالكاميرا الأمامية. مع كل جلسة (صوت أو فيديو) تسجّل الكاميرا الأمامية فيديو صامت في الخلفية بدون واجهة، ويُحفظ في الاستوديو ▸ ParrotTraining ويُحذف تلقائياً بعد 7 أيام. يحتاج إذن الكاميرا، وتظهر نقطة الكاميرا الخضراء من النظام.
**Session recording:** Settings ▸ Front-camera recording. Each session records a silent front-camera video in the background (no preview), saved to Gallery ▸ ParrotTraining and deleted after 7 days. Needs the camera permission; the system's green camera dot is shown.
**نشاط الببغاء:** أثناء التصوير يقيس التطبيق حركة الصورة (4 لقطات في الثانية) ويحفظ نسبة "النشاط" لكل جلسة، ويعرض متوسطها لكل أسبوع في شاشة السجل. إذا ما دعم الجوال هذا المسار الإضافي يستمر التصوير عادي بدون نسبة. الحركة العامة في الصورة (إنسان يمر، تغيّر إضاءة) قد ترفع النسبة قليلاً، فالأفضل تثبيت الجوال على حامل مواجه للقفص.
**Parrot activity:** while recording, the app measures picture movement (4 frames/s) and stores an "activity" percentage per session; the Log screen shows each week's average. If the phone cannot run the extra stream, recording continues without a score. Other movement in view (a person walking by, lighting changes) can raise the number a little, so mount the phone facing the cage.
**ملف الببغاء وأفضل وقت:** من الإعدادات ▸ ملف الببغاء تضيف اسمه وصورته، ويظهران في الشاشة الرئيسية مع رقم يوم التدريب، ويُحفظان داخل ملف تصدير الخطة. في السجل بطاقة "أفضل وقت للتدريب" تقارن أوقات الجلسات بنشاط الكاميرا، وإذا ما فيه تصوير تقارن بملاحظات التفاعل، ولا تعطي توصية إلا بعد 3 جلسات على الأقل لكل وقت.
**Parrot profile & best time:** Settings ▸ Parrot profile stores a name and photo (shown on Home with the training day, and kept in the plan export). The Log screen compares the daily times by camera activity, or by your reaction notes when there is no camera data, and only recommends a time after at least 3 sessions per slot.
**خفيف على الأجهزة:** نسخة الـ Release تُصغَّر بـ R8 (حذف الكود والأيقونات والموارد غير المستخدمة) وتحتفظ بالعربي والإنجليزي فقط من نصوص المكتبات. الشاشات لا تعيد حساب السجل كل ثانية، والتحليل بالكاميرا بدقة صغيرة وبـ 4 لقطات في الثانية فقط.
**Light on every phone:** the release build is shrunk with R8 (unused code, icons and resources removed) and keeps only Arabic and English library strings. Screens no longer recompute the log every second, and camera analysis runs at a small size and 4 frames/s.

**زاوية واسعة:** تصوير الجلسات يختار أوسع عدسة أمامية في الجوال، ويبعد التكبير تماماً ويوقف تثبيت الصورة (لأنه يقص الأطراف) ويحافظ على شكل مستشعر الكاميرا، ليظهر القفص كاملاً. لو العدسة نفسها ضيقة فابعد الجوال عن القفص.
**Wide view:** session recording uses the widest front lens, zooms fully out, turns off stabilization (it crops) and keeps the sensor's own shape so the whole cage is visible. If the lens itself is narrow, move the phone farther from the cage.
**نسخة كاملة:** الإعدادات ▸ النسخ الاحتياطي ▸ نسخة كاملة تحفظ الخطة مع كل ملفات الصوت والفيديو في ملف zip، وعند الاستيراد تُنسخ الملفات داخل التطبيق فلا تحتاج لإعادة إضافتها. تصدير الخطة فقط (JSON) ما زال متاحاً، والاستيراد يقبل النوعين.
**Full backup:** Settings ▸ Backup ▸ Full backup saves the plan with every audio and video file in one zip; importing copies the files inside the app so nothing has to be added again. Plan-only JSON export still exists and import accepts both.
**إشعار للآيفون:** الإعدادات ▸ إشعار على جوال آخر. عند بدء كل جلسة (واختيارياً عند انتهائها أو حدوث مشكلة) يرسل التطبيق رسالة صغيرة إلى خادم ntfy (مفتوح المصدر، ntfy.sh افتراضياً) ويصلك إشعار على تطبيق ntfy المجاني في الآيفون. اسم الموضوع يُولَّد عشوائياً ويعمل مثل كلمة السر. هذه الميزة الوحيدة في التطبيق التي تستخدم الإنترنت، وتعمل فقط إذا فعّلتها.
**Push to your iPhone:** Settings ▸ Notification to another phone. When a session starts (optionally when it ends or hits a problem) the app posts a small message to an ntfy server (open source, ntfy.sh by default) and the free ntfy iPhone app shows it. The topic name is random and acts like a password. This is the only feature that uses the internet, and only if you turn it on.

**تشغيل الكاميرا مع الجلسات التلقائية:** أندرويد يمنع تشغيل الكاميرا والتطبيق غير ظاهر، فعند بدء جلسة بالمنبّه تفتح شاشة شفافة صغيرة (للصوت) أو شاشة الفيديو (للفيديو)، تشغّل الجوال وتبدأ التسجيل، ثم تُغلق الشاشة الشفافة وبقي التسجيل شغّالاً. التصوير بالكاميرا الأمامية فقط ولا يرجع للخلفية أبداً. يحتاج صلاحية "فتح الشاشة فوق القفل" في شاشة الجاهزية.
**Camera for automatic sessions:** Android blocks the camera while the app is out of sight, so when a session starts by alarm a small see-through screen (audio) or the video screen (video) wakes the phone and starts the recording, then the see-through screen closes while recording continues. Front camera only, never the rear. Needs the full-screen permission in Readiness.

**التثبيت والتحديث:** كل النسخ (debug و release) تُوقَّع الآن بمفتاح ثابت واحد داخل المشروع (signing/parrot-release.jks)، وكل بناء على Codemagic يأخذ رقم نسخة أعلى، فيُثبَّت فوق القديم بدون حذف. أول مرة فقط يجب حذف النسخة القديمة (لأنها موقّعة بمفتاح عشوائي)، فاعمل تصدير للخطة قبلها. لا تحذف مجلد signing ولا تغيّر المفتاح لاحقاً وإلا رجعت المشكلة. إذا كان مستودع GitHub عاماً فالمفتاح ظاهر للجميع، فاجعله خاصاً.
**Installing and updating:** every APK (debug and release) is now signed with ONE fixed key kept in the project (signing/parrot-release.jks) and each Codemagic build gets a higher version number, so a new build installs over the old one. Only the first time the old install must be removed (it was signed with a random key), so export the plan first. Keep the signing folder and never change the key, or the problem returns. If the GitHub repo is public the key is public too, so keep it private.

---

## 2. البنية / Architecture

```
app/src/main/java/com/parrottraining/app/
├── ParrotApp.kt                  # Application: creates channels, arms the first alarm
├── MainActivity.kt               # Compose host, bottom navigation, RTL
├── domain/                       # Pure Kotlin, no Android imports — fully unit-testable
│   ├── MotionAnalyzer.kt         # movement score from camera frames
│   ├── Models.kt                 # AudioItem, Settings, PlanState, SessionRecord...
│   ├── PlanEngine.kt             # Week math: current week, next session, skip/repeat...
│   ├── LogAnalyzer.kt            # Builds the per-week training log rows
│   ├── SessionGuard.kt           # Decides start / replace / reject when sessions collide
│   └── ListOps.kt                # Pure, testable list reordering (move up/down)
├── data/
│   ├── TrainingRepository.kt     # Single source of truth; safe from any process entry point
│   ├── AppStorage.kt             # SharedPreferences + JSON, no network, no account
│   ├── DataJson.kt               # (De)serialisation
│   ├── AudioUtils.kt             # Persistable URI permissions, duration, availability
│   └── BackupManager.kt          # Export / Import plan as JSON
├── scheduler/
│   └── TrainingScheduler.kt      # Keeps exactly ONE AlarmManager alarm armed
├── playback/
│   ├── TrainingPlaybackService.kt# Foreground service: loops audio for the session length
│   ├── NotificationHelper.kt     # Quiet notification channels + playback notification
│   └── PlaybackStateHolder.kt    # In-process bridge from the service to the UI
├── receivers/
│   ├── TrainingAlarmReceiver.kt  # Fires the due session, arms the next one
│   └── BootReceiver.kt           # BOOT_COMPLETED / TIME_SET / TIMEZONE_CHANGED
└── ui/                            # Jetpack Compose screens (Home, Plan, Voices, Log,
                                    # Settings, Readiness) + TrainingViewModel
```

**لماذا هذه البنية؟** كل منطق حساب الأسبوع/الجلسة موجود في `domain/PlanEngine.kt` وهو
كود Kotlin خالص بلا اعتماديات Android، لذلك يمكن اختباره مباشرة بوحدات اختبار JVM سريعة
(`app/src/test`) بدون محاكي. الجدولة تعتمد بالكامل على `AlarmManager` + `BroadcastReceiver`
+ `Foreground Service`، وليس على Timer/Coroutine داخل Activity — لذلك يستمر التدريب حتى
لو أُغلق التطبيق تماماً.

All week/session math lives in `domain/PlanEngine.kt`, pure Kotlin with zero Android
imports, so it's covered by fast JVM unit tests (`app/src/test`) with no emulator needed.
Scheduling relies entirely on `AlarmManager` + a `BroadcastReceiver` + a `Foreground
Service` — never an Activity-scoped Timer or coroutine — so training keeps working even
after the app is fully closed.

---

## 3. طريقة البناء / Building

### محلياً / Locally (Android Studio)
1. افتح المجلد في Android Studio (Jellyfish أو أحدث) واسمح له بمزامنة Gradle.
2. Build ▸ Build APK(s)، أو من الطرفية:
   ```bash
   ./gradlew :app:assembleDebug     # APK قابل للتثبيت فوراً للتجربة
   ./gradlew :app:assembleRelease   # APK للإصدار (بدون توقيع مخصص يُستخدم مفتاح debug)
   ```
   > ملاحظة: ملف `gradle/wrapper/gradle-wrapper.jar` الثنائي غير مُضمَّن في هذا التسليم
   > (تم توليد كل شيء آخر برمجياً بدون اتصال إنترنت). إن لم يكن لديك Gradle مثبتاً محلياً،
   > شغّل مرة واحدة: `gradle wrapper --gradle-version 8.9` لتوليده، أو افتح المشروع في
   > Android Studio الذي يتولى ذلك تلقائياً.

3. متطلبات: JDK 17، Android SDK مع `compileSdk 35`، `minSdk 26`.

### على Codemagic / On Codemagic
انظر القسم 8 أدناه — الملف `codemagic.yaml` جاهز بالكامل.

---

## 4. طريقة التشغيل / Running

1. ثبّت الـ APK وافتح التطبيق.
2. اذهب إلى شاشة **"الأصوات"** وأضف ملف MP3 أو WAV واحد على الأقل.
3. اذهب إلى شاشة **"الخطة"** واضغط **"بدء الخطة"** (أو من الشاشة الرئيسية).
4. من **"الإعدادات"** اضبط أوقات التدريب اليومية، مدة الجلسة، ومدة الأسبوع إذا رغبت.
5. تحقق من شاشة **"جاهزية التدريب"** للتأكد من تفعيل الإشعارات و Exact Alarm واستثناء
   التطبيق من تحسين البطارية.

---

## 5. طريقة إضافة الصوت / Adding audio

من شاشة **الأصوات**: اضغط **"إضافة صوت"** → اختر ملف MP3 أو WAV من مدير الملفات.
يحتفظ التطبيق بصلاحية دائمة للوصول للملف (`Persistable URI Permission`) بحيث يستمر
العمل بعد إعادة التشغيل. يمكنك معاينة الصوت، حذفه (مع تحذير إن كان مستخدَماً في الخطة
الحالية)، أو تغيير ترتيبه بالأسهم لأعلى/أسفل — والترتيب هو الذي يحدد أي أسبوع يستخدم
أي صوت.

From the **Voices** screen: tap **Add audio** → pick an MP3/WAV file. The app keeps a
persistable read permission so it keeps working after reboot. You can preview, delete
(with a warning if it's used in the current plan), or reorder audios — their order
determines which week uses which audio.

---

## 6. طريقة إنشاء الخطة / Creating the plan

الخطة تُبنى تلقائياً من ترتيب الأصوات: الصوت رقم 1 للأسبوع 1، رقم 2 للأسبوع 2... من
شاشة **الخطة** يمكنك: تغيير صوت أي أسبوع يدوياً، وتغيير تاريخ بداية الخطة. من الشاشة
الرئيسية يمكنك: تخطي الأسبوع الحالي، إعادة الأسبوع الحالي، إيقاف/استئناف الخطة مؤقتاً.

The plan is built automatically from the audio order (audio #1 → week 1, #2 → week 2...).
From **Plan** you can override any week's audio and change the plan's start date. From
**Home** you can skip the current week, repeat it, or pause/resume the whole plan.

---

## 7. الصلاحيات المطلوبة / Required permissions

| الصلاحية | الغرض |
|---|---|
| `POST_NOTIFICATIONS` | إظهار إشعار الجلسة أثناء التشغيل في الخلفية (Android 13+) |
| `FOREGROUND_SERVICE` / `FOREGROUND_SERVICE_MEDIA_PLAYBACK` | تشغيل الصوت في خدمة أمامية موثوقة |
| `RECEIVE_BOOT_COMPLETED` | إعادة جدولة الجلسة القادمة بعد إعادة تشغيل الهاتف |
| `WAKE_LOCK` | إبقاء المعالج يقظاً أثناء تشغيل الجلسة |
| `SCHEDULE_EXACT_ALARM` | تشغيل الجلسات في وقتها المحدد بدقة |
| `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` | فتح نافذة "السماح بالعمل في الخلفية" من شاشة الجاهزية |
| `VIBRATE` | اهتزاز قصير عند بداية الجلسة (اختياري) |
| `USE_FULL_SCREEN_INTENT` / `SYSTEM_ALERT_WINDOW` | فتح شاشة الفيديو وقت الجلسة فوق القفل والتطبيقات الأخرى |
| `CAMERA` / `FOREGROUND_SERVICE_CAMERA` | تصوير الجلسات بالكاميرا الأمامية (اختياري، من الإعدادات) |

لا يطلب التطبيق أي صلاحية لجهات الاتصال أو الموقع. الكاميرا لا تُستخدم إلا إذا فعّلت تصوير الجلسات.

No contacts or location access is requested. The camera is used only if you turn on session recording. The app follows the phone's rotation lock everywhere except the video screen, which is always portrait.

---

## 8. قيود البطارية والخلفية / Battery & background limits

Android يفرض قيوداً رسمية على العمل في الخلفية (Doze Mode، App Standby، وقيود خاصة
ببعض الشركات المصنعة مثل ASUS/Xiaomi/Huawei). هذا التطبيق:
- يستخدم `setExactAndAllowWhileIdle` عندما يكون Exact Alarm متاحاً، ويتراجع تلقائياً
  إلى تنبيه غير دقيق (قد يتأخر قليلاً) إن لم يكن متاحاً — بدون أي حيلة غير رسمية.
- يوفر شاشة **"جاهزية التدريب"** تكشف عدم توفر Exact Alarm أو تفعيل تحسين البطارية،
  مع زر مباشر لفتح الإعدادات الصحيحة.
- **لا يضمن** عمل الجدولة 100% على كل الأجهزة إن فرضت الشركة المصنعة قيوداً إضافية
  خاصة بها خارج نطاق Android القياسي — هذا قيد حقيقي في نظام Android وليس خطأً في التطبيق.

Android enforces real background limits (Doze, App Standby, and OEM-specific battery
managers on some brands). This app uses `setExactAndAllowWhileIdle` when allowed and
falls back to an inexact alarm otherwise — no unofficial workaround. The **Readiness**
screen surfaces missing permissions with a direct link to the right Settings screen, but
cannot guarantee 100% background reliability on every device if the manufacturer adds
its own restrictions beyond stock Android.

---

## 9. كيفية اختبار التطبيق / Testing

- **اختبار سريع للصوت (تطبيق):** من الشاشة الرئيسية أو الإعدادات، زر **"اختبار جلسة
  (دقيقة واحدة)"** يشغّل صوت الأسبوع الحالي لمدة دقيقة فقط، دون التأثير على الخطة أو السجل.
- **اختبار صوت فردي:** من شاشة الأصوات، زر التشغيل ▶ بجانب كل ملف يعاين الصوت لثوانٍ قليلة.
- **اختبارات الوحدة (JVM):**
  ```bash
  ./gradlew :app:testDebugUnitTest
  ```
  تغطي: حساب الأسبوع الحالي، الانتقال بين الأسابيع، حساب الجلسة القادمة، تخطي/إعادة
  الأسبوع، إيقاف/استئناف الخطة، منع تداخل الجلسات، انتهاء الخطة، إعادة البرنامج تلقائياً،
  وترتيب الأصوات (`app/src/test/java/com/parrottraining/app/`).

- **In-app quick test:** the **"Test session (1 minute)"** button plays the current
  week's audio for one minute without touching the plan or the log.
- **Single-file preview:** the ▶ button next to each audio in **Voices** previews it
  briefly.
- **Unit tests:** `./gradlew :app:testDebugUnitTest` — covers current-week calculation,
  week transitions, next-session calculation, skip/repeat week, pause/resume, session
  overlap prevention, plan completion, auto-repeat, and audio reordering.

---

## 10. إعداد Codemagic / Codemagic setup

الملف `codemagic.yaml` في جذر المشروع يعرّف Workflow باسم **`android-release`**:

1. **يولّد `gradle-wrapper.jar`** أولاً عبر Gradle العام المتوفر على صور Codemagic
   (هذا الملف الثنائي غير مُضمَّن في المستودع عمداً — لم يكن بالإمكان تنزيله في بيئة
   بدون إنترنت أثناء إنشاء هذا المشروع).
2. يبني **Release APK** في `app/build/outputs/apk/release/app-release.apk`.
   - إن أضفت مجموعة `keystore_credentials` (متغيرات `CM_KEYSTORE`, `CM_KEYSTORE_PASSWORD`,
     `CM_KEY_ALIAS`, `CM_KEY_PASSWORD`) وربطتها في `android_signing`، يُوقَّع APK بمفتاحك.
   - بدون ذلك، يستخدم البناء مفتاح Debug تلقائياً فيبقى APK قابلاً للتثبيت والتجربة فوراً.
3. يبني أيضاً **Debug APK** كنسخة احتياطية دائماً قابلة للتثبيت.
4. يشغّل اختبارات الوحدة.
5. يرفع كل ملفات الـ APK كـ Artifacts.

The `codemagic.yaml` workflow **`android-release`**:
1. Regenerates `gradle-wrapper.jar` using Codemagic's globally installed Gradle (this
   binary file is intentionally not committed — it could not be downloaded in the
   network-restricted environment this project was generated in).
2. Builds a **release APK**. With a `keystore_credentials` variable group configured in
   `android_signing`, it's properly signed; without one, it falls back to the debug key
   so the APK always stays installable.
3. Also builds a plain **debug APK** as a guaranteed-installable fallback.
4. Runs unit tests.
5. Uploads all APKs as build artifacts.

---

## 11. ملاحظات أخيرة / Final notes

- لا تسجيل دخول، لا خادم، لا Firebase، لا اشتراك مدفوع — كل شيء محلي على الجهاز.
- عند نقل نسخة احتياطية (`Export`) إلى هاتف آخر، لن تعمل روابط ملفات الصوت (URI) تلقائياً؛
  سيطلب منك التطبيق إعادة اختيار كل ملف يدوياً بعد الاستيراد.
- الحد الأقصى الفعلي لعدد "التنبيهات" المجدولة في وقت واحد هو **واحد فقط** — الجلسة
  القادمة التالية دائماً، ما يحافظ على الأداء وعمر البطارية.

No login, no server, no Firebase, no paid subscription — everything is on-device. When
importing a backup on a different phone, audio file links (URIs) won't resolve
automatically; you'll be asked to re-pick each file. At any moment, only **one** alarm
is ever scheduled — the next due session — which keeps this lightweight and
battery-friendly.

import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.parrottraining.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.parrottraining.app"
        minSdk = 26
        targetSdk = 35
        // Codemagic gives every build a higher number, so each new build installs over the previous one.
        versionCode = maxOf(2, System.getenv("BUILD_NUMBER")?.toIntOrNull() ?: 2)
        versionName = "1.0.0"
    }

    // ONE fixed signing key for every build (debug and release). Android only lets a new build replace an installed
    // one if both are signed with the same key. Before, each Codemagic build used a fresh random debug key, so a new
    // build could not be installed over the old one ("package conflict" / no install screen).
    // A key uploaded to Codemagic (CM_KEYSTORE_* variables) is used instead when all four variables exist.
    signingConfigs {
        create("parrot") {
            val envPath = System.getenv("CM_KEYSTORE_PATH")
            val envReady = !envPath.isNullOrBlank() && file(envPath).exists() &&
                !System.getenv("CM_KEYSTORE_PASSWORD").isNullOrBlank() &&
                !System.getenv("CM_KEY_ALIAS").isNullOrBlank() &&
                !System.getenv("CM_KEY_PASSWORD").isNullOrBlank()
            if (envReady) {
                storeFile = file(envPath!!)
                storePassword = System.getenv("CM_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("CM_KEY_ALIAS")
                keyPassword = System.getenv("CM_KEY_PASSWORD")
            } else {
                storeFile = rootProject.file("signing/parrot-release.jks")
                storePassword = "parrot-training-2026"
                keyAlias = "parrot"
                keyPassword = "parrot-training-2026"
            }
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("parrot")
        }
        release {
            // Smaller and lighter APK: unused code, unused icons and unused resources are removed.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("parrot")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
    }

    // The app's own texts are Arabic; keep only Arabic and English strings from the libraries.
    androidResources {
        localeFilters += listOf("ar", "en")
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
        freeCompilerArgs.add("-opt-in=androidx.compose.material3.ExperimentalMaterial3Api")
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.04.01")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.5")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    debugImplementation("androidx.compose.ui:ui-tooling")

    testImplementation("junit:junit:4.13.2")
}

# Minification is disabled for this project; rules are kept here for future use.

# Release builds are shrunk with R8. The app reads and writes its data with org.json by hand (no reflection),
# and services/receivers/activities are kept automatically from the manifest, so only a few rules are needed.

# Readable crash reports (line numbers) if something ever goes wrong on a phone.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Enums are saved by name and read back with valueOf (session status, reactions, settings).
-keepclassmembers enum com.parrottraining.app.** {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

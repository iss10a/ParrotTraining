package com.parrottraining.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.parrottraining.app.data.TrainingRepository
import com.parrottraining.app.scheduler.TrainingScheduler
import com.parrottraining.app.ui.TrainingViewModel
import com.parrottraining.app.ui.log.LogScreen
import com.parrottraining.app.ui.home.HomeScreen
import com.parrottraining.app.ui.nav.Destination
import com.parrottraining.app.ui.nav.bottomBarDestinations
import com.parrottraining.app.ui.plan.PlanScreen
import com.parrottraining.app.ui.readiness.ReadinessScreen
import com.parrottraining.app.ui.settings.SettingsScreen
import com.parrottraining.app.ui.theme.ParrotTrainingTheme
import com.parrottraining.app.ui.voices.VoicesScreen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* handled by ReadinessScreen */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ask for notification permission once, up front (Android 13+). Declining does not
        // stop training: it only means the foreground notification may be less visible.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            ParrotTrainingTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(color = MaterialTheme.colorScheme.background) {
                        ParrotTrainingApp()
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Cheap safety net: whenever the user opens the app, re-check the schedule.
        TrainingRepository.get(this).refresh()
        TrainingScheduler(this).reschedule()
    }
}

@Composable
fun ParrotTrainingApp(viewModel: TrainingViewModel = viewModel()) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScopeCompat()

    LaunchedEffect(Unit) {
        viewModel.messages.collect { msg ->
            scope.launch { snackbarHostState.showSnackbar(msg) }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = { AppBottomBar(navController) }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Destination.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Destination.Home.route) {
                HomeScreen(viewModel, onOpenReadiness = { navController.navigate(Destination.Readiness.route) })
            }
            composable(Destination.Plan.route) { PlanScreen(viewModel) }
            composable(Destination.Voices.route) { VoicesScreen(viewModel) }
            composable(Destination.Log.route) { LogScreen(viewModel) }
            composable(Destination.Settings.route) {
                SettingsScreen(viewModel, onOpenReadiness = { navController.navigate(Destination.Readiness.route) })
            }
            composable(Destination.Readiness.route) { ReadinessScreen(viewModel) }
        }
    }
}

@Composable
private fun AppBottomBar(navController: NavHostController) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    NavigationBar {
        bottomBarDestinations.forEach { dest ->
            NavigationBarItem(
                selected = currentRoute == dest.route,
                onClick = {
                    if (currentRoute != dest.route) {
                        navController.navigate(dest.route) {
                            popUpTo(Destination.Home.route)
                            launchSingleTop = true
                        }
                    }
                },
                icon = { androidx.compose.material3.Icon(dest.icon, contentDescription = dest.label) },
                label = { Text(dest.label) }
            )
        }
    }
}

@Composable
private fun rememberCoroutineScopeCompat() = androidx.compose.runtime.rememberCoroutineScope()

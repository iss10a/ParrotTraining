package com.parrottraining.app

import android.app.Application
import com.parrottraining.app.data.TrainingRepository
import com.parrottraining.app.playback.NotificationHelper
import com.parrottraining.app.scheduler.TrainingScheduler

/**
 * App entry point. Creates the notification channels and makes sure the next training
 * session is armed as soon as the process starts for any reason (launcher, boot receiver,
 * alarm receiver, foreground service).
 */
class ParrotApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationHelper.ensureChannels(this)
        TrainingRepository.get(this).refresh()
        TrainingScheduler(this).reschedule()
    }
}

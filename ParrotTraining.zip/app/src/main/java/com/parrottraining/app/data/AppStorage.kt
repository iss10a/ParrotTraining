package com.parrottraining.app.data

import android.content.Context
import com.parrottraining.app.domain.AppData
import com.parrottraining.app.domain.SessionRecord
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/** Local-only persistence (SharedPreferences + JSON). No network, no account. */
class AppStorage(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("parrot_training", Context.MODE_PRIVATE)

    fun loadData(): AppData {
        val text = prefs.getString(KEY_DATA, null) ?: return AppData()
        return try {
            DataJson.dataFromJson(JSONObject(text))
        } catch (e: Exception) {
            AppData()
        }
    }

    fun saveData(d: AppData) {
        prefs.edit().putString(KEY_DATA, DataJson.dataToJson(d, forBackup = false).toString()).commit()
    }

    fun loadLog(): List<SessionRecord> {
        val text = prefs.getString(KEY_LOG, null) ?: return emptyList()
        return try {
            val arr = JSONArray(text)
            val out = ArrayList<SessionRecord>(arr.length())
            for (i in 0 until arr.length()) {
                try {
                    out.add(DataJson.recordFromJson(arr.getJSONObject(i)))
                } catch (_: Exception) {
                    // skip a corrupted entry
                }
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveLog(log: List<SessionRecord>) {
        val arr = JSONArray()
        log.forEach { arr.put(DataJson.recordToJson(it)) }
        prefs.edit().putString(KEY_LOG, arr.toString()).commit()
    }

    // ---------------------------------------------------- automatic local backup

    /**
     * Writes a rolling snapshot at most once per calendar day, so there's always a recent,
     * known-good copy to fall back to without the user having to remember to export manually.
     * Keeps the last [AUTO_BACKUP_KEEP_DAYS] snapshots and prunes older ones.
     */
    fun maybeSaveAutoBackup(d: AppData) {
        val today = LocalDate.now().toEpochDay()
        if (prefs.getLong(KEY_LAST_AUTO_BACKUP_DAY, -1L) == today) return
        val editor = prefs.edit()
        editor.putString(KEY_AUTO_BACKUP_PREFIX + today, DataJson.dataToJson(d, forBackup = true).toString())
        editor.putLong(KEY_LAST_AUTO_BACKUP_DAY, today)
        prefs.all.keys
            .filter { it.startsWith(KEY_AUTO_BACKUP_PREFIX) }
            .forEach { key ->
                val day = key.removePrefix(KEY_AUTO_BACKUP_PREFIX).toLongOrNull()
                if (day == null || day <= today - AUTO_BACKUP_KEEP_DAYS) editor.remove(key)
            }
        editor.apply()
    }

    /** Available automatic backups, most recent first. */
    fun listAutoBackups(): List<Long> = prefs.all.keys
        .filter { it.startsWith(KEY_AUTO_BACKUP_PREFIX) }
        .mapNotNull { it.removePrefix(KEY_AUTO_BACKUP_PREFIX).toLongOrNull() }
        .sortedDescending()

    fun loadAutoBackup(epochDay: Long): AppData? {
        val text = prefs.getString(KEY_AUTO_BACKUP_PREFIX + epochDay, null) ?: return null
        return try {
            DataJson.dataFromJson(JSONObject(text))
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------- "plan ending soon" warning (once per end date)

    fun warnedPlanEndDay(): Long = prefs.getLong(KEY_WARNED_PLAN_END, -1L)
    fun setWarnedPlanEndDay(epochDay: Long) { prefs.edit().putLong(KEY_WARNED_PLAN_END, epochDay).apply() }

    // ---------------------------------------------------------------- onboarding

    fun hasSeenOnboarding(): Boolean = prefs.getBoolean(KEY_ONBOARDING_SEEN, false)
    fun setSeenOnboarding() { prefs.edit().putBoolean(KEY_ONBOARDING_SEEN, true).apply() }

    private companion object {
        const val KEY_DATA = "data_json"
        const val KEY_LOG = "log_json"
        const val KEY_LAST_AUTO_BACKUP_DAY = "last_auto_backup_day"
        const val KEY_AUTO_BACKUP_PREFIX = "auto_backup_"
        const val AUTO_BACKUP_KEEP_DAYS = 3L
        const val KEY_WARNED_PLAN_END = "warned_plan_end_day"
        const val KEY_ONBOARDING_SEEN = "onboarding_seen"
    }
}

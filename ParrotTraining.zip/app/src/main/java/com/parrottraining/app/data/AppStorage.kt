package com.parrottraining.app.data

import android.content.Context
import com.parrottraining.app.domain.AppData
import com.parrottraining.app.domain.SessionRecord
import org.json.JSONArray
import org.json.JSONObject

/** Local-only persistence (SharedPreferences + JSON). No network, no account. */
class AppStorage(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("parrot_training", Context.MODE_PRIVATE)

    fun loadData(): AppData {
        val text = prefs.getString(KEY_DATA, null) ?: return AppData()
        return try {
            DataJson.dataFromJson(JSONObject(text))
        } catch (e: Exception) {
            AppData()
        }
    }

    fun saveData(d: AppData) {
        prefs.edit().putString(KEY_DATA, DataJson.dataToJson(d, forBackup = false).toString()).commit()
    }

    fun loadLog(): List<SessionRecord> {
        val text = prefs.getString(KEY_LOG, null) ?: return emptyList()
        return try {
            val arr = JSONArray(text)
            val out = ArrayList<SessionRecord>(arr.length())
            for (i in 0 until arr.length()) {
                try {
                    out.add(DataJson.recordFromJson(arr.getJSONObject(i)))
                } catch (_: Exception) {
                    // skip a corrupted entry
                }
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveLog(log: List<SessionRecord>) {
        val arr = JSONArray()
        log.forEach { arr.put(DataJson.recordToJson(it)) }
        prefs.edit().putString(KEY_LOG, arr.toString()).commit()
    }

    private companion object {
        const val KEY_DATA = "data_json"
        const val KEY_LOG = "log_json"
    }
}

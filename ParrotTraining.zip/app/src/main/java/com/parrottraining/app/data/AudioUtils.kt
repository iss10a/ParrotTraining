package com.parrottraining.app.data

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

object AudioUtils {

    /** Keeps read access to the picked file across app restarts and reboots. */
    fun takePermission(ctx: Context, uri: Uri) {
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
            // Some providers do not offer persistable grants; availability is checked separately.
        }
    }

    fun releasePermission(ctx: Context, uri: Uri) {
        try {
            ctx.contentResolver.releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
    }

    fun displayName(ctx: Context, uri: Uri): String? {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment
    }

    /** Duration in ms, or null if the file cannot be opened / is not a playable audio file. */
    fun durationMs(ctx: Context, uri: Uri): Long? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            null
        } finally {
            try {
                r.release()
            } catch (_: Exception) {
            }
        }
    }

    /** Folder for audio/video files that came from a full backup (inside the app, so they survive the original being deleted). */
    fun ownedMediaDir(ctx: Context): File = File(ctx.filesDir, "media").apply { mkdirs() }

    /** Deletes a file this app copied in from a backup. Never touches the user's own files. */
    fun deleteOwnedFile(ctx: Context, uriString: String) {
        try {
            val uri = Uri.parse(uriString)
            if (uri.scheme != "file") return
            val f = File(uri.path ?: return).canonicalFile
            if (f.parentFile == ownedMediaDir(ctx).canonicalFile) f.delete()
        } catch (_: Exception) {
        }
    }

    fun isAvailable(ctx: Context, uri: Uri): Boolean = try {
        ctx.contentResolver.openFileDescriptor(uri, "r")?.use { true } ?: false
    } catch (e: Exception) {
        false
    }
}

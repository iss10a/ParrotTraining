package com.parrottraining.app.data

import android.content.Context
import android.net.Uri
import com.parrottraining.app.domain.AppData
import com.parrottraining.app.domain.AudioItem
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** A restored backup: the data, plus how many audio/video files came with it. */
class ImportedBackup(val data: AppData, val mediaCount: Int)

/**
 * Export / import of the plan.
 * - Plan only: a small JSON file (audio and video files are NOT inside it).
 * - Full backup: a zip with `plan.json` and every audio/video file under `media/`. On restore the files are copied
 *   inside the app, so nothing has to be added again.
 */
object BackupManager {
    private const val FORMAT = "parrot-training-plan"
    private const val VERSION = 1
    private const val PLAN_ENTRY = "plan.json"
    private const val MEDIA_DIR = "media/"
    private const val BUFFER = 64 * 1024

    fun export(data: AppData): String {
        val o = DataJson.dataToJson(data, forBackup = true)
        o.put("format", FORMAT)
        o.put("version", VERSION)
        return o.toString(2)
    }

    fun parse(text: String): AppData {
        val o = JSONObject(text)
        require(o.optString("format") == FORMAT) { "ملف غير صالح" }
        return DataJson.dataFromJson(o)
    }

    /** File extension of a media name (".mp3"), or empty if it has none or looks odd. */
    fun extensionOf(name: String): String {
        val i = name.lastIndexOf('.')
        if (i <= 0 || name.length - i > 6) return ""
        val ext = name.substring(i).lowercase()
        return if (ext.drop(1).all { it in 'a'..'z' || it in '0'..'9' }) ext else ""
    }

    /** Writes the full backup to [out] and returns how many media files were stored. Call off the main thread. */
    fun exportZip(ctx: Context, data: AppData, out: OutputStream): Int {
        var stored = 0
        ZipOutputStream(BufferedOutputStream(out, BUFFER)).use { zip ->
            // Audio and video are already compressed: storing them as they are is much faster.
            zip.setLevel(Deflater.NO_COMPRESSION)
            zip.putNextEntry(ZipEntry(PLAN_ENTRY))
            zip.write(export(data).toByteArray(Charsets.UTF_8))
            zip.closeEntry()
            (data.audios + data.videos).distinctBy { it.id }.forEach { item ->
                val input = try {
                    ctx.contentResolver.openInputStream(Uri.parse(item.uri))
                } catch (_: Exception) {
                    null
                }
                // A file that is no longer readable is skipped; the plan still lists it.
                if (input != null) {
                    input.use {
                        zip.putNextEntry(ZipEntry(MEDIA_DIR + item.id + extensionOf(item.name)))
                        it.copyTo(zip, BUFFER)
                        zip.closeEntry()
                        stored++
                    }
                }
            }
        }
        return stored
    }

    /** Reads either kind of backup (zip or plain JSON). Call off the main thread. */
    fun importAuto(ctx: Context, input: InputStream): ImportedBackup {
        val buffered = BufferedInputStream(input, BUFFER)
        buffered.mark(4)
        val b0 = buffered.read()
        val b1 = buffered.read()
        buffered.reset()
        return if (b0 == 'P'.code && b1 == 'K'.code) {
            importZip(ctx, buffered)
        } else {
            ImportedBackup(parse(buffered.readBytes().toString(Charsets.UTF_8)), 0)
        }
    }

    private fun importZip(ctx: Context, input: InputStream): ImportedBackup {
        val dir = AudioUtils.ownedMediaDir(ctx)
        var plan: AppData? = null
        val files = HashMap<String, File>()
        ZipInputStream(input).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.isDirectory) continue
                if (entry.name == PLAN_ENTRY) {
                    plan = parse(zip.readBytes().toString(Charsets.UTF_8))
                } else if (entry.name.startsWith(MEDIA_DIR)) {
                    // Never trust a name coming from a file: keep only a plain file name.
                    val safe = entry.name.removePrefix(MEDIA_DIR).filter { it.isLetterOrDigit() || it == '.' || it == '-' || it == '_' }
                    if (safe.isEmpty() || safe.startsWith(".")) continue
                    val target = File(dir, safe)
                    FileOutputStream(target).use { zip.copyTo(it, BUFFER) }
                    files[safe.substringBeforeLast('.', safe)] = target
                }
            }
        }
        val data = plan ?: throw IllegalArgumentException("ملف غير صالح")
        fun relink(list: List<AudioItem>) = list.map { item ->
            files[item.id]?.let { item.copy(uri = Uri.fromFile(it).toString()) } ?: item
        }
        return ImportedBackup(data.copy(audios = relink(data.audios), videos = relink(data.videos)), files.size)
    }
}

package com.parrottraining.app.data

import com.parrottraining.app.domain.AppData
import org.json.JSONObject

/** Export / import of the plan (settings, audio order, plan). Audio URIs are NOT portable between phones. */
object BackupManager {
    private const val FORMAT = "parrot-training-plan"
    private const val VERSION = 1

    fun export(data: AppData): String {
        val o = DataJson.dataToJson(data, forBackup = true)
        o.put("format", FORMAT)
        o.put("version", VERSION)
        return o.toString(2)
    }

    fun parse(text: String): AppData {
        val o = JSONObject(text)
        require(o.optString("format") == FORMAT) { "ملف غير صالح" }
        return DataJson.dataFromJson(o)
    }
}

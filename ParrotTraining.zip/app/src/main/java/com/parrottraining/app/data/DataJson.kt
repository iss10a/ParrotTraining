package com.parrottraining.app.data

import com.parrottraining.app.domain.AppData
import com.parrottraining.app.domain.AudioItem
import com.parrottraining.app.domain.MissedPolicy
import com.parrottraining.app.domain.PlanState
import com.parrottraining.app.domain.PlanStatus
import com.parrottraining.app.domain.SessionRecord
import com.parrottraining.app.domain.SessionStatus
import com.parrottraining.app.domain.SessionType
import com.parrottraining.app.domain.Settings
import org.json.JSONArray
import org.json.JSONObject

/** JSON (de)serialisation for everything we persist. Uses the built-in org.json, no extra dependencies. */
object DataJson {

    fun audioToJson(a: AudioItem): JSONObject = JSONObject()
        .put("id", a.id)
        .put("uri", a.uri)
        .put("name", a.name)
        .put("durationMs", a.durationMs)
        .put("isVideo", a.isVideo)

    fun audioFromJson(o: JSONObject): AudioItem = AudioItem(
        id = o.getString("id"),
        uri = o.getString("uri"),
        name = o.optString("name", "audio"),
        durationMs = o.optLong("durationMs", 0L),
        isVideo = o.optBoolean("isVideo", false)
    )

    fun settingsToJson(s: Settings): JSONObject = JSONObject()
        .put("phaseDays", s.phaseDays)
        .put("sessionMinutes", s.sessionMinutes)
        .put("timesOfDay", JSONArray(s.timesOfDay))
        .put("minutesByTime", intMapToJson(s.minutesByTime))
        .put("volumePercent", s.volumePercent)
        .put("autoRepeat", s.autoRepeat)
        .put("missedPolicy", s.missedPolicy.name)
        .put("activeDaysOfWeek", JSONArray(s.activeDaysOfWeek.sorted()))
        .put("vibrateOnStart", s.vibrateOnStart)
        .put("recordSessions", s.recordSessions)
        .put("recordHighQuality", s.recordHighQuality)
        .put("videoTimes", JSONArray(s.videoTimes))
        .put("videoMinutes", s.videoMinutes)
        .put("videoDaysOfWeek", JSONArray(s.videoDaysOfWeek.sorted()))

    fun settingsFromJson(o: JSONObject): Settings {
        val d = Settings()
        val times = ArrayList<Int>()
        val arr = o.optJSONArray("timesOfDay")
        if (arr != null) for (i in 0 until arr.length()) times.add(arr.optInt(i))
        val daysArr = o.optJSONArray("activeDaysOfWeek")
        val days = if (daysArr != null) {
            (0 until daysArr.length()).map { daysArr.optInt(it) }.toSet()
        } else d.activeDaysOfWeek
        val vtArr = o.optJSONArray("videoTimes")
        val vTimes = if (vtArr != null) (0 until vtArr.length()).map { vtArr.optInt(it) } else d.videoTimes
        val vdArr = o.optJSONArray("videoDaysOfWeek")
        val vDays = if (vdArr != null) (0 until vdArr.length()).map { vdArr.optInt(it) }.toSet() else d.videoDaysOfWeek
        return Settings(
            phaseDays = o.optInt("phaseDays", d.phaseDays),
            sessionMinutes = o.optInt("sessionMinutes", d.sessionMinutes),
            timesOfDay = if (arr != null) times else d.timesOfDay,
            minutesByTime = intMapFromJson(o.optJSONObject("minutesByTime")),
            volumePercent = o.optInt("volumePercent", d.volumePercent),
            autoRepeat = o.optBoolean("autoRepeat", d.autoRepeat),
            missedPolicy = runCatching { MissedPolicy.valueOf(o.optString("missedPolicy", "IGNORE")) }
                .getOrDefault(MissedPolicy.IGNORE),
            activeDaysOfWeek = days,
            vibrateOnStart = o.optBoolean("vibrateOnStart", d.vibrateOnStart),
            recordSessions = o.optBoolean("recordSessions", d.recordSessions),
            recordHighQuality = o.optBoolean("recordHighQuality", d.recordHighQuality),
            videoTimes = vTimes,
            videoMinutes = o.optInt("videoMinutes", d.videoMinutes),
            videoDaysOfWeek = vDays
        ).sanitized()
    }

    private fun intMapToJson(m: Map<Int, Int>): JSONObject {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k.toString(), v) }
        return o
    }

    private fun intMapFromJson(o: JSONObject?): Map<Int, Int> {
        if (o == null) return emptyMap()
        val r = HashMap<Int, Int>()
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            val key = k.toIntOrNull() ?: continue
            r[key] = o.optInt(k)
        }
        return r
    }

    private fun strMapToJson(m: Map<Int, String>): JSONObject {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k.toString(), v) }
        return o
    }

    private fun strMapFromJson(o: JSONObject?): Map<Int, String> {
        if (o == null) return emptyMap()
        val r = HashMap<Int, String>()
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            val key = k.toIntOrNull() ?: continue
            r[key] = o.optString(k)
        }
        return r
    }

    private fun extraMapToJson(m: Map<Int, List<String>>): JSONObject {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k.toString(), JSONArray(v)) }
        return o
    }

    private fun extraMapFromJson(o: JSONObject?): Map<Int, List<String>> {
        if (o == null) return emptyMap()
        val r = HashMap<Int, List<String>>()
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            val key = k.toIntOrNull() ?: continue
            val arr = o.optJSONArray(k) ?: continue
            val ids = (0 until arr.length()).map { i -> arr.optString(i) }.filter { s -> s.isNotEmpty() }
            if (ids.isNotEmpty()) r[key] = ids
        }
        return r
    }

    /** [forBackup] leaves out runtime-only fields (version, missed-detection cursor, makeup counter). */
    fun planToJson(p: PlanState, forBackup: Boolean): JSONObject {
        val o = JSONObject()
            .put("status", p.status.name)
            .put("startEpochDay", p.startEpochDay)
            .put("phaseLengthOverrides", intMapToJson(p.phaseLengthOverrides))
            .put("audioOverrides", strMapToJson(p.audioOverrides))
            .put("extraAudios", extraMapToJson(p.extraAudios))
            .put("videoByPhase", extraMapToJson(p.videoByPhase))
        if (p.pausedOnEpochDay != null) o.put("pausedOnEpochDay", p.pausedOnEpochDay)
        if (!forBackup) {
            o.put("version", p.version)
            o.put("lastCheckedAtMs", p.lastCheckedAtMs)
            o.put("pendingMakeups", p.pendingMakeups)
        }
        return o
    }

    fun planFromJson(o: JSONObject): PlanState = PlanState(
        status = runCatching { PlanStatus.valueOf(o.optString("status", "NOT_STARTED")) }
            .getOrDefault(PlanStatus.NOT_STARTED),
        startEpochDay = o.optLong("startEpochDay", PlanState().startEpochDay),
        phaseLengthOverrides = intMapFromJson(o.optJSONObject("phaseLengthOverrides")),
        audioOverrides = strMapFromJson(o.optJSONObject("audioOverrides")),
        extraAudios = extraMapFromJson(o.optJSONObject("extraAudios")),
        videoByPhase = extraMapFromJson(o.optJSONObject("videoByPhase")),
        pausedOnEpochDay = if (o.has("pausedOnEpochDay")) o.optLong("pausedOnEpochDay") else null,
        version = o.optLong("version", 0L),
        lastCheckedAtMs = o.optLong("lastCheckedAtMs", 0L),
        pendingMakeups = o.optInt("pendingMakeups", 0)
    )

    fun dataToJson(d: AppData, forBackup: Boolean): JSONObject {
        val audios = JSONArray()
        d.audios.forEach { audios.put(audioToJson(it)) }
        val videos = JSONArray()
        d.videos.forEach { videos.put(audioToJson(it.copy(isVideo = true))) }
        return JSONObject()
            .put("audios", audios)
            .put("videos", videos)
            .put("settings", settingsToJson(d.settings))
            .put("plan", planToJson(d.plan, forBackup))
    }

    fun dataFromJson(o: JSONObject): AppData {
        val audios = ArrayList<AudioItem>()
        val arr = o.optJSONArray("audios")
        if (arr != null) for (i in 0 until arr.length()) audios.add(audioFromJson(arr.getJSONObject(i)))
        val videos = ArrayList<AudioItem>()
        val varr = o.optJSONArray("videos")
        if (varr != null) for (i in 0 until varr.length()) videos.add(audioFromJson(varr.getJSONObject(i)).copy(isVideo = true))
        // Videos saved by an earlier build inside the audio list are moved to the video library.
        val migrated = audios.filter { it.isVideo }
        audios.removeAll { it.isVideo }
        videos.addAll(migrated.filter { m -> videos.none { it.id == m.id } })
        return AppData(
            audios = audios,
            videos = videos,
            settings = o.optJSONObject("settings")?.let { settingsFromJson(it) } ?: Settings(),
            plan = o.optJSONObject("plan")?.let { planFromJson(it) } ?: PlanState()
        )
    }

    fun recordToJson(r: SessionRecord): JSONObject = JSONObject()
        .put("id", r.id)
        .put("type", r.type.name)
        .put("status", r.status.name)
        .put("slotAtMs", r.slotAtMs)
        .put("startedAtMs", r.startedAtMs)
        .put("plannedMs", r.plannedMs)
        .put("playedMs", r.playedMs)
        .put("audioId", r.audioId ?: JSONObject.NULL)
        .put("audioName", r.audioName)
        .put("phaseIndex", r.phaseIndex)
        .put("error", r.errorMessage ?: JSONObject.NULL)
        .put("activity", r.activityPercent ?: JSONObject.NULL)

    fun recordFromJson(o: JSONObject): SessionRecord = SessionRecord(
        id = o.getString("id"),
        type = runCatching { SessionType.valueOf(o.getString("type")) }.getOrDefault(SessionType.MANUAL),
        status = runCatching { SessionStatus.valueOf(o.getString("status")) }.getOrDefault(SessionStatus.INTERRUPTED),
        slotAtMs = o.optLong("slotAtMs", 0L),
        startedAtMs = o.optLong("startedAtMs", 0L),
        plannedMs = o.optLong("plannedMs", 0L),
        playedMs = o.optLong("playedMs", 0L),
        audioId = if (o.isNull("audioId")) null else o.optString("audioId"),
        audioName = o.optString("audioName", ""),
        phaseIndex = o.optInt("phaseIndex", -1),
        errorMessage = if (o.isNull("error")) null else o.optString("error"),
        activityPercent = if (!o.has("activity") || o.isNull("activity")) null else o.optInt("activity").coerceIn(0, 100)
    )
}

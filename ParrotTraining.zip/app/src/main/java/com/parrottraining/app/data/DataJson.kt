package com.parrottraining.app.data

import com.parrottraining.app.domain.AppData
import com.parrottraining.app.domain.AudioItem
import com.parrottraining.app.domain.MissedPolicy
import com.parrottraining.app.domain.PlanState
import com.parrottraining.app.domain.PlanStatus
import com.parrottraining.app.domain.SessionRecord
import com.parrottraining.app.domain.SessionStatus
import com.parrottraining.app.domain.SessionType
import com.parrottraining.app.domain.Settings
import org.json.JSONArray
import org.json.JSONObject

/** JSON (de)serialisation for everything we persist. Uses the built-in org.json, no extra dependencies. */
object DataJson {

    fun audioToJson(a: AudioItem): JSONObject = JSONObject()
        .put("id", a.id)
        .put("uri", a.uri)
        .put("name", a.name)
        .put("durationMs", a.durationMs)

    fun audioFromJson(o: JSONObject): AudioItem = AudioItem(
        id = o.getString("id"),
        uri = o.getString("uri"),
        name = o.optString("name", "audio"),
        durationMs = o.optLong("durationMs", 0L)
    )

    fun settingsToJson(s: Settings): JSONObject = JSONObject()
        .put("phaseDays", s.phaseDays)
        .put("sessionMinutes", s.sessionMinutes)
        .put("timesOfDay", JSONArray(s.timesOfDay))
        .put("volumePercent", s.volumePercent)
        .put("autoRepeat", s.autoRepeat)
        .put("missedPolicy", s.missedPolicy.name)

    fun settingsFromJson(o: JSONObject): Settings {
        val d = Settings()
        val times = ArrayList<Int>()
        val arr = o.optJSONArray("timesOfDay")
        if (arr != null) for (i in 0 until arr.length()) times.add(arr.optInt(i))
        return Settings(
            phaseDays = o.optInt("phaseDays", d.phaseDays),
            sessionMinutes = o.optInt("sessionMinutes", d.sessionMinutes),
            timesOfDay = if (arr != null) times else d.timesOfDay,
            volumePercent = o.optInt("volumePercent", d.volumePercent),
            autoRepeat = o.optBoolean("autoRepeat", d.autoRepeat),
            missedPolicy = runCatching { MissedPolicy.valueOf(o.optString("missedPolicy", "IGNORE")) }
                .getOrDefault(MissedPolicy.IGNORE)
        ).sanitized()
    }

    private fun intMapToJson(m: Map<Int, Int>): JSONObject {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k.toString(), v) }
        return o
    }

    private fun intMapFromJson(o: JSONObject?): Map<Int, Int> {
        if (o == null) return emptyMap()
        val r = HashMap<Int, Int>()
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            val key = k.toIntOrNull() ?: continue
            r[key] = o.optInt(k)
        }
        return r
    }

    private fun strMapToJson(m: Map<Int, String>): JSONObject {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k.toString(), v) }
        return o
    }

    private fun strMapFromJson(o: JSONObject?): Map<Int, String> {
        if (o == null) return emptyMap()
        val r = HashMap<Int, String>()
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            val key = k.toIntOrNull() ?: continue
            r[key] = o.optString(k)
        }
        return r
    }

    /** [forBackup] leaves out runtime-only fields (version, missed-detection cursor, makeup counter). */
    fun planToJson(p: PlanState, forBackup: Boolean): JSONObject {
        val o = JSONObject()
            .put("status", p.status.name)
            .put("startEpochDay", p.startEpochDay)
            .put("phaseLengthOverrides", intMapToJson(p.phaseLengthOverrides))
            .put("audioOverrides", strMapToJson(p.audioOverrides))
        if (p.pausedOnEpochDay != null) o.put("pausedOnEpochDay", p.pausedOnEpochDay)
        if (!forBackup) {
            o.put("version", p.version)
            o.put("lastCheckedAtMs", p.lastCheckedAtMs)
            o.put("pendingMakeups", p.pendingMakeups)
        }
        return o
    }

    fun planFromJson(o: JSONObject): PlanState = PlanState(
        status = runCatching { PlanStatus.valueOf(o.optString("status", "NOT_STARTED")) }
            .getOrDefault(PlanStatus.NOT_STARTED),
        startEpochDay = o.optLong("startEpochDay", PlanState().startEpochDay),
        phaseLengthOverrides = intMapFromJson(o.optJSONObject("phaseLengthOverrides")),
        audioOverrides = strMapFromJson(o.optJSONObject("audioOverrides")),
        pausedOnEpochDay = if (o.has("pausedOnEpochDay")) o.optLong("pausedOnEpochDay") else null,
        version = o.optLong("version", 0L),
        lastCheckedAtMs = o.optLong("lastCheckedAtMs", 0L),
        pendingMakeups = o.optInt("pendingMakeups", 0)
    )

    fun dataToJson(d: AppData, forBackup: Boolean): JSONObject {
        val audios = JSONArray()
        d.audios.forEach { audios.put(audioToJson(it)) }
        return JSONObject()
            .put("audios", audios)
            .put("settings", settingsToJson(d.settings))
            .put("plan", planToJson(d.plan, forBackup))
    }

    fun dataFromJson(o: JSONObject): AppData {
        val audios = ArrayList<AudioItem>()
        val arr = o.optJSONArray("audios")
        if (arr != null) for (i in 0 until arr.length()) audios.add(audioFromJson(arr.getJSONObject(i)))
        return AppData(
            audios = audios,
            settings = o.optJSONObject("settings")?.let { settingsFromJson(it) } ?: Settings(),
            plan = o.optJSONObject("plan")?.let { planFromJson(it) } ?: PlanState()
        )
    }

    fun recordToJson(r: SessionRecord): JSONObject = JSONObject()
        .put("id", r.id)
        .put("type", r.type.name)
        .put("status", r.status.name)
        .put("slotAtMs", r.slotAtMs)
        .put("startedAtMs", r.startedAtMs)
        .put("plannedMs", r.plannedMs)
        .put("playedMs", r.playedMs)
        .put("audioId", r.audioId ?: JSONObject.NULL)
        .put("audioName", r.audioName)
        .put("phaseIndex", r.phaseIndex)
        .put("error", r.errorMessage ?: JSONObject.NULL)

    fun recordFromJson(o: JSONObject): SessionRecord = SessionRecord(
        id = o.getString("id"),
        type = runCatching { SessionType.valueOf(o.getString("type")) }.getOrDefault(SessionType.MANUAL),
        status = runCatching { SessionStatus.valueOf(o.getString("status")) }.getOrDefault(SessionStatus.INTERRUPTED),
        slotAtMs = o.optLong("slotAtMs", 0L),
        startedAtMs = o.optLong("startedAtMs", 0L),
        plannedMs = o.optLong("plannedMs", 0L),
        playedMs = o.optLong("playedMs", 0L),
        audioId = if (o.isNull("audioId")) null else o.optString("audioId"),
        audioName = o.optString("audioName", ""),
        phaseIndex = o.optInt("phaseIndex", -1),
        errorMessage = if (o.isNull("error")) null else o.optString("error")
    )
}

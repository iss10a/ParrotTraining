package com.parrottraining.app.data

import android.util.Log
import com.parrottraining.app.domain.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * Sends a push to another phone (for example an iPhone running the free, open-source ntfy app).
 * It posts a small JSON message to an ntfy server; the iPhone subscribes to the same "topic".
 * Nothing here can slow down or break a training session: sending happens on its own thread and errors are ignored.
 */
object RemoteNotifier {
    private const val TAG = "RemoteNotifier"

    fun isReady(s: Settings): Boolean = s.remoteNotify && s.remoteTopic.isNotBlank() && s.remoteServer.isNotBlank()

    fun sendAsync(s: Settings, title: String, message: String, priority: Int = 3) {
        if (!isReady(s)) return
        thread(name = "remote-notify", isDaemon = true) {
            sendBlocking(s, title, message, priority)
        }
    }

    /** Returns null when the message was accepted, otherwise a short Arabic reason. Call off the main thread. */
    fun sendBlocking(s: Settings, title: String, message: String, priority: Int = 3): String? {
        if (s.remoteTopic.isBlank() || s.remoteServer.isBlank()) return "اسم الموضوع أو الخادم فارغ"
        var conn: HttpURLConnection? = null
        return try {
            val body = JSONObject()
                .put("topic", s.remoteTopic)
                .put("title", title)
                .put("message", message)
                .put("priority", priority)
                .toString()
            conn = (URL(s.remoteServer.trimEnd('/')).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 8_000
                readTimeout = 8_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code in 200..299) null else "رفض الخادم الطلب (رمز $code)"
        } catch (e: Exception) {
            Log.w(TAG, "push failed", e)
            "تعذر الاتصال بالخادم، تأكد من الإنترنت"
        } finally {
            conn?.disconnect()
        }
    }
}

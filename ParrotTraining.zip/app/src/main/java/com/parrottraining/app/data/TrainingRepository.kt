package com.parrottraining.app.data

import android.content.Context
import com.parrottraining.app.domain.AppData
import com.parrottraining.app.domain.AudioItem
import com.parrottraining.app.domain.MissedPolicy
import com.parrottraining.app.domain.movedBy
import com.parrottraining.app.domain.PlanEngine
import com.parrottraining.app.domain.PlanPosition
import com.parrottraining.app.domain.PlanState
import com.parrottraining.app.domain.PlanStatus
import com.parrottraining.app.domain.Resolved
import com.parrottraining.app.domain.SessionRecord
import com.parrottraining.app.domain.SessionStatus
import com.parrottraining.app.domain.SessionType
import com.parrottraining.app.domain.Settings
import com.parrottraining.app.playback.NotificationHelper
import com.parrottraining.app.playback.PlaybackStateHolder
import com.parrottraining.app.scheduler.TrainingScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.ZoneId
import java.util.UUID

/**
 * Single source of truth. Works in any process entry point (UI, alarm receiver, boot receiver, service),
 * so every mutation is synchronized and persisted immediately.
 */
class TrainingRepository private constructor(private val app: Context) {

    private val storage = AppStorage(app)
    private val lock = Any()

    private val _data = MutableStateFlow(storage.loadData().let { it.copy(settings = it.settings.sanitized()) })
    val data: StateFlow<AppData> = _data.asStateFlow()

    private val _log = MutableStateFlow(storage.loadLog())
    val log: StateFlow<List<SessionRecord>> = _log.asStateFlow()

    // ------------------------------------------------------------------ core

    private fun zone(): ZoneId = ZoneId.systemDefault()

    /** Normalizes the plan and detects missed / interrupted sessions. Safe to call at any time. */
    fun refresh() {
        synchronized(lock) { reconcileLocked(System.currentTimeMillis()) }
    }

    private fun reconcileLocked(now: Long) {
        val d = _data.value
        val zone = zone()
        val today = PlanEngine.epochDayOf(now, zone)
        var plan = d.plan
        var log = _log.value
        var logChanged = false

        // RUNNING records whose service is gone (process killed, reboot...) become INTERRUPTED.
        val activeId = PlaybackStateHolder.activeRecordId
        log = log.map { r ->
            if (r.status == SessionStatus.RUNNING && r.id != activeId &&
                now > r.startedAtMs + r.plannedMs + 120_000L
            ) {
                logChanged = true
                r.copy(status = SessionStatus.INTERRUPTED)
            } else r
        }

        if (plan.status == PlanStatus.ACTIVE) {
            val last = plan.lastCheckedAtMs
            val from = if (last in 1..now) last else now
            val to = now - PlanEngine.LATE_GRACE_MS
            if (to > from) {
                val known = log.filter { it.slotAtMs > 0 }.map { it.slotAtMs }.toHashSet()
                val slots = PlanEngine.slotsBetween(from, to, zone, d.audios, plan, d.settings)
                val added = slots.filter { it.epochMs !in known }.takeLast(100).map { slot ->
                    SessionRecord(
                        id = newId(),
                        type = SessionType.SCHEDULED,
                        status = SessionStatus.MISSED,
                        slotAtMs = slot.epochMs,
                        startedAtMs = slot.epochMs,
                        plannedMs = d.settings.minutesFor(slot.minuteOfDay) * 60_000L,
                        playedMs = 0L,
                        audioId = slot.position.audio.id,
                        audioName = slot.position.audio.name,
                        phaseIndex = slot.position.phaseIndex
                    )
                }
                if (added.isNotEmpty()) {
                    log = (log + added).sortedBy { it.startedAtMs }.takeLast(MAX_LOG)
                    logChanged = true
                    if (d.settings.missedPolicy == MissedPolicy.MAKEUP) {
                        plan = plan.copy(pendingMakeups = minOf(MAX_MAKEUPS, plan.pendingMakeups + added.size))
                    }
                }
                plan = plan.copy(lastCheckedAtMs = to)
            } else if (from != last) {
                plan = plan.copy(lastCheckedAtMs = from)
            }
        }

        plan = PlanEngine.normalize(plan, d.settings, d.audios.size, today)
        checkPlanEndingSoon(plan, d, today)

        if (plan != d.plan) {
            val next = d.copy(plan = plan)
            _data.value = next
            storage.saveData(next)
        }
        if (logChanged) {
            _log.value = log
            storage.saveLog(log)
        }
        storage.maybeSaveAutoBackup(_data.value)
    }

    /** Posts a one-time quiet notification when a non-repeating plan has ~1 week or less left. */
    private fun checkPlanEndingSoon(plan: PlanState, d: AppData, today: Long) {
        if (plan.status != PlanStatus.ACTIVE || d.settings.autoRepeat || d.audios.isEmpty()) return
        val total = PlanEngine.firstCycle(d.audios.size, plan, d.settings).sumOf { it.length }
        val endDay = plan.startEpochDay + total - 1 // last day of the plan
        val daysLeft = endDay - today
        if (daysLeft !in 0L..PLAN_ENDING_SOON_DAYS) return
        if (storage.warnedPlanEndDay() == endDay) return
        storage.setWarnedPlanEndDay(endDay)
        val msg = if (daysLeft == 0L) {
            "اليوم هو آخر يوم في خطة التدريب. فعّل \"إعادة البرنامج تلقائياً\" من الإعدادات إذا رغبت بالاستمرار."
        } else {
            "باقي ${daysLeft} أيام على انتهاء خطة التدريب. جهّز صوتاً إضافياً أو فعّل \"إعادة البرنامج تلقائياً\"."
        }
        NotificationHelper.postAlert(app, msg)
    }

    /** Applies [block] to the data, bumps the plan version, persists, then re-arms the alarm. */
    private fun mutate(block: (data: AppData, nowMs: Long, todayEpochDay: Long) -> AppData) {
        synchronized(lock) {
            val now = System.currentTimeMillis()
            reconcileLocked(now)
            val cur = _data.value
            val today = PlanEngine.epochDayOf(now, zone())
            val edited = block(cur, now, today)
            val next = edited.copy(
                settings = edited.settings.sanitized(),
                plan = edited.plan.copy(version = cur.plan.version + 1)
            )
            _data.value = next
            storage.saveData(next)
        }
        TrainingScheduler(app).reschedule()
    }

    // ------------------------------------------------------------ plan edits

    fun startPlan(startEpochDay: Long?) = mutate { d, now, today ->
        d.copy(plan = PlanEngine.start(d.plan, startEpochDay ?: today, now))
    }

    fun pausePlan() = mutate { d, _, today -> d.copy(plan = PlanEngine.pause(d.plan, today)) }

    fun resumePlan() = mutate { d, now, today -> d.copy(plan = PlanEngine.resume(d.plan, today, now)) }

    fun skipCurrent() = mutate { d, _, today ->
        d.copy(plan = PlanEngine.skipCurrent(d.plan, d.audios, d.settings, today))
    }

    fun repeatCurrent() = mutate { d, _, today ->
        d.copy(plan = PlanEngine.repeatCurrent(d.plan, d.audios, d.settings, today))
    }

    fun setStartDay(epochDay: Long) = mutate { d, _, _ ->
        d.copy(plan = d.plan.copy(startEpochDay = epochDay))
    }

    fun setPhaseAudio(phaseIndex: Int, audioId: String?) = mutate { d, _, _ ->
        val ov = if (audioId == null) d.plan.audioOverrides - phaseIndex
        else d.plan.audioOverrides + (phaseIndex to audioId)
        d.copy(plan = d.plan.copy(audioOverrides = ov))
    }

    fun togglePhaseExtraAudio(phaseIndex: Int, audioId: String) = mutate { d, _, _ ->
        val cur = d.plan.extraAudios[phaseIndex].orEmpty()
        val next = if (audioId in cur) cur - audioId else cur + audioId
        val map = if (next.isEmpty()) d.plan.extraAudios - phaseIndex else d.plan.extraAudios + (phaseIndex to next)
        d.copy(plan = d.plan.copy(extraAudios = map))
    }

    fun togglePhaseVideo(phaseIndex: Int, videoId: String) = mutate { d, _, _ ->
        val cur = d.plan.videoByPhase[phaseIndex].orEmpty()
        val next = if (videoId in cur) cur - videoId else cur + videoId
        val map = if (next.isEmpty()) d.plan.videoByPhase - phaseIndex else d.plan.videoByPhase + (phaseIndex to next)
        d.copy(plan = d.plan.copy(videoByPhase = map))
    }

    // ---------------------------------------------------------------- videos

    fun addVideo(item: AudioItem) = mutate { d, _, _ -> d.copy(videos = d.videos + item.copy(isVideo = true)) }

    fun removeVideo(id: String) = mutate { d, _, _ ->
        d.copy(
            videos = d.videos.filterNot { it.id == id },
            plan = d.plan.copy(
                videoByPhase = d.plan.videoByPhase
                    .mapValues { (_, ids) -> ids.filter { it != id } }
                    .filterValues { it.isNotEmpty() }
            )
        )
    }

    fun moveVideo(id: String, delta: Int) = mutate { d, _, _ ->
        d.copy(videos = d.videos.movedBy({ it.id }, id, delta))
    }

    fun renameVideo(id: String, newName: String) = mutate { d, _, _ ->
        val trimmed = newName.trim().ifBlank { return@mutate d }
        d.copy(videos = d.videos.map { if (it.id == id) it.copy(name = trimmed) else it })
    }

    // ---------------------------------------------------------------- audios

    fun addAudio(item: AudioItem) = mutate { d, _, _ -> d.copy(audios = d.audios + item) }

    fun relinkAudio(id: String, uri: String, name: String, durationMs: Long) = mutate { d, _, _ ->
        d.copy(audios = d.audios.map {
            if (it.id == id) it.copy(uri = uri, name = name, durationMs = durationMs) else it
        })
    }

    fun removeAudio(id: String) = mutate { d, _, _ ->
        d.copy(
            audios = d.audios.filterNot { it.id == id },
            plan = d.plan.copy(
                audioOverrides = d.plan.audioOverrides.filterValues { it != id },
                extraAudios = d.plan.extraAudios
                    .mapValues { (_, ids) -> ids.filter { it != id } }
                    .filterValues { it.isNotEmpty() }
            )
        )
    }

    fun moveAudio(id: String, delta: Int) = mutate { d, _, _ ->
        d.copy(audios = d.audios.movedBy({ it.id }, id, delta))
    }

    fun renameAudio(id: String, newName: String) = mutate { d, _, _ ->
        val trimmed = newName.trim().ifBlank { return@mutate d }
        d.copy(audios = d.audios.map { if (it.id == id) it.copy(name = trimmed) else it })
    }

    // -------------------------------------------------------------- settings

    fun updateSettings(transform: (Settings) -> Settings) = mutate { d, _, _ ->
        d.copy(settings = transform(d.settings))
    }

    fun importData(imported: AppData) = mutate { _, now, _ ->
        imported.copy(plan = imported.plan.copy(lastCheckedAtMs = now, pendingMakeups = 0))
    }

    // ------------------------------------------------------------ resolution

    /** Audio for a scheduled session, based on the date of the session itself. */
    fun resolveForSlot(slotMs: Long): Resolved? {
        val d = _data.value
        val day = PlanEngine.epochDayOf(slotMs, zone())
        val pos = PlanEngine.positionOn(day, d.audios, d.plan, d.settings) as? PlanPosition.Active ?: return null
        return Resolved(pos.audio, pos.phaseIndex, PlanEngine.audiosForPhase(pos.phaseIndex, d.audios, d.plan))
    }

    /** Videos of the week a video session belongs to, based on the date of the session itself. */
    fun resolveVideo(slotMs: Long): Resolved? {
        val d = _data.value
        val day = PlanEngine.epochDayOf(slotMs, zone())
        val pos = PlanEngine.positionOn(day, d.audios, d.plan, d.settings) as? PlanPosition.Active ?: return null
        val items = PlanEngine.videosForPhase(pos.phaseIndex, d.videos, d.plan)
        if (items.isEmpty()) return null
        return Resolved(items.first(), pos.phaseIndex, items)
    }

    /** Audio of the current week (manual / test / makeup sessions). Falls back to the first audio. */
    fun resolveCurrent(nowMs: Long): Resolved? {
        val d = _data.value
        if (d.audios.isEmpty()) return null
        val today = PlanEngine.epochDayOf(nowMs, zone())
        val eff = PlanEngine.normalize(d.plan, d.settings, d.audios.size, today)
        val pos = PlanEngine.currentPosition(today, d.audios, eff, d.settings)
        return if (pos is PlanPosition.Active) {
            Resolved(pos.audio, pos.phaseIndex, PlanEngine.audiosForPhase(pos.phaseIndex, d.audios, eff))
        } else Resolved(d.audios.first(), -1)
    }

    // ------------------------------------------------------------------- log

    fun beginSession(r: SessionRecord) {
        synchronized(lock) {
            _log.value = (_log.value + r).sortedBy { it.startedAtMs }.takeLast(MAX_LOG)
            storage.saveLog(_log.value)
        }
    }

    fun finishSession(id: String, status: SessionStatus, playedMs: Long, error: String?) {
        synchronized(lock) {
            _log.value = _log.value.map {
                if (it.id == id) it.copy(status = status, playedMs = playedMs, errorMessage = error) else it
            }
            storage.saveLog(_log.value)
        }
    }

    /** Records a scheduled/manual session that could not even start. */
    fun logFailure(type: SessionType, slotAtMs: Long, message: String) {
        val resolved = when {
            type == SessionType.VIDEO -> resolveVideo(slotAtMs)
            slotAtMs > 0 -> resolveForSlot(slotAtMs)
            else -> resolveCurrent(System.currentTimeMillis())
        }
        val now = System.currentTimeMillis()
        beginSession(
            SessionRecord(
                id = newId(),
                type = type,
                status = SessionStatus.FAILED,
                slotAtMs = slotAtMs,
                startedAtMs = if (slotAtMs > 0) slotAtMs else now,
                plannedMs = _data.value.settings.let { st ->
                    val t = if (slotAtMs > 0) PlanEngine.minuteOfDayOf(slotAtMs, zone()) else -1
                    when {
                        type == SessionType.VIDEO -> st.videoMinutes
                        t >= 0 -> st.minutesFor(t)
                        else -> st.sessionMinutes
                    }
                } * 60_000L,
                playedMs = 0L,
                audioId = resolved?.audio?.id,
                audioName = resolved?.audio?.name ?: "",
                phaseIndex = resolved?.phaseIndex ?: -1,
                errorMessage = message
            )
        )
    }

    /** True (and decrements the counter) if a makeup session is due after the session that just ended. */
    fun consumeMakeup(): Boolean = synchronized(lock) {
        val d = _data.value
        if (d.settings.missedPolicy != MissedPolicy.MAKEUP ||
            d.plan.pendingMakeups <= 0 || d.plan.status != PlanStatus.ACTIVE
        ) {
            false
        } else {
            val next = d.copy(plan = d.plan.copy(pendingMakeups = d.plan.pendingMakeups - 1))
            _data.value = next
            storage.saveData(next)
            true
        }
    }

    fun clearLog() {
        synchronized(lock) {
            _log.value = emptyList()
            storage.saveLog(emptyList())
        }
    }

    // ----------------------------------------------------- automatic backups

    /** Most recent automatic daily backups first (kept for the last few days). */
    fun listAutoBackups(): List<Long> = storage.listAutoBackups()

    /** Restores a specific automatic backup as the active data. Audio file links may need re-picking. */
    fun restoreAutoBackup(epochDay: Long): Boolean {
        val backup = storage.loadAutoBackup(epochDay) ?: return false
        importData(backup)
        return true
    }

    // --------------------------------------------------------------- onboarding

    fun hasSeenOnboarding(): Boolean = storage.hasSeenOnboarding()
    fun setSeenOnboarding() = storage.setSeenOnboarding()

    companion object {
        private const val MAX_LOG = 600
        private const val MAX_MAKEUPS = 2
        private const val PLAN_ENDING_SOON_DAYS = 7L

        @Volatile
        private var instance: TrainingRepository? = null

        fun get(context: Context): TrainingRepository =
            instance ?: synchronized(this) {
                instance ?: TrainingRepository(context.applicationContext).also { instance = it }
            }

        fun newId(): String = UUID.randomUUID().toString()
    }
}

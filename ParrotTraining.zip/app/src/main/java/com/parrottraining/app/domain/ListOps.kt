package com.parrottraining.app.domain

/** Moves the item with id [id] by [delta] positions (e.g. -1 = up, +1 = down). No-op if out of range. */
fun <T> List<T>.movedBy(id: (T) -> String, targetId: String, delta: Int): List<T> {
    val i = indexOfFirst { id(it) == targetId }
    val j = i + delta
    if (i < 0 || j !in indices) return this
    val list = toMutableList()
    val item = list.removeAt(i)
    list.add(j, item)
    return list
}

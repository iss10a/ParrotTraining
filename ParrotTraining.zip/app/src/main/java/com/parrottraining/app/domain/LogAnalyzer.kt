package com.parrottraining.app.domain

import java.time.ZoneId

data class PhaseRow(
    val phase: PhaseInfo,
    val audio: AudioItem?,
    val planned: Int,
    val completed: Int,
    val missed: Int,
    val lastSessionMs: Long?,
    val nextSessionMs: Long?,
    val isCurrent: Boolean,
    /** Average camera activity (0..100) of this week's completed sessions that were filmed. Null if none. */
    val avgActivityPercent: Int? = null,
    /** Owner's notes on this week's completed sessions. */
    val voiceCount: Int = 0,
    val mimicCount: Int = 0,
    val noneCount: Int = 0,
    /** Reason of the most recent failed session of this week, if any. */
    val lastError: String? = null
) {
    val hasReport: Boolean get() = avgActivityPercent != null || voiceCount + mimicCount + noneCount > 0
}

object LogAnalyzer {
    /** [plan] must already be normalized (and started "today" when the plan has not started yet). */
    fun rows(
        audios: List<AudioItem>,
        plan: PlanState,
        settings: Settings,
        log: List<SessionRecord>,
        zone: ZoneId,
        next: SessionSlot?,
        currentIndex: Int?
    ): List<PhaseRow> {
        val phases = PlanEngine.firstCycle(audios.size, plan, settings).filter { it.length > 0 }
        return phases.map { phase ->
            val inPhase = log.filter {
                val day = PlanEngine.epochDayOf(it.eventMs, zone)
                day >= phase.startEpochDay && day <= phase.endInclusiveEpochDay
            }
            PhaseRow(
                phase = phase,
                audio = PlanEngine.audioForPhase(phase.index, audios, plan),
                planned = PlanEngine.activeDayCount(phase, settings) * settings.timesOfDay.size,
                completed = inPhase.count { it.isCompletedSession },
                missed = inPhase.count { it.isMissedSession },
                lastSessionMs = inPhase.filter { it.isCompletedSession }.maxOfOrNull { it.startedAtMs },
                nextSessionMs = next?.takeIf {
                    it.epochDay >= phase.startEpochDay && it.epochDay <= phase.endInclusiveEpochDay
                }?.epochMs,
                isCurrent = currentIndex == phase.index,
                avgActivityPercent = inPhase.filter { it.isCompletedSession }
                    .mapNotNull { it.activityPercent }
                    .takeIf { it.isNotEmpty() }
                    ?.let { it.sum() / it.size },
                voiceCount = inPhase.count { it.isCompletedSession && it.reaction == SessionReaction.VOICE },
                mimicCount = inPhase.count { it.isCompletedSession && it.reaction == SessionReaction.MIMIC },
                noneCount = inPhase.count { it.isCompletedSession && it.reaction == SessionReaction.NONE },
                lastError = inPhase.filter { it.status == SessionStatus.FAILED && !it.errorMessage.isNullOrBlank() }
                    .maxByOrNull { it.eventMs }?.errorMessage
            )
        }
    }

    /** The week with the highest average camera activity, or null when no week has a score. */
    fun mostActiveRow(rows: List<PhaseRow>): PhaseRow? =
        rows.filter { it.avgActivityPercent != null }.maxByOrNull { it.avgActivityPercent ?: 0 }

    /** Completed / planned across all weeks so far, as a 0..100 percentage. Null if nothing is planned yet. */
    fun overallCompletionPercent(rows: List<PhaseRow>): Int? {
        val planned = rows.sumOf { it.planned }
        if (planned <= 0) return null
        val completed = rows.sumOf { it.completed }
        return ((completed * 100L) / planned).toInt().coerceIn(0, 100)
    }
}

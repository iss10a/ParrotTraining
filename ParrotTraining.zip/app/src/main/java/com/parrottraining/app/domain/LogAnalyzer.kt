package com.parrottraining.app.domain

import java.time.ZoneId

data class PhaseRow(
    val phase: PhaseInfo,
    val audio: AudioItem?,
    val planned: Int,
    val completed: Int,
    val missed: Int,
    val lastSessionMs: Long?,
    val nextSessionMs: Long?,
    val isCurrent: Boolean
)

object LogAnalyzer {
    /** [plan] must already be normalized (and started "today" when the plan has not started yet). */
    fun rows(
        audios: List<AudioItem>,
        plan: PlanState,
        settings: Settings,
        log: List<SessionRecord>,
        zone: ZoneId,
        next: SessionSlot?,
        currentIndex: Int?
    ): List<PhaseRow> {
        val phases = PlanEngine.firstCycle(audios.size, plan, settings).filter { it.length > 0 }
        return phases.map { phase ->
            val inPhase = log.filter {
                val day = PlanEngine.epochDayOf(it.eventMs, zone)
                day >= phase.startEpochDay && day <= phase.endInclusiveEpochDay
            }
            PhaseRow(
                phase = phase,
                audio = PlanEngine.audioForPhase(phase.index, audios, plan),
                planned = phase.length * settings.timesOfDay.size,
                completed = inPhase.count { it.isCompletedSession },
                missed = inPhase.count { it.isMissedSession },
                lastSessionMs = inPhase.filter { it.isCompletedSession }.maxOfOrNull { it.startedAtMs },
                nextSessionMs = next?.takeIf {
                    it.epochDay >= phase.startEpochDay && it.epochDay <= phase.endInclusiveEpochDay
                }?.epochMs,
                isCurrent = currentIndex == phase.index
            )
        }
    }
}

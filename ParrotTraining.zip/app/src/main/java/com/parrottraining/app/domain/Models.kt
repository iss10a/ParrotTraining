package com.parrottraining.app.domain

import java.time.LocalDate

enum class PlanStatus { NOT_STARTED, ACTIVE, PAUSED }

enum class MissedPolicy { IGNORE, MAKEUP }

enum class SessionType { SCHEDULED, MANUAL, TEST, MAKEUP, PREVIEW, VIDEO }

enum class SessionStatus { RUNNING, COMPLETED, STOPPED, INTERRUPTED, MISSED, FAILED }

/** How the parrot reacted in a session, as noted by the owner. */
enum class SessionReaction { VOICE, MIMIC, NONE }

/** One audio file. The order of the audio list defines the order of the weeks. */
data class AudioItem(
    val id: String,
    val uri: String,
    val name: String,
    val durationMs: Long = 0L,
    /** True for a video file (shown on screen at session time; its sound is the training audio). */
    val isVideo: Boolean = false
)

data class Settings(
    val phaseDays: Int = 7,
    val sessionMinutes: Int = 10,
    /** Minutes since local midnight, e.g. 360 = 06:00. */
    val timesOfDay: List<Int> = listOf(6 * 60, 18 * 60),
    /** Own session length (minutes) for a given time of day. Times not listed use [sessionMinutes]. */
    val minutesByTime: Map<Int, Int> = emptyMap(),
    val volumePercent: Int = 100,
    val autoRepeat: Boolean = false,
    val missedPolicy: MissedPolicy = MissedPolicy.IGNORE,
    /** ISO day-of-week values: 1 = Monday ... 7 = Sunday. Training only runs on these days. */
    val activeDaysOfWeek: Set<Int> = (1..7).toSet(),
    /** Short vibration when a real (non-preview) session starts, in case the phone is out of sight. */
    val vibrateOnStart: Boolean = false,
    /** Silent front-camera recording during every session (kept 7 days in the gallery). */
    val recordSessions: Boolean = false,
    /** 720p instead of 480p. */
    val recordHighQuality: Boolean = false,
    /** Video schedule (separate from the audio times): minutes since midnight, e.g. 540 = 09:00. May be empty. */
    val videoTimes: List<Int> = emptyList(),
    /** Only used when a video's own length cannot be read. Video sessions normally last as long as their videos. */
    val videoMinutes: Int = 10,
    /** ISO day-of-week values on which videos run (1 = Monday ... 7 = Sunday). */
    val videoDaysOfWeek: Set<Int> = (1..7).toSet(),
    /** After each finished session, a quiet notification asks how the parrot reacted (3 quick buttons). */
    val askReaction: Boolean = true
) {

    /** Session length for the slot at [timeOfDay] (minutes since midnight). */
    fun minutesFor(timeOfDay: Int): Int = (minutesByTime[timeOfDay] ?: sessionMinutes).coerceIn(1, 240)

    fun sanitized(): Settings {
        val times = timesOfDay.map { it.coerceIn(0, 1439) }.distinct().sorted().ifEmpty { listOf(6 * 60) }
        return copy(
            minutesByTime = minutesByTime.filterKeys { it in times }.mapValues { it.value.coerceIn(1, 240) },
            phaseDays = phaseDays.coerceIn(1, 365),
            sessionMinutes = sessionMinutes.coerceIn(1, 240),
            timesOfDay = times,
            volumePercent = volumePercent.coerceIn(0, 100),
            activeDaysOfWeek = activeDaysOfWeek.filter { it in 1..7 }.toSet().ifEmpty { (1..7).toSet() },
            videoTimes = videoTimes.map { it.coerceIn(0, 1439) }.distinct().sorted(),
            videoMinutes = videoMinutes.coerceIn(1, 240),
            videoDaysOfWeek = videoDaysOfWeek.filter { it in 1..7 }.toSet().ifEmpty { (1..7).toSet() }
        )
    }
}

/**
 * Plan state. Phase i (week i) uses audios[i] unless [audioOverrides] contains i.
 * [phaseLengthOverrides] lets "skip" / "repeat week" change the length of a single phase.
 */
data class PlanState(
    val status: PlanStatus = PlanStatus.NOT_STARTED,
    val startEpochDay: Long = LocalDate.now().toEpochDay(),
    val phaseLengthOverrides: Map<Int, Int> = emptyMap(),
    val audioOverrides: Map<Int, String> = emptyMap(),
    /** Extra audio ids for a week (besides its main audio). A session plays main + extras in turn. */
    val extraAudios: Map<Int, List<String>> = emptyMap(),
    /** Video ids shown in a week (same weeks as the audio plan), at the video times on the video days. */
    val videoByPhase: Map<Int, List<String>> = emptyMap(),
    val pausedOnEpochDay: Long? = null,
    /** Incremented on every user change; alarms carry it so stale alarms can be detected. */
    val version: Long = 0L,
    /** Sessions up to this instant were already evaluated for "missed" detection. */
    val lastCheckedAtMs: Long = 0L,
    val pendingMakeups: Int = 0
)

data class AppData(
    val audios: List<AudioItem> = emptyList(),
    /** Video library (kept apart from [audios] so the audio plan is unchanged). Items have isVideo = true. */
    val videos: List<AudioItem> = emptyList(),
    val settings: Settings = Settings(),
    val plan: PlanState = PlanState()
)

data class SessionRecord(
    val id: String,
    val type: SessionType,
    val status: SessionStatus,
    /** Scheduled instant, 0 for manual sessions. */
    val slotAtMs: Long,
    val startedAtMs: Long,
    val plannedMs: Long,
    val playedMs: Long,
    val audioId: String?,
    val audioName: String,
    val phaseIndex: Int,
    val errorMessage: String? = null,
    /** Share of the session in which the camera saw movement (0..100). Null when the camera was off or too short. */
    val activityPercent: Int? = null,
    /** The owner's note on how the parrot reacted. Null until noted. */
    val reaction: SessionReaction? = null
) {
    val eventMs: Long get() = if (slotAtMs > 0) slotAtMs else startedAtMs

    val isCompletedSession: Boolean
        get() = status == SessionStatus.COMPLETED &&
            (type == SessionType.SCHEDULED || type == SessionType.MAKEUP || type == SessionType.MANUAL)

    val isMissedSession: Boolean
        get() = status == SessionStatus.MISSED || (status == SessionStatus.FAILED && type == SessionType.SCHEDULED)
}

/** Resolved audio for a session. phaseIndex is -1 when the plan is not running. */
data class Resolved(
    val audio: AudioItem,
    val phaseIndex: Int,
    /** All audios of the week in play order (main first). */
    val playlist: List<AudioItem> = listOf(audio)
)

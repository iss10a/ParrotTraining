package com.parrottraining.app.domain

import java.time.LocalDate

enum class PlanStatus { NOT_STARTED, ACTIVE, PAUSED }

enum class MissedPolicy { IGNORE, MAKEUP }

enum class SessionType { SCHEDULED, MANUAL, TEST, MAKEUP, PREVIEW }

enum class SessionStatus { RUNNING, COMPLETED, STOPPED, INTERRUPTED, MISSED, FAILED }

/** One audio file. The order of the audio list defines the order of the weeks. */
data class AudioItem(
    val id: String,
    val uri: String,
    val name: String,
    val durationMs: Long = 0L
)

data class Settings(
    val phaseDays: Int = 7,
    val sessionMinutes: Int = 10,
    /** Minutes since local midnight, e.g. 360 = 06:00. */
    val timesOfDay: List<Int> = listOf(6 * 60, 18 * 60),
    val volumePercent: Int = 100,
    val autoRepeat: Boolean = false,
    val missedPolicy: MissedPolicy = MissedPolicy.IGNORE,
    /** ISO day-of-week values: 1 = Monday ... 7 = Sunday. Training only runs on these days. */
    val activeDaysOfWeek: Set<Int> = (1..7).toSet(),
    /** Short vibration when a real (non-preview) session starts, in case the phone is out of sight. */
    val vibrateOnStart: Boolean = false
) {
    fun sanitized(): Settings = copy(
        phaseDays = phaseDays.coerceIn(1, 365),
        sessionMinutes = sessionMinutes.coerceIn(1, 240),
        timesOfDay = timesOfDay.map { it.coerceIn(0, 1439) }.distinct().sorted().ifEmpty { listOf(6 * 60) },
        volumePercent = volumePercent.coerceIn(0, 100),
        activeDaysOfWeek = activeDaysOfWeek.filter { it in 1..7 }.toSet().ifEmpty { (1..7).toSet() }
    )
}

/**
 * Plan state. Phase i (week i) uses audios[i] unless [audioOverrides] contains i.
 * [phaseLengthOverrides] lets "skip" / "repeat week" change the length of a single phase.
 */
data class PlanState(
    val status: PlanStatus = PlanStatus.NOT_STARTED,
    val startEpochDay: Long = LocalDate.now().toEpochDay(),
    val phaseLengthOverrides: Map<Int, Int> = emptyMap(),
    val audioOverrides: Map<Int, String> = emptyMap(),
    val pausedOnEpochDay: Long? = null,
    /** Incremented on every user change; alarms carry it so stale alarms can be detected. */
    val version: Long = 0L,
    /** Sessions up to this instant were already evaluated for "missed" detection. */
    val lastCheckedAtMs: Long = 0L,
    val pendingMakeups: Int = 0
)

data class AppData(
    val audios: List<AudioItem> = emptyList(),
    val settings: Settings = Settings(),
    val plan: PlanState = PlanState()
)

data class SessionRecord(
    val id: String,
    val type: SessionType,
    val status: SessionStatus,
    /** Scheduled instant, 0 for manual sessions. */
    val slotAtMs: Long,
    val startedAtMs: Long,
    val plannedMs: Long,
    val playedMs: Long,
    val audioId: String?,
    val audioName: String,
    val phaseIndex: Int,
    val errorMessage: String? = null
) {
    val eventMs: Long get() = if (slotAtMs > 0) slotAtMs else startedAtMs

    val isCompletedSession: Boolean
        get() = status == SessionStatus.COMPLETED &&
            (type == SessionType.SCHEDULED || type == SessionType.MAKEUP || type == SessionType.MANUAL)

    val isMissedSession: Boolean
        get() = status == SessionStatus.MISSED || (status == SessionStatus.FAILED && type == SessionType.SCHEDULED)
}

/** Resolved audio for a session. phaseIndex is -1 when the plan is not running. */
data class Resolved(val audio: AudioItem, val phaseIndex: Int)

package com.parrottraining.app.domain

import java.nio.ByteBuffer

/**
 * Measures how much the picture moves during a session (a simple "parrot activity" score).
 *
 * Every analysed frame is shrunk to a small grid of average brightness values and compared with the previous
 * frame. A frame counts as "active" when enough grid cells changed (the bird moved). Frames where almost the
 * whole picture changed at once (camera exposure jump, lights switched) are ignored, not counted either way.
 * Pure Kotlin so it can be unit tested without a phone.
 */
class MotionAnalyzer(
    private val gridW: Int = GRID_W,
    private val gridH: Int = GRID_H,
    /** A cell counts as changed when its average brightness moved by more than this (0..255). */
    private val cellThreshold: Int = 12,
    /** A frame is active when at least this share of the cells changed. */
    private val activeFraction: Double = 0.008,
    /** A frame is ignored (lighting jump) when more than this share of the cells changed. */
    private val ignoreAboveFraction: Double = 0.6
) {
    private var prev: IntArray? = null
    private var valid = 0
    private var active = 0

    /** Shrinks the brightness (Y) plane to the grid and feeds it in. [rowStride] is the plane's bytes per row. */
    @Synchronized
    fun addLumaFrame(y: ByteBuffer, width: Int, height: Int, rowStride: Int) {
        addGrid(downsample(y, width, height, rowStride))
    }

    internal fun downsample(y: ByteBuffer, width: Int, height: Int, rowStride: Int): IntArray {
        val grid = IntArray(gridW * gridH)
        for (gy in 0 until gridH) {
            val y0 = gy * height / gridH
            val y1 = maxOf(y0 + 1, (gy + 1) * height / gridH)
            for (gx in 0 until gridW) {
                val x0 = gx * width / gridW
                val x1 = maxOf(x0 + 1, (gx + 1) * width / gridW)
                var sum = 0
                var n = 0
                var yy = y0
                while (yy < y1) {
                    var xx = x0
                    while (xx < x1) {
                        val idx = yy * rowStride + xx
                        if (idx < y.limit()) {
                            sum += y.get(idx).toInt() and 0xFF
                            n++
                        }
                        xx += 2
                    }
                    yy += 2
                }
                grid[gy * gridW + gx] = if (n > 0) sum / n else 0
            }
        }
        return grid
    }

    /** Feeds one already-shrunk frame (size gridW * gridH). */
    @Synchronized
    fun addGrid(grid: IntArray) {
        val p = prev
        prev = grid
        if (p == null || p.size != grid.size) return
        var changed = 0
        for (i in grid.indices) {
            if (kotlin.math.abs(grid[i] - p[i]) > cellThreshold) changed++
        }
        val fraction = changed.toDouble() / grid.size
        if (fraction > ignoreAboveFraction) return
        valid++
        if (fraction >= activeFraction) active++
    }

    /** Share of analysed frames in which something moved (0..100), or null when there were too few frames. */
    @Synchronized
    fun activityPercent(): Int? {
        if (valid < MIN_FRAMES) return null
        return ((active * 100L) / valid).toInt().coerceIn(0, 100)
    }

    companion object {
        const val GRID_W = 32
        const val GRID_H = 24
        const val MIN_FRAMES = 10

        /** One analysed frame every this many nanoseconds (4 per second is plenty and keeps the battery calm). */
        const val FRAME_INTERVAL_NS = 250_000_000L
    }
}

package com.parrottraining.app.domain

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

data class PhaseInfo(val index: Int, val startEpochDay: Long, val length: Int) {
    val endExclusiveEpochDay: Long get() = startEpochDay + length
    val endInclusiveEpochDay: Long get() = startEpochDay + length - 1
}

sealed interface PlanPosition {
    data object NotStarted : PlanPosition
    data class BeforeStart(val startEpochDay: Long) : PlanPosition
    data object NoAudio : PlanPosition
    data object Completed : PlanPosition
    data class Active(
        val phaseIndex: Int,
        val phaseCount: Int,
        val dayInPhase: Int,
        val phaseLength: Int,
        val audio: AudioItem,
        val phaseStartEpochDay: Long,
        val cycle: Long
    ) : PlanPosition {
        val phaseEndEpochDay: Long get() = phaseStartEpochDay + phaseLength - 1
    }
}

data class SessionSlot(
    val epochMs: Long,
    val epochDay: Long,
    val minuteOfDay: Int,
    val position: PlanPosition.Active
)

/**
 * Pure (Android-free) plan logic: which week is it, which audio belongs to a day,
 * when is the next session. Everything derives from the plan start date, the phase length,
 * the audio order and a few overrides, so it never relies on stored timestamps of future sessions.
 */
object PlanEngine {
    const val LATE_GRACE_MS = 5 * 60_000L
    const val LATE_PLAY_LIMIT_MS = 3 * 60_000L
    const val EARLY_LIMIT_MS = 60_000L
    private const val MAX_SCAN_DAYS = 1500
    private const val MAX_BACKFILL_DAYS = 400L

    fun epochDayOf(ms: Long, zone: ZoneId): Long =
        Instant.ofEpochMilli(ms).atZone(zone).toLocalDate().toEpochDay()

    fun slotMillis(epochDay: Long, minuteOfDay: Int, zone: ZoneId): Long =
        LocalDate.ofEpochDay(epochDay)
            .atTime(minuteOfDay / 60, minuteOfDay % 60)
            .atZone(zone)
            .toInstant()
            .toEpochMilli()

    /** ISO day-of-week (1 = Monday ... 7 = Sunday) of [epochDay] is one of the user's active training days. */
    fun isActiveDay(epochDay: Long, settings: Settings): Boolean =
        LocalDate.ofEpochDay(epochDay).dayOfWeek.value in settings.activeDaysOfWeek

    /** How many days inside [phase] are active training days — used to compute "planned" session counts. */
    fun activeDayCount(phase: PhaseInfo, settings: Settings): Int {
        if (settings.activeDaysOfWeek.size == 7) return phase.length
        var count = 0
        for (d in phase.startEpochDay until phase.endExclusiveEpochDay) {
            if (isActiveDay(d, settings)) count++
        }
        return count
    }

    // ---------------------------------------------------------------- phases

    fun phaseLength(index: Int, plan: PlanState, settings: Settings): Int =
        (plan.phaseLengthOverrides[index] ?: settings.phaseDays).coerceAtLeast(0)

    /** The phases of the first (current) cycle, laid out from the plan start date. */
    fun firstCycle(audioCount: Int, plan: PlanState, settings: Settings): List<PhaseInfo> {
        val out = ArrayList<PhaseInfo>(audioCount)
        var cursor = plan.startEpochDay
        for (i in 0 until audioCount) {
            val len = phaseLength(i, plan, settings)
            out.add(PhaseInfo(i, cursor, len))
            cursor += len
        }
        return out
    }

    fun audioForPhase(index: Int, audios: List<AudioItem>, plan: PlanState): AudioItem? {
        val overrideId = plan.audioOverrides[index]
        val overridden = if (overrideId != null) audios.firstOrNull { it.id == overrideId } else null
        return overridden ?: audios.getOrNull(index)
    }

    fun isAudioUsed(audioId: String, audios: List<AudioItem>, plan: PlanState): Boolean =
        audios.indices.any { audioForPhase(it, audios, plan)?.id == audioId }

    /**
     * When auto-repeat is on and the cycle is over, moves the start date to the beginning of the
     * cycle that contains [todayEpochDay] and drops one-off length overrides.
     */
    fun normalize(plan: PlanState, settings: Settings, audioCount: Int, todayEpochDay: Long): PlanState {
        if (plan.status != PlanStatus.ACTIVE || !settings.autoRepeat || audioCount == 0) return plan
        val total = firstCycle(audioCount, plan, settings).sumOf { it.length }
        val end = plan.startEpochDay + total
        if (todayEpochDay < end) return plan
        val cycleLen = audioCount.toLong() * settings.phaseDays
        val newStart = end + Math.floorDiv(todayEpochDay - end, cycleLen) * cycleLen
        return plan.copy(startEpochDay = newStart, phaseLengthOverrides = emptyMap())
    }

    // -------------------------------------------------------------- position

    fun positionOn(epochDay: Long, audios: List<AudioItem>, plan: PlanState, settings: Settings): PlanPosition {
        if (plan.status == PlanStatus.NOT_STARTED) return PlanPosition.NotStarted
        if (audios.isEmpty()) return PlanPosition.NoAudio
        val offset = epochDay - plan.startEpochDay
        if (offset < 0) return PlanPosition.BeforeStart(plan.startEpochDay)

        val phases = firstCycle(audios.size, plan, settings)
        val total = phases.sumOf { it.length }.toLong()
        if (offset < total) {
            val p = phases.first { epochDay >= it.startEpochDay && epochDay < it.endExclusiveEpochDay }
            return active(p.index, p.startEpochDay, p.length, epochDay, audios, plan, 0L)
        }
        if (!settings.autoRepeat) return PlanPosition.Completed

        // Later cycles use the default length for every phase.
        val days = settings.phaseDays.toLong()
        val cycleLen = audios.size * days
        val rem = (offset - total) % cycleLen
        val idx = (rem / days).toInt()
        val dayIdx = rem % days
        val cycle = (offset - total) / cycleLen + 1
        return active(idx, epochDay - dayIdx, settings.phaseDays, epochDay, audios, plan, cycle)
    }

    private fun active(
        idx: Int, phaseStart: Long, len: Int, day: Long,
        audios: List<AudioItem>, plan: PlanState, cycle: Long
    ): PlanPosition.Active = PlanPosition.Active(
        phaseIndex = idx,
        phaseCount = audios.size,
        dayInPhase = (day - phaseStart + 1).toInt(),
        phaseLength = len,
        audio = audioForPhase(idx, audios, plan) ?: audios[idx],
        phaseStartEpochDay = phaseStart,
        cycle = cycle
    )

    /** Position used for display: a paused plan is frozen on the day it was paused. */
    fun currentPosition(todayEpochDay: Long, audios: List<AudioItem>, plan: PlanState, settings: Settings): PlanPosition {
        val paused = plan.pausedOnEpochDay
        val ref = if (plan.status == PlanStatus.PAUSED && paused != null) paused else todayEpochDay
        return positionOn(ref, audios, plan, settings)
    }

    // -------------------------------------------------------------- sessions

    fun nextSession(
        afterMs: Long, zone: ZoneId,
        audios: List<AudioItem>, plan: PlanState, settings: Settings
    ): SessionSlot? {
        if (plan.status != PlanStatus.ACTIVE || settings.timesOfDay.isEmpty()) return null
        val startDay = epochDayOf(afterMs, zone)
        val times = settings.timesOfDay.sorted()
        for (d in 0..MAX_SCAN_DAYS) {
            val day = startDay + d
            when (val pos = positionOn(day, audios, plan, settings)) {
                is PlanPosition.Active -> {
                    if (!isActiveDay(day, settings)) continue
                    for (t in times) {
                        val ms = slotMillis(day, t, zone)
                        if (ms > afterMs) return SessionSlot(ms, day, t, pos)
                    }
                }
                is PlanPosition.BeforeStart -> Unit
                else -> return null
            }
        }
        return null
    }

    /** All sessions planned in (fromExclusiveMs, toInclusiveMs]. */
    fun slotsBetween(
        fromExclusiveMs: Long, toInclusiveMs: Long, zone: ZoneId,
        audios: List<AudioItem>, plan: PlanState, settings: Settings
    ): List<SessionSlot> {
        if (plan.status != PlanStatus.ACTIVE || toInclusiveMs <= fromExclusiveMs || settings.timesOfDay.isEmpty()) {
            return emptyList()
        }
        val endDay = epochDayOf(toInclusiveMs, zone)
        val startDay = maxOf(epochDayOf(fromExclusiveMs, zone), endDay - MAX_BACKFILL_DAYS)
        val times = settings.timesOfDay.sorted()
        val out = ArrayList<SessionSlot>()
        for (day in startDay..endDay) {
            val pos = positionOn(day, audios, plan, settings) as? PlanPosition.Active ?: continue
            if (!isActiveDay(day, settings)) continue
            for (t in times) {
                val ms = slotMillis(day, t, zone)
                if (ms > fromExclusiveMs && ms <= toInclusiveMs) out.add(SessionSlot(ms, day, t, pos))
            }
        }
        return out.sortedBy { it.epochMs }
    }

    /** True if [slotMs] is (still) a planned session instant under the current plan and settings. */
    fun isValidSlot(slotMs: Long, zone: ZoneId, audios: List<AudioItem>, plan: PlanState, settings: Settings): Boolean {
        if (plan.status != PlanStatus.ACTIVE) return false
        val day = epochDayOf(slotMs, zone)
        if (positionOn(day, audios, plan, settings) !is PlanPosition.Active) return false
        if (!isActiveDay(day, settings)) return false
        return settings.timesOfDay.any { slotMillis(day, it, zone) == slotMs }
    }

    // ------------------------------------------------------------ plan edits

    fun start(plan: PlanState, startEpochDay: Long, nowMs: Long): PlanState = plan.copy(
        status = PlanStatus.ACTIVE,
        startEpochDay = startEpochDay,
        phaseLengthOverrides = emptyMap(),
        pausedOnEpochDay = null,
        pendingMakeups = 0,
        lastCheckedAtMs = nowMs
    )

    fun pause(plan: PlanState, todayEpochDay: Long): PlanState =
        if (plan.status == PlanStatus.ACTIVE) {
            plan.copy(status = PlanStatus.PAUSED, pausedOnEpochDay = todayEpochDay, pendingMakeups = 0)
        } else plan

    /** Resuming shifts the start date by the number of paused days, so no training day is lost. */
    fun resume(plan: PlanState, todayEpochDay: Long, nowMs: Long): PlanState {
        if (plan.status != PlanStatus.PAUSED) return plan
        val pausedOn = plan.pausedOnEpochDay ?: todayEpochDay
        val base = maxOf(pausedOn, plan.startEpochDay)
        val shift = maxOf(0L, todayEpochDay - base)
        return plan.copy(
            status = PlanStatus.ACTIVE,
            startEpochDay = plan.startEpochDay + shift,
            pausedOnEpochDay = null,
            lastCheckedAtMs = nowMs,
            pendingMakeups = 0
        )
    }

    private fun refDay(plan: PlanState, today: Long): Long {
        val paused = plan.pausedOnEpochDay
        return if (plan.status == PlanStatus.PAUSED && paused != null) paused else today
    }

    /** Ends the current phase today, so the next phase starts today. */
    fun skipCurrent(plan: PlanState, audios: List<AudioItem>, settings: Settings, todayEpochDay: Long): PlanState {
        if (plan.status == PlanStatus.NOT_STARTED) return plan
        val ref = refDay(plan, todayEpochDay)
        val eff = normalize(plan, settings, audios.size, ref)
        val pos = positionOn(ref, audios, eff, settings) as? PlanPosition.Active ?: return plan
        if (pos.cycle != 0L) return eff
        val elapsed = (ref - pos.phaseStartEpochDay).toInt()
        return eff.copy(phaseLengthOverrides = eff.phaseLengthOverrides + (pos.phaseIndex to elapsed))
    }

    /** Extends the current phase by one more phase length; later phases move accordingly. */
    fun repeatCurrent(plan: PlanState, audios: List<AudioItem>, settings: Settings, todayEpochDay: Long): PlanState {
        if (plan.status == PlanStatus.NOT_STARTED) return plan
        val ref = refDay(plan, todayEpochDay)
        val eff = normalize(plan, settings, audios.size, ref)
        val pos = positionOn(ref, audios, eff, settings) as? PlanPosition.Active ?: return plan
        if (pos.cycle != 0L) return eff
        val newLen = pos.phaseLength + settings.phaseDays
        return eff.copy(phaseLengthOverrides = eff.phaseLengthOverrides + (pos.phaseIndex to newLen))
    }
}

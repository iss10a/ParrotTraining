package com.parrottraining.app.domain

/** Small pure helpers for the session camera recorder (kept apart from Android code so they can be unit tested). */
object RecorderMath {

    /** Rotation to write into the video so it plays upright: sensor orientation minus the screen rotation. */
    fun orientationHint(sensorOrientation: Int, displayRotationDegrees: Int): Int =
        ((sensorOrientation - displayRotationDegrees) % 360 + 360) % 360

    /**
     * Picks the largest recording size whose shorter side does not exceed [targetShortSide]
     * (480 = normal, 720 = high quality). Falls back to the smallest supported size, then to 640x480.
     */
    fun chooseSize(sizes: List<Pair<Int, Int>>, targetShortSide: Int): Pair<Int, Int> {
        if (sizes.isEmpty()) return 640 to 480
        val fitting = sizes.filter { minOf(it.first, it.second) <= targetShortSide }
        if (fitting.isEmpty()) return sizes.minByOrNull { it.first.toLong() * it.second } ?: (640 to 480)
        return fitting.maxByOrNull { it.first.toLong() * it.second } ?: (640 to 480)
    }
}

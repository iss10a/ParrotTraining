package com.parrottraining.app.domain

/** Small pure helpers for the session camera recorder (kept apart from Android code so they can be unit tested). */
object RecorderMath {

    /** Horizontal field of view (degrees) of a lens: wider means more of the room is visible. */
    fun fieldOfViewDegrees(sensorWidthMm: Float, focalLengthMm: Float): Double =
        Math.toDegrees(2.0 * Math.atan(sensorWidthMm / (2.0 * focalLengthMm)))

    /**
     * Like [chooseSize], but prefers sizes with the sensor's own shape (e.g. 4:3) because a different shape
     * crops the edges of the picture and shows less of the cage.
     */
    fun chooseWideSize(sizes: List<Pair<Int, Int>>, targetShortSide: Int, sensorWidth: Int, sensorHeight: Int): Pair<Int, Int> {
        if (sensorWidth <= 0 || sensorHeight <= 0) return chooseSize(sizes, targetShortSide)
        val ratio = sensorWidth.toDouble() / sensorHeight
        val sameShape = sizes.filter { Math.abs(it.first.toDouble() / it.second - ratio) < 0.02 }
        return if (sameShape.isNotEmpty()) chooseSize(sameShape, targetShortSide) else chooseSize(sizes, targetShortSide)
    }

    /** Rotation to write into the video so it plays upright: sensor orientation minus the screen rotation. */
    fun orientationHint(sensorOrientation: Int, displayRotationDegrees: Int): Int =
        ((sensorOrientation - displayRotationDegrees) % 360 + 360) % 360

    /**
     * Picks the largest recording size whose shorter side does not exceed [targetShortSide]
     * (480 = normal, 720 = high quality). Falls back to the smallest supported size, then to 640x480.
     */
    fun chooseSize(sizes: List<Pair<Int, Int>>, targetShortSide: Int): Pair<Int, Int> {
        if (sizes.isEmpty()) return 640 to 480
        val fitting = sizes.filter { minOf(it.first, it.second) <= targetShortSide }
        if (fitting.isEmpty()) return sizes.minByOrNull { it.first.toLong() * it.second } ?: (640 to 480)
        return fitting.maxByOrNull { it.first.toLong() * it.second } ?: (640 to 480)
    }
}

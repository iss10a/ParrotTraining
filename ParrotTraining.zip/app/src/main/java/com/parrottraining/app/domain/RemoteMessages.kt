package com.parrottraining.app.domain

import java.util.Random

/** Text of the notifications sent to the owner's other phone. Pure, so it can be unit tested. */
object RemoteMessages {

    fun sessionStarted(
        parrotName: String,
        type: SessionType,
        hasVideo: Boolean,
        itemNames: List<String>,
        durationMs: Long,
        phaseIndex: Int
    ): Pair<String, String> {
        val who = parrotName.trim()
        val title = if (who.isEmpty()) "🦜 بدأت جلسة التدريب" else "🦜 بدأت جلسة تدريب $who"
        val parts = mutableListOf<String>()
        parts += (if (hasVideo) "فيديو: " else "صوت: ") + itemNames.joinToString(" + ")
        parts += "المدة ${minutesOf(durationMs)} دقيقة"
        if (phaseIndex >= 0) parts += "الأسبوع ${phaseIndex + 1}"
        when (type) {
            SessionType.MANUAL -> parts += "تشغيل يدوي"
            SessionType.TEST -> parts += "تجربة"
            SessionType.MAKEUP -> parts += "جلسة تعويضية"
            else -> Unit
        }
        return title to parts.joinToString(" • ")
    }

    fun sessionEnded(parrotName: String, status: SessionStatus, playedMs: Long): Pair<String, String> {
        val who = parrotName.trim()
        val done = status == SessionStatus.COMPLETED
        val title = (if (done) "✅ انتهت جلسة التدريب" else "⏹ توقفت جلسة التدريب") + if (who.isEmpty()) "" else " ($who)"
        return title to "المدة المشغّلة ${minutesOf(playedMs)} دقيقة"
    }

    private fun minutesOf(ms: Long): Long = ((ms + 30_000L) / 60_000L).coerceAtLeast(if (ms > 0) 1L else 0L)

    private const val TOPIC_CHARS = "abcdefghijklmnopqrstuvwxyz0123456789"

    /** A hard-to-guess topic name: whoever knows it can read the notifications, so it works like a password. */
    fun randomTopic(random: Random): String =
        "parrot-" + (1..14).map { TOPIC_CHARS[random.nextInt(TOPIC_CHARS.length)] }.joinToString("")
}

package com.parrottraining.app.domain

/**
 * Decides what to do when a new session is requested while another one may already be playing.
 * Two sessions must never play at the same time.
 */
object SessionGuard {
    enum class Decision { START, REPLACE_CURRENT, REJECT_INCOMING }

    fun onNewSession(current: SessionType?, incoming: SessionType): Decision = when {
        current == null -> Decision.START
        // A short audio preview must never cut off a real training session.
        incoming == SessionType.PREVIEW && current != SessionType.PREVIEW -> Decision.REJECT_INCOMING
        // Everything else: stop the old one, then start the new one.
        else -> Decision.REPLACE_CURRENT
    }
}

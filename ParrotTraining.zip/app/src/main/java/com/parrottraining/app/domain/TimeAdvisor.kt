package com.parrottraining.app.domain

import java.time.ZoneId

/** What happened in the finished scheduled sessions of one daily time slot. */
data class SlotStats(
    val minuteOfDay: Int,
    val sessions: Int,
    /** Sessions of this slot that have a camera activity score. */
    val activityCount: Int,
    val avgActivityPercent: Int?,
    /** Sessions of this slot the owner noted a reaction for, and how many of them were not "no reaction". */
    val noted: Int,
    val responded: Int
) {
    val responsePercent: Int? get() = if (noted > 0) responded * 100 / noted else null
}

enum class AdviceBasis { ACTIVITY, RESPONSE }

/** [best] is only set when the slots clearly differ and each compared slot has enough sessions behind it. */
data class TimeAdvice(val slots: List<SlotStats>, val best: SlotStats?, val basis: AdviceBasis?)

/** Compares the daily training times, so the owner can see which time the parrot is livelier at. */
object TimeAdvisor {
    const val MIN_SESSIONS = 3
    const val MIN_ACTIVITY_GAP = 5
    const val MIN_RESPONSE_GAP = 15

    fun analyze(log: List<SessionRecord>, zone: ZoneId): TimeAdvice {
        val groups = log
            .filter { it.isCompletedSession && it.type == SessionType.SCHEDULED && it.slotAtMs > 0 }
            .groupBy { PlanEngine.minuteOfDayOf(it.slotAtMs, zone) }
        val slots = groups.map { (minute, list) ->
            val acts = list.mapNotNull { it.activityPercent }
            val notes = list.mapNotNull { it.reaction }
            SlotStats(
                minuteOfDay = minute,
                sessions = list.size,
                activityCount = acts.size,
                avgActivityPercent = if (acts.isEmpty()) null else acts.sum() / acts.size,
                noted = notes.size,
                responded = notes.count { it != SessionReaction.NONE }
            )
        }.sortedBy { it.minuteOfDay }

        val byActivity = slots.filter { it.activityCount >= MIN_SESSIONS && it.avgActivityPercent != null }
        if (byActivity.size >= 2) {
            val best = byActivity.maxByOrNull { it.avgActivityPercent ?: 0 }
            val low = byActivity.minOf { it.avgActivityPercent ?: 0 }
            if (best != null && (best.avgActivityPercent ?: 0) - low >= MIN_ACTIVITY_GAP) {
                return TimeAdvice(slots, best, AdviceBasis.ACTIVITY)
            }
        }
        val byResponse = slots.filter { it.noted >= MIN_SESSIONS && it.responsePercent != null }
        if (byResponse.size >= 2) {
            val best = byResponse.maxByOrNull { it.responsePercent ?: 0 }
            val low = byResponse.minOf { it.responsePercent ?: 0 }
            if (best != null && (best.responsePercent ?: 0) - low >= MIN_RESPONSE_GAP) {
                return TimeAdvice(slots, best, AdviceBasis.RESPONSE)
            }
        }
        return TimeAdvice(slots, null, null)
    }
}

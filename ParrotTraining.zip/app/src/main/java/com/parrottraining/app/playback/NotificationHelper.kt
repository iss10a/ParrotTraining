package com.parrottraining.app.playback

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.parrottraining.app.MainActivity
import com.parrottraining.app.R

object NotificationHelper {
    const val CHANNEL_PLAYBACK = "training_playback"
    const val CHANNEL_ALERTS = "training_alerts"
    const val CHANNEL_VIDEO = "training_video"
    const val NOTIF_ID_PLAYBACK = 1001
    private const val NOTIF_ID_ALERT = 1002
    private const val NOTIF_ID_VIDEO = 1003
    private const val NOTIF_ID_REACTION = 1004

    /** Quiet channels: no sound, no vibration, low importance. */
    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val playback = NotificationChannel(
            CHANNEL_PLAYBACK, "جلسات التدريب", NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "إشعار هادئ يظهر أثناء تشغيل جلسة التدريب"
            setSound(null, null)
            enableVibration(false)
            setShowBadge(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val alerts = NotificationChannel(
            CHANNEL_ALERTS, "تنبيهات التدريب", NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "تنبيهات عند تعذر تشغيل جلسة"
            setSound(null, null)
            enableVibration(false)
            setShowBadge(false)
        }
        val video = NotificationChannel(
            CHANNEL_VIDEO, "فيديو التدريب", NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "يفتح شاشة الفيديو في وقت الجلسة"
            setSound(null, null)
            enableVibration(false)
            setShowBadge(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannel(video)
        nm.createNotificationChannel(playback)
        nm.createNotificationChannel(alerts)
    }

    private fun openAppIntent(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun serviceAction(ctx: Context, action: String, requestCode: Int): PendingIntent =
        PendingIntent.getService(
            ctx, requestCode,
            Intent(ctx, TrainingPlaybackService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** Foreground notification. [remainingMs] < 0 means "no session yet" (preparing). */
    fun buildPlayback(
        ctx: Context,
        audioName: String,
        remainingMs: Long,
        paused: Boolean,
        showPauseAction: Boolean
    ): Notification {
        val b = NotificationCompat.Builder(ctx, CHANNEL_PLAYBACK)
            .setSmallIcon(R.drawable.ic_stat_parrot)
            .setContentTitle("تدريب الببغاء")
            .setContentText(
                if (paused) "الجلسة متوقفة مؤقتاً • $audioName" else "جلسة التدريب قيد التشغيل • $audioName"
            )
            .setSubText(audioName)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent(ctx))

        if (!paused && remainingMs >= 0) {
            // The system draws a live countdown by itself; no per-second notification updates needed.
            b.setShowWhen(true)
                .setWhen(System.currentTimeMillis() + remainingMs)
                .setUsesChronometer(true)
                .setChronometerCountDown(true)
        } else {
            b.setShowWhen(false)
        }
        if (showPauseAction) {
            b.addAction(
                0,
                if (paused) "استئناف" else "إيقاف مؤقت",
                serviceAction(ctx, TrainingPlaybackService.ACTION_TOGGLE_PAUSE, 2)
            )
        }
        b.addAction(0, "إيقاف", serviceAction(ctx, TrainingPlaybackService.ACTION_STOP, 1))
        return b.build()
    }

    /** Opens the video screen over the lock screen (like an alarm). If the system blocks that, the notification can be tapped. */
    fun postVideoLaunch(ctx: Context) {
        val pi = PendingIntent.getActivity(
            ctx, 3,
            Intent(ctx, VideoPlayerActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL_VIDEO)
            .setSmallIcon(R.drawable.ic_stat_parrot)
            .setContentTitle("تدريب الببغاء")
            .setContentText("حان وقت الفيديو")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID_VIDEO, n)
    }

    fun cancelVideoLaunch(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(NOTIF_ID_VIDEO)
    }

    fun update(ctx: Context, n: Notification) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID_PLAYBACK, n)
    }

    /** After a finished session: three quick buttons to note how the parrot reacted. Disappears after 30 minutes. */
    fun postReactionPrompt(ctx: Context, recordId: String) {
        fun action(reaction: String, requestCode: Int): PendingIntent = PendingIntent.getBroadcast(
            ctx, requestCode,
            Intent(ctx, com.parrottraining.app.receivers.ReactionReceiver::class.java)
                .setAction(com.parrottraining.app.receivers.ReactionReceiver.ACTION_REACTION)
                .putExtra(com.parrottraining.app.receivers.ReactionReceiver.EXTRA_RECORD_ID, recordId)
                .putExtra(com.parrottraining.app.receivers.ReactionReceiver.EXTRA_REACTION, reaction),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_stat_parrot)
            .setContentTitle("كيف كان تفاعل الببغاء؟")
            .setContentText("اختر الأقرب لما حصل في هذه الجلسة")
            .setAutoCancel(true)
            .setSilent(true)
            .setTimeoutAfter(30 * 60 * 1000L)
            .setContentIntent(openAppIntent(ctx))
            .addAction(0, "رد بصوت", action("VOICE", 21))
            .addAction(0, "قلّد", action("MIMIC", 22))
            .addAction(0, "ما تفاعل", action("NONE", 23))
            .build()
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID_REACTION, n)
    }

    fun cancelReactionPrompt(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(NOTIF_ID_REACTION)
    }

    /** A quiet, dismissible message, e.g. "the audio file could not be played". */
    fun postAlert(ctx: Context, text: String) {
        try {
            val st = com.parrottraining.app.data.TrainingRepository.get(ctx).data.value.settings
            if (st.remoteOnProblem) {
                com.parrottraining.app.data.RemoteNotifier.sendAsync(st, "⚠️ تنبيه من تدريب الببغاء", text, priority = 4)
            }
        } catch (_: Exception) {
        }
        val n = NotificationCompat.Builder(ctx, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_stat_parrot)
            .setContentTitle("تدريب الببغاء")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setSilent(true)
            .setContentIntent(openAppIntent(ctx))
            .build()
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID_ALERT, n)
    }
}

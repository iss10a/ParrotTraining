package com.parrottraining.app.playback

import com.parrottraining.app.domain.SessionType
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

/** In-process bridge between the playback service and the UI. */
object PlaybackStateHolder {

    data class UiState(
        val active: Boolean = false,
        val type: SessionType? = null,
        val audioName: String = "",
        val audioId: String? = null,
        val remainingMs: Long = 0L,
        val paused: Boolean = false,
        val preparing: Boolean = false,
        val phaseIndex: Int = -1
    )

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    /** Id of the session record currently owned by the service (used to detect stale RUNNING records). */
    @Volatile
    var activeRecordId: String? = null

    fun update(s: UiState) {
        _state.value = s
    }

    fun clear() {
        _state.value = UiState()
        activeRecordId = null
    }

    fun post(message: String) {
        _messages.tryEmit(message)
    }
}

package com.parrottraining.app.playback

import android.view.SurfaceHolder
import com.parrottraining.app.domain.SessionType
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

/** In-process bridge between the playback service and the UI. */
object PlaybackStateHolder {

    data class UiState(
        val active: Boolean = false,
        val type: SessionType? = null,
        val audioName: String = "",
        val audioId: String? = null,
        val remainingMs: Long = 0L,
        val paused: Boolean = false,
        val preparing: Boolean = false,
        val phaseIndex: Int = -1
    )

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    // ---- video output: the screen (Activity) hands its surface to the service's player
    @Volatile
    var displayHolder: SurfaceHolder? = null
        private set

    /** Set by the service; called on the main thread whenever the Activity's surface appears or goes away. */
    var displayListener: ((SurfaceHolder?) -> Unit)? = null

    fun setDisplay(holder: SurfaceHolder?) {
        displayHolder = holder
        displayListener?.invoke(holder)
    }

    private val _videoSize = MutableStateFlow(0 to 0)
    val videoSize: StateFlow<Pair<Int, Int>> = _videoSize.asStateFlow()

    fun updateVideoSize(width: Int, height: Int) {
        _videoSize.value = width to height
    }

    /** Id of the session record currently owned by the service (used to detect stale RUNNING records). */
    @Volatile
    var activeRecordId: String? = null

    /** A recording that is waiting for a visible screen of the app (Android only lets the camera start then). */
    class RecordRequest(val label: String, val highQuality: Boolean, val recordId: String)

    private val pendingRecord = java.util.concurrent.atomic.AtomicReference<RecordRequest?>(null)

    fun setPendingRecord(request: RecordRequest?) {
        pendingRecord.set(request)
    }

    /** Returns the waiting request and clears it, so only one screen ever starts the recording. */
    fun takePendingRecord(): RecordRequest? = pendingRecord.getAndSet(null)

    fun update(s: UiState) {
        _state.value = s
    }

    fun clear() {
        _state.value = UiState()
        _videoSize.value = 0 to 0
        activeRecordId = null
    }

    fun post(message: String) {
        _messages.tryEmit(message)
    }
}

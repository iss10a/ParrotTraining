package com.parrottraining.app.playback

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager

/**
 * A see-through screen that opens for a moment when an audio session starts by itself.
 * Android only lets the camera service start while the app has a visible screen, so this screen wakes the phone,
 * starts the recording, and closes. The recording keeps running after it closes.
 */
class RecordHostActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private var started = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try {
            (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).requestDismissKeyguard(this, null)
        } catch (_: Exception) {
        }
        NotificationHelper.cancelRecordLaunch(this)
    }

    override fun onResume() {
        super.onResume()
        if (started) return
        started = true
        SessionRecorderService.startPending(this)
        handler.postDelayed({ finish() }, 2_500L)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}

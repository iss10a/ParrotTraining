package com.parrottraining.app.playback

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Where a session recording is being written. Exactly one of [uri] (Android 10+) or [file] (older) is set. */
class RecordingOutput(val uri: Uri?, val file: File?, val pfd: ParcelFileDescriptor?)

/**
 * Session recordings go to the gallery (Movies/ParrotTraining) and are removed automatically after [KEEP_DAYS] days.
 * The app only ever deletes files it created itself.
 */
object RecordingStorage {
    private const val FOLDER = "ParrotTraining"
    const val KEEP_DAYS = 7

    fun create(ctx: Context, label: String): RecordingOutput {
        val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
        val name = "parrot_${stamp}_$label.mp4"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/" + FOLDER)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("تعذر إنشاء ملف التسجيل")
            val pfd = ctx.contentResolver.openFileDescriptor(uri, "w")
                ?: throw IllegalStateException("تعذر فتح ملف التسجيل")
            return RecordingOutput(uri, null, pfd)
        }
        val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES), FOLDER)
        dir.mkdirs()
        return RecordingOutput(null, File(dir, name), null)
    }

    /** Closes the file; keeps it (and shows it in the gallery) or deletes it if the recording failed. */
    fun finish(ctx: Context, out: RecordingOutput, keep: Boolean) {
        try {
            out.pfd?.close()
        } catch (_: Exception) {
        }
        try {
            if (out.uri != null) {
                if (keep) {
                    val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                    ctx.contentResolver.update(out.uri, v, null, null)
                } else {
                    ctx.contentResolver.delete(out.uri, null, null)
                }
            } else if (out.file != null && !keep) {
                out.file.delete()
            }
        } catch (_: Exception) {
        }
    }

    /** Deletes this app's recordings older than [KEEP_DAYS] days. */
    fun deleteOld(ctx: Context) {
        val cutoffMs = System.currentTimeMillis() - KEEP_DAYS * 24L * 60L * 60L * 1000L
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = ctx.contentResolver
                val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? AND ${MediaStore.MediaColumns.DATE_ADDED} < ?"
                val args = arrayOf(Environment.DIRECTORY_MOVIES + "/" + FOLDER + "%", (cutoffMs / 1000L).toString())
                resolver.query(base, arrayOf(MediaStore.MediaColumns._ID), selection, args, null)?.use { c ->
                    while (c.moveToNext()) {
                        resolver.delete(ContentUris.withAppendedId(base, c.getLong(0)), null, null)
                    }
                }
            } else {
                val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES), FOLDER)
                dir.listFiles()?.forEach { if (it.lastModified() < cutoffMs) it.delete() }
            }
        } catch (_: Exception) {
        }
    }
}

package com.parrottraining.app.playback

import android.Manifest
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.Log
import android.view.Display
import android.view.Surface
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.parrottraining.app.R
import com.parrottraining.app.data.TrainingRepository
import com.parrottraining.app.domain.MotionAnalyzer
import com.parrottraining.app.domain.RecorderMath

/**
 * Records the front camera, silently (no microphone, no preview), for the length of a training session.
 * While recording it also measures how much the picture moves (a small side stream, 4 frames a second) and saves
 * the result as the session's "activity" score. If the phone cannot run that side stream, it records without it.
 * It is a separate foreground service so a camera problem can never affect the training sound itself.
 * [TrainingPlaybackService] starts it with each session and stops it when the session ends.
 */
class SessionRecorderService : Service() {

    private val lock = Any()
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var camera: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var recorder: MediaRecorder? = null
    private var output: RecordingOutput? = null
    private var imageReader: ImageReader? = null
    private var analyzer: MotionAnalyzer? = null
    private var activityRecordId: String? = null
    private var analysisSize: Pair<Int, Int>? = null
    private var cameraChars: CameraCharacteristics? = null

    @Volatile
    private var lastAnalysisNs = 0L

    @Volatile
    private var recording = false

    @Volatile
    private var stopRequested = false
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!promoteToForeground()) {
            NotificationHelper.postAlert(this, "تعذر تشغيل تصوير الكاميرا الأمامية: النظام يمنع الكاميرا لأن التطبيق غير ظاهر (قيود أندرويد).")
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY
        running = true
        stopRequested = false
        val label = intent.getStringExtra(EXTRA_LABEL) ?: "session"
        val high = intent.getBooleanExtra(EXTRA_HIGH_QUALITY, false)
        activityRecordId = intent.getStringExtra(EXTRA_RECORD_ID)
        try {
            startRecording(label, high)
        } catch (e: Exception) {
            fail("تعذر بدء تصوير الكاميرا: ${e.message ?: "خطأ غير معروف"}", e)
        }
        return START_NOT_STICKY
    }

    private fun promoteToForeground(): Boolean = try {
        val n = NotificationCompat.Builder(this, NotificationHelper.CHANNEL_PLAYBACK)
            .setSmallIcon(R.drawable.ic_stat_parrot)
            .setContentTitle("تسجيل الجلسة")
            .setContentText("الكاميرا الأمامية تسجّل بدون صوت")
            .setOngoing(true)
            .setSilent(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } else {
            startForeground(NOTIF_ID, n)
        }
        true
    } catch (e: Exception) {
        false
    }

    private fun startRecording(label: String, highQuality: Boolean) {
        RecordingStorage.deleteOld(this)

        val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        // Front camera only. If the phone reports none, stop instead of silently using the rear camera.
        val id = widestFrontCameraId(cm) ?: throw IllegalStateException("لا توجد كاميرا أمامية في هذا الجوال")
        val chars = cm.getCameraCharacteristics(id)
        cameraChars = chars
        // Wide view: the sensor's own shape and no digital crop, so the whole cage stays in the picture.
        val active = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
        val sensorW = active?.width() ?: 0
        val sensorH = active?.height() ?: 0

        val sizes = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            ?.getOutputSizes(MediaRecorder::class.java)
            ?.map { it.width to it.height }
            .orEmpty()
        val (w, h) = RecorderMath.chooseWideSize(sizes, if (highQuality) 720 else 480, sensorW, sensorH)
        analysisSize = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            ?.getOutputSizes(ImageFormat.YUV_420_888)
            ?.map { it.width to it.height }
            ?.takeIf { it.isNotEmpty() }
            ?.let { RecorderMath.chooseWideSize(it, ANALYSIS_SHORT_SIDE, sensorW, sensorH) }

        val out = RecordingStorage.create(this, label)
        output = out

        val rec = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(this) else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }
        // No audio source on purpose: the file has no sound, so the training audio is never recorded.
        rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        val pfd = out.pfd
        if (pfd != null) rec.setOutputFile(pfd.fileDescriptor) else rec.setOutputFile(out.file!!.absolutePath)
        rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        rec.setVideoEncodingBitRate(if (highQuality) 3_000_000 else 1_200_000)
        rec.setVideoFrameRate(24)
        rec.setVideoSize(w, h)
        rec.setOrientationHint(RecorderMath.orientationHint(chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0, displayRotationDegrees()))
        rec.prepare()
        recorder = rec

        val t = HandlerThread("session-recorder").also { it.start() }
        thread = t
        val hd = Handler(t.looper)
        handler = hd
        setUpAnalysis(hd)

        cm.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(device: CameraDevice) {
                synchronized(lock) {
                    if (stopRequested) {
                        device.close()
                        return
                    }
                    camera = device
                }
                createSession(device, withAnalysis = imageReader != null)
            }

            override fun onDisconnected(device: CameraDevice) {
                device.close()
                fail("انقطعت الكاميرا أثناء التسجيل", null)
            }

            override fun onError(device: CameraDevice, error: Int) {
                device.close()
                fail("تعذر فتح الكاميرا (رمز $error)", null)
            }
        }, hd)
    }

    /** Prepares the small side stream used to measure movement. Any problem just means no activity score. */
    private fun setUpAnalysis(hd: Handler) {
        val size = analysisSize ?: return
        try {
            val reader = ImageReader.newInstance(size.first, size.second, ImageFormat.YUV_420_888, 2)
            val a = MotionAnalyzer()
            reader.setOnImageAvailableListener({ r ->
                val image = runCatching { r.acquireLatestImage() }.getOrNull()
                    ?: return@setOnImageAvailableListener
                try {
                    val ts = image.timestamp
                    if (ts - lastAnalysisNs >= MotionAnalyzer.FRAME_INTERVAL_NS) {
                        lastAnalysisNs = ts
                        val plane = image.planes[0]
                        a.addLumaFrame(plane.buffer, image.width, image.height, plane.rowStride)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "activity analysis frame failed", e)
                } finally {
                    image.close()
                }
            }, hd)
            imageReader = reader
            analyzer = a
        } catch (e: Exception) {
            Log.w(TAG, "activity analysis not available", e)
            closeAnalysis()
        }
    }

    private fun closeAnalysis() {
        try {
            imageReader?.setOnImageAvailableListener(null, null)
            imageReader?.close()
        } catch (_: Exception) {
        }
        imageReader = null
    }

    private fun createSession(device: CameraDevice, withAnalysis: Boolean) {
        try {
            val surface: Surface = recorder?.surface ?: throw IllegalStateException("لا يوجد مخرج للتسجيل")
            val extra: Surface? = if (withAnalysis) imageReader?.surface else null
            val surfaces = if (extra != null) listOf(surface, extra) else listOf(surface)
            @Suppress("DEPRECATION")
            device.createCaptureSession(surfaces, object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    synchronized(lock) {
                        if (stopRequested) {
                            session.close()
                            return
                        }
                        captureSession = session
                        try {
                            val req = device.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                                .apply {
                                    addTarget(surface)
                                    if (extra != null) addTarget(extra)
                                    applyWideView(this)
                                }
                                .build()
                            session.setRepeatingRequest(req, null, handler)
                            recorder?.start()
                            recording = true
                        } catch (e: Exception) {
                            fail("تعذر بدء التسجيل: ${e.message ?: "خطأ غير معروف"}", e)
                        }
                    }
                }

                override fun onConfigureFailed(session: CameraCaptureSession) {
                    if (extra != null) {
                        // This phone cannot run the movement stream next to the recording: record without it.
                        Log.w(TAG, "side stream not supported, recording without activity score")
                        closeAnalysis()
                        analyzer = null
                        createSession(device, withAnalysis = false)
                    } else {
                        fail("تعذر تهيئة الكاميرا للتسجيل", null)
                    }
                }
            }, handler)
        } catch (e: Exception) {
            fail("تعذر تهيئة الكاميرا للتسجيل: ${e.message ?: "خطأ غير معروف"}", e)
        }
    }

    /** The front camera with the widest field of view (some phones have a normal and an ultra-wide selfie lens). */
    private fun widestFrontCameraId(cm: CameraManager): String? {
        var best: String? = null
        var bestFov = -1.0
        for (id in cm.cameraIdList) {
            val c = try {
                cm.getCameraCharacteristics(id)
            } catch (_: Exception) {
                continue
            }
            if (c.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_FRONT) continue
            val sensor = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
            val focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.minOrNull()
            val fov = if (sensor != null && focal != null && focal > 0f) {
                RecorderMath.fieldOfViewDegrees(sensor.width, focal)
            } else 0.0
            if (best == null || fov > bestFov) {
                best = id
                bestFov = fov
            }
        }
        return best
    }

    /** Zoom all the way out and keep the full sensor area; image stabilization is off because it crops the edges. */
    private fun applyWideView(builder: CaptureRequest.Builder) {
        val c = cameraChars ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val range = c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
                if (range != null) builder.set(CaptureRequest.CONTROL_ZOOM_RATIO, minOf(range.lower, 1.0f))
            } else {
                c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)?.let { builder.set(CaptureRequest.SCALER_CROP_REGION, it) }
            }
            builder.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF)
        } catch (e: Exception) {
            Log.w(TAG, "wide view settings not supported", e)
        }
    }

    private fun displayRotationDegrees(): Int = try {
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        when (dm.getDisplay(Display.DEFAULT_DISPLAY)?.rotation) {
            Surface.ROTATION_90 -> 90
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 270
            else -> 0
        }
    } catch (e: Exception) {
        0
    }

    private fun fail(message: String, e: Exception?) {
        Log.w(TAG, message, e)
        NotificationHelper.postAlert(this, message)
        releaseAll(keepFile = false)
        running = false
        stopSelf()
    }

    /** Called when the session ends: finishes the file (kept in the gallery) and stops the service. */
    fun requestStop() {
        releaseAll(keepFile = true)
        running = false
        stopSelf()
    }

    private fun releaseAll(keepFile: Boolean) {
        var activity: Int? = null
        var activityId: String? = null
        synchronized(lock) {
            stopRequested = true
            var ok = recording
            try {
                captureSession?.stopRepeating()
            } catch (_: Exception) {
            }
            try {
                captureSession?.close()
            } catch (_: Exception) {
            }
            captureSession = null
            try {
                camera?.close()
            } catch (_: Exception) {
            }
            camera = null
            val rec = recorder
            recorder = null
            if (rec != null) {
                if (recording) {
                    try {
                        rec.stop()
                    } catch (_: RuntimeException) {
                        ok = false // stopped too early: the file is not valid
                    }
                }
                try {
                    rec.reset()
                } catch (_: Exception) {
                }
                try {
                    rec.release()
                } catch (_: Exception) {
                }
            }
            recording = false
            if (keepFile && ok) {
                activity = analyzer?.activityPercent()
                activityId = activityRecordId
            }
            closeAnalysis()
            analyzer = null
            activityRecordId = null
            val out = output
            output = null
            if (out != null) RecordingStorage.finish(this, out, keep = keepFile && ok)
            thread?.quitSafely()
            thread = null
            handler = null
        }
        RecordingStorage.deleteOld(this)
        val pct = activity
        val id = activityId
        if (pct != null && id != null) {
            try {
                TrainingRepository.get(this).setActivity(id, pct)
            } catch (e: Exception) {
                Log.w(TAG, "could not save activity score", e)
            }
        }
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        releaseAll(keepFile = true)
        super.onDestroy()
    }

    companion object {
        private const val TAG = "SessionRecorder"
        const val ACTION_START = "com.parrottraining.app.action.RECORD_START"
        const val EXTRA_LABEL = "label"
        const val EXTRA_HIGH_QUALITY = "high_quality"
        const val EXTRA_RECORD_ID = "record_id"

        /** The movement stream is small on purpose: 240 on the short side is enough to see a parrot move. */
        private const val ANALYSIS_SHORT_SIDE = 240
        private const val NOTIF_ID = 1005

        @Volatile
        private var instance: SessionRecorderService? = null

        fun hasCameraPermission(ctx: Context): Boolean =
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

        /** Starts silent front-camera recording for a session. Never throws: a failure only shows a notification. */
        fun start(ctx: Context, label: String, highQuality: Boolean, recordId: String? = null) {
            if (!hasCameraPermission(ctx)) {
                NotificationHelper.postAlert(ctx, "تصوير الجلسات مفعّل لكن إذن الكاميرا غير ممنوح.")
                return
            }
            try {
                ContextCompat.startForegroundService(
                    ctx,
                    Intent(ctx, SessionRecorderService::class.java)
                        .setAction(ACTION_START)
                        .putExtra(EXTRA_LABEL, label)
                        .putExtra(EXTRA_HIGH_QUALITY, highQuality)
                        .putExtra(EXTRA_RECORD_ID, recordId)
                )
            } catch (e: Exception) {
                NotificationHelper.postAlert(ctx, "تعذر تشغيل تصوير الكاميرا الأمامية: النظام يمنع الكاميرا لأن التطبيق غير ظاهر (قيود أندرويد).")
            }
        }

        /** Starts the recording that the playback service queued for this session. Called from a screen that is visible. */
        fun startPending(ctx: Context) {
            val req = PlaybackStateHolder.takePendingRecord() ?: return
            start(ctx, req.label, req.highQuality, req.recordId)
        }

        fun stop() {
            instance?.requestStop()
        }
    }
}

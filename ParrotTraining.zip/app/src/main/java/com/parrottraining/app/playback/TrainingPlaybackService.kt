package com.parrottraining.app.playback

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.parrottraining.app.data.TrainingRepository
import com.parrottraining.app.domain.Resolved
import com.parrottraining.app.domain.SessionGuard
import com.parrottraining.app.domain.SessionRecord
import com.parrottraining.app.domain.SessionStatus
import com.parrottraining.app.domain.SessionType
import com.parrottraining.app.domain.Settings
import com.parrottraining.app.domain.AudioItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Plays one training session at a time: loops the week's audio until the session time is over.
 * Runs as a foreground (mediaPlayback) service so it keeps working with the screen off and
 * without any Activity. The countdown lives here, not in the UI.
 */
class TrainingPlaybackService : Service() {

    private class Session(
        val record: SessionRecord,
        val audio: AudioItem,
        val loop: Boolean,
        val durationMs: Long
    ) {
        var remainingMs: Long = durationMs
        var playedMs: Long = 0L
        var prepared = false
        var userPaused = false
        var focusPaused = false
        var lastTick: Long = SystemClock.elapsedRealtime()
        var pausedSince: Long = 0L
        var preparingMs: Long = 0L

        val type: SessionType get() = record.type
        val running: Boolean get() = prepared && !userPaused && !focusPaused
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var repo: TrainingRepository
    private lateinit var audioManager: AudioManager

    private var session: Session? = null
    private var player: MediaPlayer? = null
    private var tickerJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var focusRequest: AudioFocusRequest? = null
    private var ducked = false

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        val s = session ?: return@OnAudioFocusChangeListener
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                endSession(SessionStatus.INTERRUPTED, null)
                shutdownIfIdle()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                s.focusPaused = true
                pausePlayer(s)
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                ducked = true
                applyVolume()
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                ducked = false
                applyVolume()
                if (s.focusPaused) {
                    s.focusPaused = false
                    if (!s.userPaused) resumePlayer(s)
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        repo = TrainingRepository.get(this)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        NotificationHelper.ensureChannels(this)
        // Live volume changes from the settings screen.
        scope.launch {
            repo.data.map { it.settings.volumePercent }.distinctUntilChanged().collect { applyVolume() }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                // Must become a foreground service right away (Android gives us only a few seconds).
                if (!promoteToForeground()) {
                    handleForegroundFailure(intent)
                } else {
                    handleStart(intent)
                }
            }
            ACTION_STOP -> {
                if (session != null) endSession(SessionStatus.STOPPED, null)
                shutdownIfIdle()
            }
            ACTION_TOGGLE_PAUSE -> togglePause()
            else -> shutdownIfIdle()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (session != null) endSession(SessionStatus.INTERRUPTED, null)
        scope.cancel()
        releaseWakeLock()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- start

    private fun promoteToForeground(): Boolean = try {
        val n = NotificationHelper.buildPlayback(this, "", -1L, paused = false, showPauseAction = false)
        ServiceCompat.startForeground(
            this, NotificationHelper.NOTIF_ID_PLAYBACK, n,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        )
        true
    } catch (e: Exception) {
        false
    }

    private fun handleForegroundFailure(intent: Intent) {
        val type = typeOf(intent)
        val msg = "تعذر تشغيل خدمة التدريب في الخلفية (قيود النظام أو البطارية)."
        if (type != SessionType.PREVIEW) {
            repo.logFailure(type, intent.getLongExtra(EXTRA_SLOT_AT, 0L), msg)
            NotificationHelper.postAlert(this, msg)
        }
        PlaybackStateHolder.post(msg)
        stopSelf()
    }

    private fun typeOf(intent: Intent): SessionType =
        runCatching { SessionType.valueOf(intent.getStringExtra(EXTRA_TYPE) ?: "") }
            .getOrDefault(SessionType.MANUAL)

    private fun handleStart(intent: Intent) {
        val type = typeOf(intent)
        val slotAt = intent.getLongExtra(EXTRA_SLOT_AT, 0L)
        val data = repo.data.value

        val decision = SessionGuard.onNewSession(session?.type, type)
        if (decision == SessionGuard.Decision.REJECT_INCOMING) {
            PlaybackStateHolder.post("لا يمكن معاينة الصوت أثناء جلسة تدريب قيد التشغيل.")
            return
        }

        val resolved: Resolved? = when (type) {
            SessionType.PREVIEW -> {
                val id = intent.getStringExtra(EXTRA_AUDIO_ID)
                data.audios.firstOrNull { it.id == id }?.let { Resolved(it, -1) }
            }
            SessionType.SCHEDULED -> repo.resolveForSlot(slotAt)
            else -> repo.resolveCurrent(System.currentTimeMillis())
        }

        // Never two sessions at once: stop the old one first.
        if (decision == SessionGuard.Decision.REPLACE_CURRENT) {
            endSession(SessionStatus.INTERRUPTED, null)
        }

        if (resolved == null) {
            val msg = "لا يوجد ملف صوتي لهذه الجلسة."
            if (type != SessionType.PREVIEW) repo.logFailure(type, slotAt, msg)
            PlaybackStateHolder.post(msg)
            shutdownIfIdle()
            return
        }
        startSession(type, slotAt, resolved, data.settings)
    }

    private fun startSession(type: SessionType, slotAt: Long, r: Resolved, settings: Settings) {
        val duration = when (type) {
            SessionType.TEST -> TEST_SESSION_MS
            SessionType.PREVIEW -> PREVIEW_MAX_MS
            else -> settings.sessionMinutes * 60_000L
        }
        val now = System.currentTimeMillis()
        val record = SessionRecord(
            id = TrainingRepository.newId(),
            type = type,
            status = SessionStatus.RUNNING,
            slotAtMs = slotAt,
            startedAtMs = now,
            plannedMs = duration,
            playedMs = 0L,
            audioId = r.audio.id,
            audioName = r.audio.name,
            phaseIndex = r.phaseIndex
        )
        if (type != SessionType.PREVIEW) {
            repo.beginSession(record)
            PlaybackStateHolder.activeRecordId = record.id
        }
        val s = Session(record, r.audio, loop = type != SessionType.PREVIEW, durationMs = duration)
        session = s
        ducked = false
        acquireWakeLock(duration + MAX_PAUSE_MS + 120_000L)
        publish(s)
        updateNotification(s)
        preparePlayer(s)
        startTicker()
    }

    private fun preparePlayer(s: Session) {
        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setDataSource(applicationContext, Uri.parse(s.audio.uri))
            mp.isLooping = s.loop
            mp.setOnPreparedListener { onPrepared(s) }
            mp.setOnCompletionListener {
                // Only reached for non-looping playback (audio preview).
                if (session === s && !s.loop) completeSession()
            }
            mp.setOnErrorListener { _, _, _ ->
                failSession(s, ERROR_MESSAGE)
                true
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            failSession(s, ERROR_MESSAGE)
        }
    }

    private fun onPrepared(s: Session) {
        if (session !== s) return
        requestFocus()
        applyVolume()
        try {
            player?.start()
        } catch (e: Exception) {
            failSession(s, ERROR_MESSAGE)
            return
        }
        s.prepared = true
        s.lastTick = SystemClock.elapsedRealtime()
        publish(s)
        updateNotification(s)
    }

    // ----------------------------------------------------------------- tick

    private fun startTicker() {
        tickerJob?.cancel()
        tickerJob = scope.launch {
            while (isActive) {
                delay(500)
                tick()
            }
        }
    }

    private fun tick() {
        val s = session ?: return
        val now = SystemClock.elapsedRealtime()
        val delta = (now - s.lastTick).coerceAtLeast(0L)
        s.lastTick = now
        when {
            !s.prepared -> {
                s.preparingMs += delta
                if (s.preparingMs > PREPARE_TIMEOUT_MS) {
                    failSession(s, ERROR_MESSAGE)
                    return
                }
            }
            s.running -> {
                s.remainingMs -= delta
                s.playedMs += delta
            }
            else -> {
                if (s.pausedSince > 0 && now - s.pausedSince > MAX_PAUSE_MS) {
                    endSession(SessionStatus.INTERRUPTED, null)
                    shutdownIfIdle()
                    return
                }
            }
        }
        if (s.prepared && s.remainingMs <= 0) {
            completeSession()
            return
        }
        publish(s)
    }

    // ------------------------------------------------------------ pause etc.

    private fun togglePause() {
        val s = session ?: return
        if (s.type == SessionType.PREVIEW) return
        if (s.userPaused) {
            s.userPaused = false
            if (!s.focusPaused) resumePlayer(s)
        } else {
            s.userPaused = true
            pausePlayer(s)
        }
    }

    private fun pausePlayer(s: Session) {
        try {
            if (s.prepared && player?.isPlaying == true) player?.pause()
        } catch (_: Exception) {
        }
        s.pausedSince = SystemClock.elapsedRealtime()
        s.lastTick = s.pausedSince
        publish(s)
        updateNotification(s)
    }

    private fun resumePlayer(s: Session) {
        try {
            if (s.prepared) player?.start()
        } catch (_: Exception) {
        }
        s.pausedSince = 0L
        s.lastTick = SystemClock.elapsedRealtime()
        publish(s)
        updateNotification(s)
    }

    // ------------------------------------------------------------------ end

    private fun completeSession() {
        val s = session ?: return
        endSession(SessionStatus.COMPLETED, null)
        // A missed session can be made up right after the next regular one.
        if (s.type == SessionType.SCHEDULED && repo.consumeMakeup()) {
            val r = repo.resolveCurrent(System.currentTimeMillis())
            if (r != null) {
                startSession(SessionType.MAKEUP, 0L, r, repo.data.value.settings)
                return
            }
        }
        shutdownIfIdle()
    }

    private fun failSession(s: Session, message: String) {
        if (session !== s) return
        endSession(SessionStatus.FAILED, message)
        PlaybackStateHolder.post(message)
        if (s.type != SessionType.PREVIEW) NotificationHelper.postAlert(this, message)
        // The next scheduled session is already armed, so the plan continues normally.
        shutdownIfIdle()
    }

    private fun endSession(status: SessionStatus, error: String?) {
        val s = session ?: return
        session = null
        tickerJob?.cancel()
        tickerJob = null
        try {
            player?.stop()
        } catch (_: Exception) {
        }
        try {
            player?.release()
        } catch (_: Exception) {
        }
        player = null
        abandonFocus()
        releaseWakeLock()
        if (s.type != SessionType.PREVIEW) {
            repo.finishSession(s.record.id, status, s.playedMs, error)
        }
        PlaybackStateHolder.clear()
    }

    private fun shutdownIfIdle() {
        if (session == null) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    // ---------------------------------------------------- audio / notification

    private fun applyVolume() {
        val p = player ?: return
        val base = repo.data.value.settings.volumePercent / 100f
        val v = if (ducked) base * 0.3f else base
        try {
            p.setVolume(v, v)
        } catch (_: Exception) {
        }
    }

    private fun requestFocus() {
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setOnAudioFocusChangeListener(focusListener, Handler(Looper.getMainLooper()))
            .build()
        focusRequest = req
        // If focus cannot be granted (e.g. during a call) we still play; the listener handles later changes.
        audioManager.requestAudioFocus(req)
    }

    private fun abandonFocus() {
        focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        focusRequest = null
    }

    private fun acquireWakeLock(timeoutMs: Long) {
        releaseWakeLock()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ParrotTraining:session").apply {
            setReferenceCounted(false)
            acquire(timeoutMs)
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        wakeLock = null
    }

    private fun publish(s: Session) {
        PlaybackStateHolder.update(
            PlaybackStateHolder.UiState(
                active = true,
                type = s.type,
                audioName = s.audio.name,
                audioId = s.audio.id,
                remainingMs = ((s.remainingMs.coerceAtLeast(0L) + 999L) / 1000L) * 1000L,
                paused = s.userPaused || s.focusPaused,
                preparing = !s.prepared,
                phaseIndex = s.record.phaseIndex
            )
        )
    }

    private fun updateNotification(s: Session) {
        val n = NotificationHelper.buildPlayback(
            this,
            audioName = s.audio.name,
            remainingMs = if (s.prepared) s.remainingMs.coerceAtLeast(0L) else -1L,
            paused = s.userPaused || s.focusPaused,
            showPauseAction = s.type != SessionType.PREVIEW
        )
        NotificationHelper.update(this, n)
    }

    companion object {
        const val ACTION_START = "com.parrottraining.app.action.START_SESSION"
        const val ACTION_STOP = "com.parrottraining.app.action.STOP_SESSION"
        const val ACTION_TOGGLE_PAUSE = "com.parrottraining.app.action.TOGGLE_PAUSE"
        private const val EXTRA_TYPE = "type"
        private const val EXTRA_SLOT_AT = "slot_at"
        private const val EXTRA_AUDIO_ID = "audio_id"

        const val TEST_SESSION_MS = 60_000L
        const val PREVIEW_MAX_MS = 20_000L
        private const val MAX_PAUSE_MS = 30 * 60_000L
        private const val PREPARE_TIMEOUT_MS = 20_000L
        const val ERROR_MESSAGE = "تعذر تشغيل الملف الصوتي. تأكد أن الملف ما زال موجوداً."

        fun start(ctx: Context, type: SessionType, slotAtMs: Long = 0L, audioId: String? = null) {
            val i = Intent(ctx, TrainingPlaybackService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_TYPE, type.name)
                .putExtra(EXTRA_SLOT_AT, slotAtMs)
            if (audioId != null) i.putExtra(EXTRA_AUDIO_ID, audioId)
            ContextCompat.startForegroundService(ctx, i)
        }

        /** Stops the current session only. Does nothing when nothing is playing. */
        fun stop(ctx: Context) {
            if (!PlaybackStateHolder.state.value.active) return
            try {
                ctx.startService(Intent(ctx, TrainingPlaybackService::class.java).setAction(ACTION_STOP))
            } catch (_: Exception) {
            }
        }

        fun togglePause(ctx: Context) {
            if (!PlaybackStateHolder.state.value.active) return
            try {
                ctx.startService(Intent(ctx, TrainingPlaybackService::class.java).setAction(ACTION_TOGGLE_PAUSE))
            } catch (_: Exception) {
            }
        }
    }
}

package com.parrottraining.app.playback

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.min

/**
 * Full-screen landscape video screen shown at session time (over the lock screen, screen turned on).
 * It is always landscape (the phone's rotation lock does not matter here); the rest of the app follows the lock.
 * It only displays the picture: the player itself lives in [TrainingPlaybackService], so the
 * sound and the countdown keep working even if this screen is closed or blocked by the system.
 */
class VideoPlayerActivity : Activity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var label: TextView
    private lateinit var stopButton: TextView

    private var seenActive = false
    private var videoW = 0
    private var videoH = 0

    private val hideStop = Runnable { stopButton.visibility = View.GONE }
    private val noSessionTimeout = Runnable { if (!seenActive) finish() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Always landscape, even when the phone's rotation lock is on (only this screen; the rest of the app follows the lock).
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try {
            // A plain "swipe" lock screen is dismissed; a PIN / pattern lock is only shown over.
            (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).requestDismissKeyguard(this, null)
        } catch (_: Exception) {
        }

        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        surface = SurfaceView(this)
        root.addView(surface, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        label = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 22f
            gravity = Gravity.CENTER
        }
        root.addView(label, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        stopButton = TextView(this).apply {
            text = "إيقاف الجلسة"
            setTextColor(Color.WHITE)
            textSize = 16f
            setBackgroundColor(0x99000000.toInt())
            setPadding(48, 24, 48, 24)
            visibility = View.GONE
            setOnClickListener {
                TrainingPlaybackService.stop(this@VideoPlayerActivity)
                finish()
            }
        }
        root.addView(stopButton, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
            setMargins(32, 32, 32, 32)
        })

        // A touch shows the stop button for a few seconds.
        root.setOnClickListener {
            stopButton.visibility = View.VISIBLE
            handler.removeCallbacks(hideStop)
            handler.postDelayed(hideStop, 4000L)
        }
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fitVideo() }
        setContentView(root)

        surface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                PlaybackStateHolder.setDisplay(holder)
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                if (PlaybackStateHolder.displayHolder === holder) PlaybackStateHolder.setDisplay(null)
            }
        })

        NotificationHelper.cancelVideoLaunch(this)

        scope.launch {
            PlaybackStateHolder.state.collect { st ->
                if (st.active) {
                    seenActive = true
                    label.text = if (videoW == 0) st.audioName else ""
                } else if (seenActive) {
                    finish()
                }
            }
        }
        scope.launch {
            PlaybackStateHolder.videoSize.collect { (w, h) ->
                videoW = w
                videoH = h
                if (w > 0) label.text = ""
                fitVideo()
            }
        }
        // If no session ever shows up (e.g. it already ended), do not stay open on a black screen.
        handler.postDelayed(noSessionTimeout, 20_000L)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            val c = WindowInsetsControllerCompat(window, window.decorView)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    /** Scales the picture to the screen while keeping its proportions (letter-box). */
    private fun fitVideo() {
        val cw = root.width
        val ch = root.height
        if (videoW <= 0 || videoH <= 0 || cw <= 0 || ch <= 0) return
        val scale = min(cw.toFloat() / videoW, ch.toFloat() / videoH)
        val w = (videoW * scale).toInt().coerceAtLeast(1)
        val h = (videoH * scale).toInt().coerceAtLeast(1)
        val lp = surface.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w || lp.height != h || lp.gravity != Gravity.CENTER) {
            lp.width = w
            lp.height = h
            lp.gravity = Gravity.CENTER
            surface.layoutParams = lp
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        scope.cancel()
        if (PlaybackStateHolder.displayHolder === surface.holder) PlaybackStateHolder.setDisplay(null)
        super.onDestroy()
    }
}

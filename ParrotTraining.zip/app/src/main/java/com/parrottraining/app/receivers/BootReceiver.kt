package com.parrottraining.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.parrottraining.app.scheduler.TrainingScheduler
import java.util.TimeZone

/**
 * Re-arms the next training session after: reboot, clock change, time zone change,
 * app update, or a change of the exact-alarm permission.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            ACTION_EXACT_ALARM_PERMISSION_CHANGED -> {
                if (intent.action == Intent.ACTION_TIMEZONE_CHANGED) {
                    // Make sure the JVM does not keep using a cached old zone.
                    TimeZone.setDefault(null)
                }
                TrainingScheduler(context.applicationContext).reschedule()
            }
        }
    }

    private companion object {
        const val ACTION_EXACT_ALARM_PERMISSION_CHANGED =
            "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED"
    }
}

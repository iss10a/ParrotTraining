package com.parrottraining.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.parrottraining.app.data.TrainingRepository
import com.parrottraining.app.domain.SessionReaction
import com.parrottraining.app.playback.NotificationHelper

/** Handles the three buttons of the "how did the parrot react?" notification. */
class ReactionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_REACTION) return
        val app = context.applicationContext
        val id = intent.getStringExtra(EXTRA_RECORD_ID)
        val reaction = runCatching { SessionReaction.valueOf(intent.getStringExtra(EXTRA_REACTION) ?: "") }.getOrNull()
        if (id != null && reaction != null) {
            TrainingRepository.get(app).setReaction(id, reaction)
        }
        NotificationHelper.cancelReactionPrompt(app)
    }

    companion object {
        const val ACTION_REACTION = "com.parrottraining.app.action.REACTION"
        const val EXTRA_RECORD_ID = "record_id"
        const val EXTRA_REACTION = "reaction"
    }
}

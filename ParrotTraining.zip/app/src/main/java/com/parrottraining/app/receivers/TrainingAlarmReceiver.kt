package com.parrottraining.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.parrottraining.app.data.TrainingRepository
import com.parrottraining.app.domain.PlanEngine
import com.parrottraining.app.domain.PlanStatus
import com.parrottraining.app.domain.SessionType
import com.parrottraining.app.playback.NotificationHelper
import com.parrottraining.app.playback.TrainingPlaybackService
import com.parrottraining.app.scheduler.TrainingScheduler
import java.time.ZoneId

/**
 * Fired by AlarmManager for the next session. It validates that the alarm is still meaningful
 * (plan active, same plan version, still a planned slot, not far too late), starts the foreground
 * service, and immediately arms the following session.
 */
class TrainingAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_SESSION_ALARM) return
        val app = context.applicationContext
        val scheduledAt = intent.getLongExtra(EXTRA_SCHEDULED_AT, 0L)
        val version = intent.getLongExtra(EXTRA_VERSION, -1L)
        val now = System.currentTimeMillis()
        val repo = TrainingRepository.get(app)

        try {
            repo.refresh()
            val d = repo.data.value
            val valid = scheduledAt > 0 &&
                version == d.plan.version &&
                d.plan.status == PlanStatus.ACTIVE &&
                now >= scheduledAt - PlanEngine.EARLY_LIMIT_MS &&
                now - scheduledAt <= PlanEngine.LATE_PLAY_LIMIT_MS &&
                PlanEngine.isValidSlot(scheduledAt, ZoneId.systemDefault(), d.audios, d.plan, d.settings)

            if (valid) {
                try {
                    TrainingPlaybackService.start(app, SessionType.SCHEDULED, slotAtMs = scheduledAt)
                } catch (e: Exception) {
                    val msg = "تعذر بدء الجلسة المجدولة في الخلفية (قيود النظام)."
                    repo.logFailure(SessionType.SCHEDULED, scheduledAt, msg)
                    NotificationHelper.postAlert(app, msg)
                }
            }
        } finally {
            // Arm the next session (strictly after the one that just fired).
            TrainingScheduler(app).reschedule(afterMs = maxOf(now, scheduledAt))
        }
    }

    companion object {
        const val ACTION_SESSION_ALARM = "com.parrottraining.app.action.SESSION_ALARM"
        const val EXTRA_SCHEDULED_AT = "scheduled_at"
        const val EXTRA_VERSION = "plan_version"
    }
}

package com.parrottraining.app.scheduler

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.parrottraining.app.data.TrainingRepository
import com.parrottraining.app.domain.PlanEngine
import com.parrottraining.app.domain.SessionSlot
import com.parrottraining.app.receivers.TrainingAlarmReceiver
import java.time.ZoneId

/**
 * Keeps exactly ONE alarm armed: the next training session. After a session starts (or the plan,
 * settings, time, time zone or boot state changes) the next one is computed again from scratch.
 */
class TrainingScheduler(context: Context) {
    private val app = context.applicationContext

    fun canScheduleExact(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val am = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return am.canScheduleExactAlarms()
    }

    /**
     * @param afterMs only sessions strictly after this instant are considered
     * (the alarm receiver passes the instant of the session that just fired).
     */
    fun reschedule(afterMs: Long = System.currentTimeMillis()): SessionSlot? {
        val repo = TrainingRepository.get(app)
        repo.refresh()
        val d = repo.data.value
        val am = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        armVideoAlarm(am, d)

        val slot = PlanEngine.nextSession(
            maxOf(afterMs, System.currentTimeMillis()),
            ZoneId.systemDefault(), d.audios, d.plan, d.settings
        )
        if (slot == null) {
            cancel(am)
            return null
        }

        val intent = baseIntent()
            .putExtra(TrainingAlarmReceiver.EXTRA_SCHEDULED_AT, slot.epochMs)
            .putExtra(TrainingAlarmReceiver.EXTRA_VERSION, d.plan.version)
        val pi = PendingIntent.getBroadcast(
            app, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (canScheduleExact()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, slot.epochMs, pi)
            } else {
                // Exact alarms are not permitted: fall back to an inexact (possibly delayed) alarm.
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, slot.epochMs, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, slot.epochMs, pi)
        }
        return slot
    }

    /** The video schedule has its own alarm, so audio and video sessions never replace each other's alarm. */
    private fun armVideoAlarm(am: AlarmManager, d: com.parrottraining.app.domain.AppData) {
        val slot = PlanEngine.nextVideoSession(
            System.currentTimeMillis(), ZoneId.systemDefault(), d.audios, d.plan, d.settings
        )
        if (slot == null) {
            val old = PendingIntent.getBroadcast(
                app, VIDEO_REQUEST_CODE, videoIntent(),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (old != null) {
                am.cancel(old)
                old.cancel()
            }
            return
        }
        val pi = PendingIntent.getBroadcast(
            app, VIDEO_REQUEST_CODE,
            videoIntent()
                .putExtra(TrainingAlarmReceiver.EXTRA_SCHEDULED_AT, slot.epochMs)
                .putExtra(TrainingAlarmReceiver.EXTRA_VERSION, d.plan.version),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (canScheduleExact()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, slot.epochMs, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, slot.epochMs, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, slot.epochMs, pi)
        }
    }

    private fun videoIntent() = Intent(app, TrainingAlarmReceiver::class.java)
        .setAction(TrainingAlarmReceiver.ACTION_VIDEO_ALARM)

    private fun baseIntent() = Intent(app, TrainingAlarmReceiver::class.java)
        .setAction(TrainingAlarmReceiver.ACTION_SESSION_ALARM)

    private fun cancel(am: AlarmManager) {
        val pi = PendingIntent.getBroadcast(
            app, REQUEST_CODE, baseIntent(),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            am.cancel(pi)
            pi.cancel()
        }
    }

    private companion object {
        const val REQUEST_CODE = 4711
        const val VIDEO_REQUEST_CODE = 4712
    }
}

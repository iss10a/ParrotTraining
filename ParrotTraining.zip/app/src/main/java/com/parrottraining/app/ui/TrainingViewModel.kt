package com.parrottraining.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.parrottraining.app.data.AudioUtils
import com.parrottraining.app.data.BackupManager
import com.parrottraining.app.data.TrainingRepository
import com.parrottraining.app.domain.AppData
import com.parrottraining.app.domain.AudioItem
import com.parrottraining.app.domain.LogAnalyzer
import com.parrottraining.app.domain.MissedPolicy
import com.parrottraining.app.domain.PhaseRow
import com.parrottraining.app.domain.PlanEngine
import com.parrottraining.app.domain.PlanPosition
import com.parrottraining.app.domain.SessionRecord
import com.parrottraining.app.domain.SessionType
import com.parrottraining.app.domain.Settings
import com.parrottraining.app.playback.PlaybackStateHolder
import com.parrottraining.app.playback.TrainingPlaybackService
import com.parrottraining.app.scheduler.TrainingScheduler
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.time.ZoneId

/** Everything the UI needs, derived live from [TrainingRepository]. Never schedules anything itself. */
class TrainingViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = TrainingRepository.get(app)
    private val scheduler = TrainingScheduler(app)

    val data: StateFlow<AppData> = repo.data
    val log: StateFlow<List<SessionRecord>> = repo.log
    val playback: StateFlow<PlaybackStateHolder.UiState> = PlaybackStateHolder.state
    val messages: SharedFlow<String> = PlaybackStateHolder.messages

    init {
        // Keeps "day in phase" / "next session" fresh while a screen is open, and detects
        // missed sessions even if no alarm fires while the app happens to be in the foreground.
        viewModelScope.launch {
            while (true) {
                repo.refresh()
                delay(20_000)
            }
        }
    }

    fun refreshNow() = repo.refresh()

    private fun zone() = ZoneId.systemDefault()

    // ------------------------------------------------------------ home view

    fun currentPosition(nowMs: Long): PlanPosition {
        val d = data.value
        val today = PlanEngine.epochDayOf(nowMs, zone())
        val eff = PlanEngine.normalize(d.plan, d.settings, d.audios.size, today)
        return PlanEngine.currentPosition(today, d.audios, eff, d.settings)
    }

    fun nextSession(nowMs: Long) = data.value.let {
        PlanEngine.nextSession(nowMs, zone(), it.audios, it.plan, it.settings)
    }

    fun logRows(nowMs: Long): List<PhaseRow> {
        val d = data.value
        val today = PlanEngine.epochDayOf(nowMs, zone())
        val eff = PlanEngine.normalize(d.plan, d.settings, d.audios.size, today)
        val pos = PlanEngine.currentPosition(today, d.audios, eff, d.settings)
        val currentIndex = (pos as? PlanPosition.Active)?.phaseIndex
        return LogAnalyzer.rows(d.audios, eff, d.settings, log.value, zone(), nextSession(nowMs), currentIndex)
    }

    // -------------------------------------------------------------- actions

    fun startPlan(startEpochDay: Long? = null) = repo.startPlan(startEpochDay)
    fun pausePlan() = repo.pausePlan()
    fun resumePlan() = repo.resumePlan()
    fun skipCurrentWeek() = repo.skipCurrent()
    fun repeatCurrentWeek() = repo.repeatCurrent()
    fun setStartDay(epochDay: Long) = repo.setStartDay(epochDay)
    fun setPhaseAudio(phaseIndex: Int, audioId: String?) = repo.setPhaseAudio(phaseIndex, audioId)

    fun playNow() {
        val r = repo.resolveCurrent(System.currentTimeMillis())
        if (r == null) {
            PlaybackStateHolder.post("أضف صوتاً أولاً قبل التشغيل.")
            return
        }
        TrainingPlaybackService.start(getApplication(), SessionType.MANUAL)
    }

    fun startTestSession() {
        val r = repo.resolveCurrent(System.currentTimeMillis())
        if (r == null) {
            PlaybackStateHolder.post("أضف صوتاً أولاً قبل الاختبار.")
            return
        }
        TrainingPlaybackService.start(getApplication(), SessionType.TEST)
    }

    fun previewAudio(audioId: String) =
        TrainingPlaybackService.start(getApplication(), SessionType.PREVIEW, audioId = audioId)

    fun stopPlayback() = TrainingPlaybackService.stop(getApplication())
    fun togglePlaybackPause() = TrainingPlaybackService.togglePause(getApplication())

    // --------------------------------------------------------------- audios

    fun addAudio(uri: Uri) {
        val app = getApplication<Application>()
        AudioUtils.takePermission(app, uri)
        val name = AudioUtils.displayName(app, uri) ?: "صوت"
        val duration = AudioUtils.durationMs(app, uri) ?: 0L
        repo.addAudio(AudioItem(id = TrainingRepository.newId(), uri = uri.toString(), name = name, durationMs = duration))
    }

    fun removeAudio(id: String) = repo.removeAudio(id)
    fun moveAudioUp(id: String) = repo.moveAudio(id, -1)
    fun moveAudioDown(id: String) = repo.moveAudio(id, +1)

    fun isAudioUsedInPlan(id: String): Boolean {
        val d = data.value
        return PlanEngine.isAudioUsed(id, d.audios, d.plan)
    }

    fun relinkAudio(id: String, uri: Uri) {
        val app = getApplication<Application>()
        AudioUtils.takePermission(app, uri)
        val name = AudioUtils.displayName(app, uri) ?: "صوت"
        val duration = AudioUtils.durationMs(app, uri) ?: 0L
        repo.relinkAudio(id, uri.toString(), name, duration)
    }

    fun isAudioAvailable(item: AudioItem): Boolean =
        try {
            AudioUtils.isAvailable(getApplication(), Uri.parse(item.uri))
        } catch (_: Exception) {
            false
        }

    // ------------------------------------------------------------- settings

    fun updateSettings(transform: (Settings) -> Settings) = repo.updateSettings(transform)

    fun setPhaseDays(days: Int) = updateSettings { it.copy(phaseDays = days) }
    fun setSessionMinutes(minutes: Int) = updateSettings { it.copy(sessionMinutes = minutes) }
    fun setVolumePercent(percent: Int) = updateSettings { it.copy(volumePercent = percent) }
    fun setAutoRepeat(enabled: Boolean) = updateSettings { it.copy(autoRepeat = enabled) }
    fun setMissedPolicy(policy: MissedPolicy) = updateSettings { it.copy(missedPolicy = policy) }

    fun addTime(minuteOfDay: Int) = updateSettings { it.copy(timesOfDay = it.timesOfDay + minuteOfDay) }
    fun removeTime(minuteOfDay: Int) = updateSettings { it.copy(timesOfDay = it.timesOfDay - minuteOfDay) }

    fun clearLog() = repo.clearLog()

    // --------------------------------------------------------- backup / restore

    fun exportPlan(): String = BackupManager.export(data.value)

    fun importPlan(text: String): Result<Unit> = try {
        val parsed = BackupManager.parse(text)
        repo.importData(parsed)
        Result.success(Unit)
    } catch (e: Exception) {
        Result.failure(e)
    }

    fun canScheduleExact(): Boolean = scheduler.canScheduleExact()
}

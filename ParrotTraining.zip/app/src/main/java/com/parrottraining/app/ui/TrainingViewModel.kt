package com.parrottraining.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.parrottraining.app.data.AudioUtils
import com.parrottraining.app.data.BackupManager
import com.parrottraining.app.data.TrainingRepository
import com.parrottraining.app.domain.AppData
import com.parrottraining.app.domain.AudioItem
import com.parrottraining.app.domain.LogAnalyzer
import com.parrottraining.app.domain.MissedPolicy
import com.parrottraining.app.domain.PhaseRow
import com.parrottraining.app.domain.PlanEngine
import com.parrottraining.app.domain.PlanPosition
import com.parrottraining.app.domain.SessionReaction
import com.parrottraining.app.domain.SessionRecord
import com.parrottraining.app.domain.SessionType
import com.parrottraining.app.domain.Settings
import com.parrottraining.app.playback.PlaybackStateHolder
import com.parrottraining.app.playback.TrainingPlaybackService
import com.parrottraining.app.scheduler.TrainingScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import com.parrottraining.app.data.ImageUtils
import java.time.ZoneId

/** Everything the UI needs, derived live from [TrainingRepository]. Never schedules anything itself. */
class TrainingViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = TrainingRepository.get(app)
    private val scheduler = TrainingScheduler(app)

    val data: StateFlow<AppData> = repo.data
    val log: StateFlow<List<SessionRecord>> = repo.log
    val playback: StateFlow<PlaybackStateHolder.UiState> = PlaybackStateHolder.state
    val messages: SharedFlow<String> = PlaybackStateHolder.messages

    init {
        // Keeps "day in phase" / "next session" fresh while a screen is open, and detects
        // missed sessions even if no alarm fires while the app happens to be in the foreground.
        viewModelScope.launch {
            while (true) {
                repo.refresh()
                delay(20_000)
            }
        }
    }

    fun refreshNow() = repo.refresh()

    private fun zone() = ZoneId.systemDefault()

    // ------------------------------------------------------------ home view

    fun currentPosition(nowMs: Long): PlanPosition {
        val d = data.value
        val today = PlanEngine.epochDayOf(nowMs, zone())
        val eff = PlanEngine.normalize(d.plan, d.settings, d.audios.size, today)
        return PlanEngine.currentPosition(today, d.audios, eff, d.settings)
    }

    fun nextSession(nowMs: Long) = data.value.let {
        PlanEngine.nextSession(nowMs, zone(), it.audios, it.plan, it.settings)
    }

    fun logRows(nowMs: Long): List<PhaseRow> {
        val d = data.value
        val today = PlanEngine.epochDayOf(nowMs, zone())
        val eff = PlanEngine.normalize(d.plan, d.settings, d.audios.size, today)
        val pos = PlanEngine.currentPosition(today, d.audios, eff, d.settings)
        val currentIndex = (pos as? PlanPosition.Active)?.phaseIndex
        return LogAnalyzer.rows(d.audios, eff, d.settings, log.value, zone(), nextSession(nowMs), currentIndex)
    }

    // -------------------------------------------------------------- actions

    fun startPlan(startEpochDay: Long? = null) = repo.startPlan(startEpochDay)
    fun pausePlan() = repo.pausePlan()
    fun resumePlan() = repo.resumePlan()
    fun skipCurrentWeek() = repo.skipCurrent()
    fun repeatCurrentWeek() = repo.repeatCurrent()
    fun setStartDay(epochDay: Long) = repo.setStartDay(epochDay)
    fun setPhaseAudio(phaseIndex: Int, audioId: String?) = repo.setPhaseAudio(phaseIndex, audioId)
    fun togglePhaseExtraAudio(phaseIndex: Int, audioId: String) = repo.togglePhaseExtraAudio(phaseIndex, audioId)

    fun playNow() {
        val r = repo.resolveCurrent(System.currentTimeMillis())
        if (r == null) {
            PlaybackStateHolder.post("أضف صوتاً أولاً قبل التشغيل.")
            return
        }
        TrainingPlaybackService.start(getApplication(), SessionType.MANUAL)
    }

    fun startTestSession() {
        val r = repo.resolveCurrent(System.currentTimeMillis())
        if (r == null) {
            PlaybackStateHolder.post("أضف صوتاً أولاً قبل الاختبار.")
            return
        }
        TrainingPlaybackService.start(getApplication(), SessionType.TEST)
    }

    fun previewAudio(audioId: String) =
        TrainingPlaybackService.start(getApplication(), SessionType.PREVIEW, audioId = audioId)

    fun stopPlayback() = TrainingPlaybackService.stop(getApplication())
    fun togglePlaybackPause() = TrainingPlaybackService.togglePause(getApplication())

    // --------------------------------------------------------------- audios

    fun addAudio(uri: Uri, video: Boolean = false) {
        val app = getApplication<Application>()
        AudioUtils.takePermission(app, uri)
        val name = AudioUtils.displayName(app, uri) ?: if (video) "فيديو" else "صوت"
        val duration = AudioUtils.durationMs(app, uri) ?: 0L
        val item = AudioItem(
            id = TrainingRepository.newId(), uri = uri.toString(), name = name, durationMs = duration, isVideo = video
        )
        if (video) repo.addVideo(item) else repo.addAudio(item)
    }

    /** Adds several video files picked at once. */
    fun addVideos(uris: List<Uri>) {
        uris.forEach { addAudio(it, video = true) }
    }

    /** Adds several audio files picked at once. */
    fun addAudios(uris: List<Uri>) {
        uris.forEach { addAudio(it) }
    }

    fun renameAudio(id: String, newName: String) = repo.renameAudio(id, newName)

    fun renameVideo(id: String, newName: String) = repo.renameVideo(id, newName)
    fun removeVideo(id: String) {
        data.value.videos.firstOrNull { it.id == id }?.let { AudioUtils.deleteOwnedFile(getApplication(), it.uri) }
        repo.removeVideo(id)
    }
    fun moveVideoUp(id: String) = repo.moveVideo(id, -1)
    fun moveVideoDown(id: String) = repo.moveVideo(id, +1)
    fun togglePhaseVideo(phaseIndex: Int, videoId: String) = repo.togglePhaseVideo(phaseIndex, videoId)

    fun isVideoUsedInPlan(id: String): Boolean = data.value.plan.videoByPhase.values.any { id in it }

    fun nextVideoSession(nowMs: Long) = data.value.let {
        PlanEngine.nextVideoSession(nowMs, zone(), it.audios, it.plan, it.settings)
    }

    fun removeAudio(id: String) {
        data.value.audios.firstOrNull { it.id == id }?.let { AudioUtils.deleteOwnedFile(getApplication(), it.uri) }
        repo.removeAudio(id)
    }
    fun moveAudioUp(id: String) = repo.moveAudio(id, -1)
    fun moveAudioDown(id: String) = repo.moveAudio(id, +1)

    fun isAudioUsedInPlan(id: String): Boolean {
        val d = data.value
        return PlanEngine.isAudioUsed(id, d.audios, d.plan)
    }

    fun relinkAudio(id: String, uri: Uri) {
        val app = getApplication<Application>()
        AudioUtils.takePermission(app, uri)
        val name = AudioUtils.displayName(app, uri) ?: "صوت"
        val duration = AudioUtils.durationMs(app, uri) ?: 0L
        repo.relinkAudio(id, uri.toString(), name, duration)
    }

    fun isAudioAvailable(item: AudioItem): Boolean =
        try {
            AudioUtils.isAvailable(getApplication(), Uri.parse(item.uri))
        } catch (_: Exception) {
            false
        }

    // ------------------------------------------------------------- settings

    fun updateSettings(transform: (Settings) -> Settings) = repo.updateSettings(transform)

    fun setPhaseDays(days: Int) = updateSettings { it.copy(phaseDays = days) }
    fun setSessionMinutes(minutes: Int) = updateSettings { it.copy(sessionMinutes = minutes) }
    fun setVolumePercent(percent: Int) = updateSettings { it.copy(volumePercent = percent) }
    fun setAutoRepeat(enabled: Boolean) = updateSettings { it.copy(autoRepeat = enabled) }
    fun setMissedPolicy(policy: MissedPolicy) = updateSettings { it.copy(missedPolicy = policy) }

    fun setTimeMinutes(timeOfDay: Int, minutes: Int) =
        updateSettings { it.copy(minutesByTime = it.minutesByTime + (timeOfDay to minutes)) }

    fun addTime(minuteOfDay: Int) = updateSettings { it.copy(timesOfDay = it.timesOfDay + minuteOfDay) }
    fun removeTime(minuteOfDay: Int) = updateSettings { it.copy(timesOfDay = it.timesOfDay - minuteOfDay) }

    /** ISO day-of-week: 1 = Monday ... 7 = Sunday. Toggles [day] in the set of active training days. */
    fun toggleActiveDay(day: Int) = updateSettings {
        val set = it.activeDaysOfWeek
        it.copy(activeDaysOfWeek = if (day in set) set - day else set + day)
    }

    // ---- video schedule (own times, own length per time, own days)
    fun addVideoTime(minuteOfDay: Int) = updateSettings { it.copy(videoTimes = it.videoTimes + minuteOfDay) }
    fun removeVideoTime(minuteOfDay: Int) = updateSettings { it.copy(videoTimes = it.videoTimes - minuteOfDay) }
    fun toggleVideoDay(day: Int) = updateSettings {
        val set = it.videoDaysOfWeek
        it.copy(videoDaysOfWeek = if (day in set) set - day else set + day)
    }

    fun setRecordSessions(enabled: Boolean) = updateSettings { it.copy(recordSessions = enabled) }
    fun setRecordHighQuality(enabled: Boolean) = updateSettings { it.copy(recordHighQuality = enabled) }

    fun setVibrateOnStart(enabled: Boolean) = updateSettings { it.copy(vibrateOnStart = enabled) }
    fun setAskReaction(enabled: Boolean) = updateSettings { it.copy(askReaction = enabled) }

    // ---- notification to another phone (iPhone) when a session starts
    fun setRemoteNotify(enabled: Boolean) = updateSettings {
        val topic = if (enabled && it.remoteTopic.isBlank()) {
            com.parrottraining.app.domain.RemoteMessages.randomTopic(java.security.SecureRandom())
        } else it.remoteTopic
        it.copy(remoteNotify = enabled, remoteTopic = topic)
    }
    fun setRemoteTopic(topic: String) = updateSettings { it.copy(remoteTopic = topic) }
    fun newRemoteTopic() = updateSettings {
        it.copy(remoteTopic = com.parrottraining.app.domain.RemoteMessages.randomTopic(java.security.SecureRandom()))
    }
    fun setRemoteServer(server: String) = updateSettings { it.copy(remoteServer = server) }
    fun setRemoteOnEnd(enabled: Boolean) = updateSettings { it.copy(remoteOnEnd = enabled) }
    fun setRemoteOnProblem(enabled: Boolean) = updateSettings { it.copy(remoteOnProblem = enabled) }

    /** Sends a test message and reports the result in plain words. */
    fun sendRemoteTest(onResult: (String) -> Unit) {
        val st = data.value.settings
        viewModelScope.launch(Dispatchers.IO) {
            val error = com.parrottraining.app.data.RemoteNotifier.sendBlocking(
                st, "🦜 تجربة", "وصل الإشعار بنجاح من تطبيق تدريب الببغاء"
            )
            kotlinx.coroutines.withContext(Dispatchers.Main) { onResult(error ?: "تم إرسال إشعار تجريبي، تحقق من جوالك الثاني") }
        }
    }
    fun setReaction(id: String, reaction: SessionReaction?) = repo.setReaction(id, reaction)

    fun clearLog() = repo.clearLog()

    fun setParrotName(name: String) = repo.setParrotName(name)

    /** Shrinks the picked photo to a small square off the main thread, then saves it. Null removes the photo. */
    fun setParrotPhoto(uri: Uri?) {
        if (uri == null) {
            repo.setParrotPhoto(null)
            return
        }
        val app = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val b64 = ImageUtils.squareThumbnailBase64(app, uri)
            if (b64 != null) repo.setParrotPhoto(b64) else PlaybackStateHolder.post("تعذر قراءة الصورة")
        }
    }

    // --------------------------------------------------------- backup / restore

    fun exportPlan(): String = BackupManager.export(data.value)

    /** Full backup with the audio and video files. Blocking: call from a background thread. */
    fun exportBackupZip(out: java.io.OutputStream): Int = BackupManager.exportZip(getApplication(), data.value, out)

    /** Restores a full (zip) or plan-only (json) backup. Blocking: call from a background thread. Returns the number of media files restored. */
    fun importBackup(input: java.io.InputStream): Result<Int> = try {
        val imported = BackupManager.importAuto(getApplication(), input)
        repo.importData(imported.data)
        Result.success(imported.mediaCount)
    } catch (e: Exception) {
        Result.failure(e)
    }

    fun importPlan(text: String): Result<Unit> = try {
        val parsed = BackupManager.parse(text)
        repo.importData(parsed)
        Result.success(Unit)
    } catch (e: Exception) {
        Result.failure(e)
    }

    fun canScheduleExact(): Boolean = scheduler.canScheduleExact()

    // --------------------------------------------------------- automatic backups

    /** Most recent automatic daily backups first (epoch days). */
    fun autoBackups(): List<Long> = repo.listAutoBackups()

    fun restoreAutoBackup(epochDay: Long): Boolean = repo.restoreAutoBackup(epochDay)

    // ------------------------------------------------------------- onboarding

    fun hasSeenOnboarding(): Boolean = repo.hasSeenOnboarding()
    fun setSeenOnboarding() = repo.setSeenOnboarding()

    // ----------------------------------------------------------- log summary

    /** 0..100, or null when there's nothing planned yet to measure against. */
    fun overallCompletionPercent(nowMs: Long): Int? {
        val rows = logRows(nowMs)
        return LogAnalyzer.overallCompletionPercent(rows)
    }
}

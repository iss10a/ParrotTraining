package com.parrottraining.app.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.parrottraining.app.domain.PlanPosition
import com.parrottraining.app.domain.PlanStatus
import com.parrottraining.app.domain.SessionType
import com.parrottraining.app.ui.TrainingViewModel
import com.parrottraining.app.util.msToClock
import com.parrottraining.app.util.rememberNow
import com.parrottraining.app.util.toClockStringFromMillis
import com.parrottraining.app.util.toDateStringFromMillis
import com.parrottraining.app.util.toEpochDayStringFull

@Composable
fun HomeScreen(viewModel: TrainingViewModel, onOpenReadiness: () -> Unit) {
    val data by viewModel.data.collectAsStateWithLifecycle()
    val log by viewModel.log.collectAsStateWithLifecycle()
    val playback by viewModel.playback.collectAsStateWithLifecycle()
    val now by rememberNow(1000L)

    val position = viewModel.currentPosition(now)
    val next = viewModel.nextSession(now)
    val plan = data.plan

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("تدريب الببغاء", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        StatusCard(plan.status, data.audios.isEmpty())

        if (playback.active) {
            PlaybackCard(playback, onTogglePause = viewModel::togglePlaybackPause, onStop = viewModel::stopPlayback)
        }

        when (position) {
            is PlanPosition.Active -> {
                val rows = viewModel.logRows(now)
                val row = rows.getOrNull(position.phaseIndex)
                InfoCard(position, next, row?.completed ?: 0, row?.missed ?: 0)
                ActionButtons(
                    viewModel = viewModel,
                    isPaused = plan.status == PlanStatus.PAUSED,
                    isActive = plan.status == PlanStatus.ACTIVE
                )
            }
            is PlanPosition.NotStarted -> StartCard(hasAudio = data.audios.isNotEmpty()) { viewModel.startPlan() }
            is PlanPosition.NoAudio -> EmptyAudioCard()
            is PlanPosition.BeforeStart -> Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("الخطة ستبدأ يوم ${position.startEpochDay.toEpochDayStringFull()}")
                    Text("لم تبدأ الخطة بعد، ستبدأ في تاريخها المحدد.")
                }
            }
            is PlanPosition.Completed -> Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("اكتملت الخطة.", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("يمكنك تفعيل \"إعادة البرنامج تلقائياً\" من الإعدادات أو بدء خطة جديدة.")
                }
            }
        }

        TextButton(onClick = onOpenReadiness) { Text("فحص جاهزية التدريب") }

        if (plan.status == PlanStatus.ACTIVE || plan.status == PlanStatus.PAUSED) {
            OutlinedButton(onClick = { viewModel.startTestSession() }, modifier = Modifier.fillMaxWidth()) {
                Text("اختبار جلسة (دقيقة واحدة)")
            }
        }
    }
}

@Composable
private fun StatusCard(status: PlanStatus, noAudio: Boolean) {
    val (dot, text) = when {
        noAudio -> "⚪" to "لا يوجد صوت بعد"
        status == PlanStatus.ACTIVE -> "🟢" to "التدريب فعال"
        status == PlanStatus.PAUSED -> "🟡" to "التدريب متوقف مؤقتاً"
        else -> "⚪" to "لم يبدأ التدريب بعد"
    }
    Text("$dot $text", style = MaterialTheme.typography.titleMedium)
}

@Composable
private fun InfoCard(position: PlanPosition.Active, next: com.parrottraining.app.domain.SessionSlot?, completed: Int, missed: Int) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("الأسبوع الحالي", style = MaterialTheme.typography.labelLarge)
            Text("الأسبوع ${position.phaseIndex + 1} من ${position.phaseCount}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { (position.dayInPhase.toFloat() / position.phaseLength.toFloat()).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth()
            )
            Text("اليوم ${position.dayInPhase} من ${position.phaseLength}")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("الصوت الحالي")
                Text(position.audio.name, fontWeight = FontWeight.Bold)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("الجلسة القادمة")
                Text(
                    if (next != null) "${next.epochMs.toDateStringFromMillis()} ${next.epochMs.toClockStringFromMillis()}"
                    else "لا توجد جلسة قادمة"
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("الجلسات المكتملة")
                Text("$completed")
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("الجلسات الفائتة")
                Text("$missed")
            }
        }
    }
}

@Composable
private fun PlaybackCard(playback: com.parrottraining.app.playback.PlaybackStateHolder.UiState, onTogglePause: () -> Unit, onStop: () -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (playback.preparing) "جاري التحضير..." else if (playback.paused) "متوقف مؤقتاً" else "قيد التشغيل الآن", fontWeight = FontWeight.Bold)
            Text(playback.audioName)
            if (!playback.preparing) Text("الوقت المتبقي: ${playback.remainingMs.msToClock()}", style = MaterialTheme.typography.headlineSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (playback.type != SessionType.PREVIEW) {
                    OutlinedButton(onClick = onTogglePause) {
                        Icon(if (playback.paused) Icons.Filled.PlayArrow else Icons.Filled.Pause, contentDescription = null)
                        Spacer(Modifier.size(4.dp))
                        Text(if (playback.paused) "استئناف" else "إيقاف مؤقت")
                    }
                }
                Button(onClick = onStop) {
                    Icon(Icons.Filled.Stop, contentDescription = null)
                    Spacer(Modifier.size(4.dp))
                    Text("إيقاف التشغيل الآن")
                }
            }
        }
    }
}

@Composable
private fun ActionButtons(viewModel: TrainingViewModel, isPaused: Boolean, isActive: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(onClick = { viewModel.playNow() }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Filled.PlayArrow, contentDescription = null)
            Spacer(Modifier.size(6.dp))
            Text("تشغيل الآن")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            if (isActive) {
                OutlinedButton(onClick = { viewModel.pausePlan() }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Pause, contentDescription = null)
                    Spacer(Modifier.size(4.dp))
                    Text("إيقاف مؤقت")
                }
            }
            if (isPaused) {
                Button(onClick = { viewModel.resumePlan() }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(Modifier.size(4.dp))
                    Text("استئناف")
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { viewModel.skipCurrentWeek() }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.SkipNext, contentDescription = null)
                Spacer(Modifier.size(4.dp))
                Text("تخطي الأسبوع")
            }
            OutlinedButton(onClick = { viewModel.repeatCurrentWeek() }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.Replay, contentDescription = null)
                Spacer(Modifier.size(4.dp))
                Text("إعادة الأسبوع")
            }
        }
    }
}

@Composable
private fun StartCard(hasAudio: Boolean, onStart: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("لم تبدأ خطة التدريب بعد.", style = MaterialTheme.typography.titleMedium)
            if (!hasAudio) {
                Text("أضف ملفاً صوتياً واحداً على الأقل من شاشة \"الأصوات\" قبل البدء.")
            } else {
                Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) { Text("بدء الخطة") }
            }
        }
    }
}

@Composable
private fun EmptyAudioCard() {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
        Column(Modifier.padding(16.dp)) {
            Text("لا يوجد ملف صوتي متاح لتشغيله.", fontWeight = FontWeight.Bold)
            Text("أضف صوتاً من شاشة \"الأصوات\" لمتابعة الخطة.")
        }
    }
}

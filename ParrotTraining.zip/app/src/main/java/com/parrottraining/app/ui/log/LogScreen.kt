package com.parrottraining.app.ui.log

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.parrottraining.app.domain.LogAnalyzer
import com.parrottraining.app.domain.PhaseRow
import com.parrottraining.app.domain.SessionReaction
import com.parrottraining.app.domain.SessionRecord
import com.parrottraining.app.ui.TrainingViewModel
import com.parrottraining.app.util.rememberNow
import com.parrottraining.app.util.toClockStringFromMillis
import com.parrottraining.app.util.toDateStringFromMillis
import com.parrottraining.app.util.toEpochDayString

@Composable
fun LogScreen(viewModel: TrainingViewModel) {
    val data by viewModel.data.collectAsStateWithLifecycle()
    val log by viewModel.log.collectAsStateWithLifecycle()
    val now by rememberNow(30_000L)
    val rows = viewModel.logRows(now)
    val overallPercent = viewModel.overallCompletionPercent(now)
    val recent = log.filter { it.isCompletedSession }.sortedByDescending { it.startedAtMs }.take(8)

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("سجل التدريب", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            if (log.isNotEmpty()) {
                TextButton(onClick = { viewModel.clearLog() }) { Text("مسح السجل") }
            }
        }

        if (overallPercent != null) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("نسبة الالتزام الإجمالية", fontWeight = FontWeight.Bold)
                        Text("$overallPercent%", fontWeight = FontWeight.Bold)
                    }
                    LinearProgressIndicator(
                        progress = { overallPercent / 100f },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        if (rows.isEmpty()) {
            Text("لا توجد بيانات بعد. ابدأ الخطة وأضف أصواتاً لتتبع التقدم.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (rows.any { it.hasReport }) {
                    item(key = "report") { ReportCard(rows) }
                }
                if (recent.isNotEmpty()) {
                    item(key = "recent") {
                        RecentSessionsCard(recent) { id, reaction -> viewModel.setReaction(id, reaction) }
                    }
                }
                items(rows, key = { it.phase.index }) { row -> LogRowCard(row) }
            }
        }
    }
}

@Composable
private fun LogRowCard(row: PhaseRow) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (row.isCurrent) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("الأسبوع ${row.phase.index + 1}", fontWeight = FontWeight.Bold)
            Text(row.audio?.name ?: "بلا صوت")
            Text("${row.phase.startEpochDay.toEpochDayString()} → ${row.phase.endInclusiveEpochDay.toEpochDayString()}")
            Text("${row.planned} جلسة مخططة")
            Text("${row.completed} مكتملة")
            Text("${row.missed} فائتة")
            row.avgActivityPercent?.let { Text("متوسط نشاط الببغاء في الجلسات المصوّرة: $it%") }
            if (row.voiceCount + row.mimicCount + row.noneCount > 0) {
                Text("التفاعل: رد بصوت ${row.voiceCount} • قلّد ${row.mimicCount} • ما تفاعل ${row.noneCount}")
            }
            row.lastError?.let {
                Text("آخر خطأ: $it", color = MaterialTheme.colorScheme.error)
            }
            row.lastSessionMs?.let { Text("آخر جلسة: ${it.toDateStringFromMillis()} ${it.toClockStringFromMillis()}") }
            row.nextSessionMs?.let { Text("الجلسة القادمة: ${it.toDateStringFromMillis()} ${it.toClockStringFromMillis()}") }
        }
    }
}


/** Bars of the average camera activity per week, plus the most active week. */
@Composable
private fun ReportCard(rows: List<PhaseRow>) {
    val withActivity = rows.filter { it.avgActivityPercent != null }
    val best = LogAnalyzer.mostActiveRow(rows)
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("تقرير الأسابيع", fontWeight = FontWeight.Bold)
            if (withActivity.isNotEmpty()) {
                Text("نشاط الببغاء (من حركة الكاميرا) في كل أسبوع")
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    withActivity.forEach { r ->
                        val pct = r.avgActivityPercent ?: 0
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$pct%")
                            Box(
                                Modifier
                                    .width(28.dp)
                                    .height(maxOf(3f, pct.coerceIn(0, 100) * 0.9f).dp)
                                    .background(MaterialTheme.colorScheme.primary)
                            )
                            Text("${r.phase.index + 1}")
                        }
                    }
                }
                best?.let {
                    Text("الأكثر نشاطاً: الأسبوع ${it.phase.index + 1}${it.audio?.name?.let { n -> " ($n)" } ?: ""} • ${it.avgActivityPercent}%")
                }
            }
            val voice = rows.sumOf { it.voiceCount }
            val mimic = rows.sumOf { it.mimicCount }
            val none = rows.sumOf { it.noneCount }
            if (voice + mimic + none > 0) {
                Text("إجمالي التفاعل المسجّل: رد بصوت $voice • قلّد $mimic • ما تفاعل $none")
            }
        }
    }
}

/** The latest finished sessions, so the owner can note (or change) how the parrot reacted. */
@Composable
private fun RecentSessionsCard(sessions: List<SessionRecord>, onReaction: (String, SessionReaction?) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("آخر الجلسات: كيف كان التفاعل؟", fontWeight = FontWeight.Bold)
            sessions.forEach { r ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "${r.startedAtMs.toDateStringFromMillis()} ${r.startedAtMs.toClockStringFromMillis()} • ${r.audioName}" +
                            (r.activityPercent?.let { " • نشاط $it%" } ?: "")
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            SessionReaction.VOICE to "رد بصوت",
                            SessionReaction.MIMIC to "قلّد",
                            SessionReaction.NONE to "ما تفاعل"
                        ).forEach { (reaction, label) ->
                            FilterChip(
                                selected = r.reaction == reaction,
                                onClick = { onReaction(r.id, if (r.reaction == reaction) null else reaction) },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }
        }
    }
}

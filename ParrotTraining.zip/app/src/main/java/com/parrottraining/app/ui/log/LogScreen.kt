package com.parrottraining.app.ui.log

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.parrottraining.app.domain.PhaseRow
import com.parrottraining.app.ui.TrainingViewModel
import com.parrottraining.app.util.rememberNow
import com.parrottraining.app.util.toClockStringFromMillis
import com.parrottraining.app.util.toDateStringFromMillis
import com.parrottraining.app.util.toEpochDayString

@Composable
fun LogScreen(viewModel: TrainingViewModel) {
    val data by viewModel.data.collectAsStateWithLifecycle()
    val log by viewModel.log.collectAsStateWithLifecycle()
    val now by rememberNow(30_000L)
    val rows = viewModel.logRows(now)

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("سجل التدريب", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            if (log.isNotEmpty()) {
                TextButton(onClick = { viewModel.clearLog() }) { Text("مسح السجل") }
            }
        }

        if (rows.isEmpty()) {
            Text("لا توجد بيانات بعد. ابدأ الخطة وأضف أصواتاً لتتبع التقدم.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(rows, key = { it.phase.index }) { row -> LogRowCard(row) }
            }
        }
    }
}

@Composable
private fun LogRowCard(row: PhaseRow) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (row.isCurrent) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("الأسبوع ${row.phase.index + 1}", fontWeight = FontWeight.Bold)
            Text(row.audio?.name ?: "بلا صوت")
            Text("${row.phase.startEpochDay.toEpochDayString()} → ${row.phase.endInclusiveEpochDay.toEpochDayString()}")
            Text("${row.planned} جلسة مخططة")
            Text("${row.completed} مكتملة")
            Text("${row.missed} فائتة")
            row.lastSessionMs?.let { Text("آخر جلسة: ${it.toDateStringFromMillis()} ${it.toClockStringFromMillis()}") }
            row.nextSessionMs?.let { Text("الجلسة القادمة: ${it.toDateStringFromMillis()} ${it.toClockStringFromMillis()}") }
        }
    }
}

package com.parrottraining.app.ui.nav

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Destination(val route: String, val label: String, val icon: ImageVector) {
    data object Home : Destination("home", "الرئيسية", Icons.Filled.Home)
    data object Plan : Destination("plan", "الخطة", Icons.Filled.List)
    data object Voices : Destination("voices", "الأصوات", Icons.Filled.MusicNote)
    data object Log : Destination("log", "السجل", Icons.Filled.List)
    data object Settings : Destination("settings", "الإعدادات", Icons.Filled.Settings)
    data object Readiness : Destination("readiness", "جاهزية التدريب", Icons.Filled.Settings)
}

val bottomBarDestinations = listOf(
    Destination.Home, Destination.Plan, Destination.Voices, Destination.Log, Destination.Settings
)

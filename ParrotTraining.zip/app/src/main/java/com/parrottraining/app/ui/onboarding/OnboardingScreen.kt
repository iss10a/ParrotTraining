package com.parrottraining.app.ui.onboarding

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

private data class OnboardingStep(val emoji: String, val title: String, val body: String)

private val steps = listOf(
    OnboardingStep("🎵", "1. أضف صوتاً", "من شاشة \"الأصوات\"، أضف ملف MP3 أو WAV واحد على الأقل — يمكنك إضافة عدة ملفات دفعة واحدة."),
    OnboardingStep("⏰", "2. اضبط الأوقات", "من \"الإعدادات\" حدّد أوقات التدريب اليومية، مدة الجلسة، وأيام الأسبوع التي يعمل بها التطبيق."),
    OnboardingStep("▶", "3. ابدأ الخطة", "من الشاشة الرئيسية أو شاشة \"الخطة\"، اضغط \"بدء الخطة\" — كل أسبوع يشغّل صوتاً واحداً فقط تلقائياً."),
    OnboardingStep("✓", "4. تأكد من الجاهزية", "افتح شاشة \"جاهزية التدريب\" وتأكد من تفعيل الإشعارات و Exact Alarm واستثناء التطبيق من تحسين البطارية، ليعمل حتى والشاشة مقفلة.")
)

@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "مرحباً بك في تدريب الببغاء 🦜",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Text("أربع خطوات بسيطة قبل ما تبدأ:", style = MaterialTheme.typography.bodyLarge)

        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            steps.forEach { step -> StepCard(step) }
        }

        Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) {
            Text("ابدأ", style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
private fun StepCard(step: OnboardingStep) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(step.emoji, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.size(40.dp), textAlign = TextAlign.Center)
            Column(Modifier.padding(start = 12.dp)) {
                Text(step.title, fontWeight = FontWeight.Bold)
                Text(step.body, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

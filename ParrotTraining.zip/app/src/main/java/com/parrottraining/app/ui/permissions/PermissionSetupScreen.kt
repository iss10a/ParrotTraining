package com.parrottraining.app.ui.permissions

import android.Manifest
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import com.parrottraining.app.util.PermissionHelper
import com.parrottraining.app.util.PermissionHelper.Step

/**
 * Asks for every permission the app needs, one after the other, like a normal Android app does on first open.
 * Pop-up permissions (notifications, camera) are asked directly; the others open the right Settings page, and
 * when the user comes back the next one is asked automatically. Nothing is forced: "later" always works.
 */
@Composable
fun PermissionSetupScreen(onFinished: () -> Unit, onMute: () -> Unit) {
    val ctx = LocalContext.current
    val handler = remember { Handler(Looper.getMainLooper()) }
    var tick by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(false) }
    // True while a Settings page is open; returning from it moves on to the next permission.
    var waitingForSettings by remember { mutableStateOf(false) }
    val attempted = remember { mutableStateListOf<Step>() }
    val advanceHolder = remember { arrayOfNulls<() -> Unit>(1) }

    fun scheduleAdvance() {
        // A short delay lets the screen finish coming back before the next page is opened.
        handler.postDelayed({ advanceHolder[0]?.invoke() }, 400L)
    }

    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        tick++
        if (running) scheduleAdvance()
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        tick++
        if (running) scheduleAdvance()
    }

    fun request(step: Step) {
        when (step) {
            Step.NOTIFICATIONS ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                else scheduleAdvance()
            Step.CAMERA -> cameraLauncher.launch(Manifest.permission.CAMERA)
            else -> {
                waitingForSettings = true
                if (!PermissionHelper.open(ctx, PermissionHelper.settingsIntents(ctx, step))) {
                    waitingForSettings = false
                    scheduleAdvance()
                }
            }
        }
    }

    fun advance() {
        if (!running) return
        val next = PermissionHelper.missing(ctx).firstOrNull { it !in attempted }
        if (next == null) {
            running = false
            tick++
            return
        }
        attempted.add(next)
        request(next)
    }
    SideEffect { advanceHolder[0] = { advance() } }

    val owner = ctx as? LifecycleOwner
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                tick++
                if (waitingForSettings) {
                    waitingForSettings = false
                    if (running) scheduleAdvance()
                }
            }
        }
        owner?.lifecycle?.addObserver(observer)
        onDispose {
            owner?.lifecycle?.removeObserver(observer)
            handler.removeCallbacksAndMessages(null)
        }
    }

    // Re-read the real state of every permission each time we come back (tick changes).
    val missing = remember(tick) { PermissionHelper.missing(ctx) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("صلاحيات التطبيق", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            if (missing.isEmpty()) "كل الصلاحيات جاهزة، التطبيق يشتغل بكامل قوته ✓"
            else "التطبيق يحتاج هذه الصلاحيات ليشغّل الجلسات في وقتها والجوال مقفل، ويصوّر. اضغط «منح الكل» وراح أسألك عنها واحدة واحدة."
        )

        Step.values().forEach { step ->
            val ok = step !in missing
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (ok) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text((if (ok) "✓ " else "✗ ") + step.title, fontWeight = FontWeight.Bold)
                        Text(step.why, style = MaterialTheme.typography.bodySmall)
                    }
                    if (!ok) {
                        OutlinedButton(onClick = { running = false; request(step) }) { Text("منح") }
                    }
                }
            }
        }

        if (missing.isNotEmpty()) {
            Button(
                onClick = {
                    attempted.clear()
                    running = true
                    advance()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (running) "جاري السؤال…" else "منح الكل") }
            OutlinedButton(onClick = onFinished, modifier = Modifier.fillMaxWidth()) { Text("لاحقاً") }
            TextButton(onClick = onMute, modifier = Modifier.fillMaxWidth()) { Text("لا تعرض هذه الشاشة مرة ثانية") }
        } else {
            Button(onClick = onFinished, modifier = Modifier.fillMaxWidth()) { Text("متابعة") }
        }
    }
}

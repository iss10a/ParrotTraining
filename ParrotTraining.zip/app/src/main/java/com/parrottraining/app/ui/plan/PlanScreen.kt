package com.parrottraining.app.ui.plan

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.parrottraining.app.domain.AudioItem
import com.parrottraining.app.domain.PlanEngine
import com.parrottraining.app.domain.PlanStatus
import com.parrottraining.app.ui.TrainingViewModel
import com.parrottraining.app.util.rememberNow
import com.parrottraining.app.util.toEpochDayString
import java.time.Instant
import java.time.ZoneId

@Composable
fun PlanScreen(viewModel: TrainingViewModel) {
    val data by viewModel.data.collectAsStateWithLifecycle()
    val now by rememberNow(30_000L)
    var showDatePicker by remember { mutableStateOf(false) }

    val today = PlanEngine.epochDayOf(now, ZoneId.systemDefault())
    val effPlan = PlanEngine.normalize(data.plan, data.settings, data.audios.size, today)
    val phases = PlanEngine.firstCycle(data.audios.size, effPlan, data.settings)

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("خطة التدريب", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            TextButton(onClick = { showDatePicker = true }) { Text("تغيير تاريخ البداية") }
        }

        if (data.audios.isEmpty()) {
            Text("أضف أصواتاً من شاشة \"الأصوات\" لبناء الخطة.")
        } else if (phases.isEmpty()) {
            Text("لا توجد مراحل بعد.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(phases, key = { it.index }) { phase ->
                    val audio = PlanEngine.audioForPhase(phase.index, data.audios, effPlan)
                    PhaseCard(
                        index = phase.index,
                        startDay = phase.startEpochDay,
                        endDay = phase.endInclusiveEpochDay,
                        audio = audio,
                        audios = data.audios,
                        onChangeAudio = { id -> viewModel.setPhaseAudio(phase.index, id) }
                    )
                }
            }
        }

        if (data.plan.status == PlanStatus.NOT_STARTED && data.audios.isNotEmpty()) {
            Button(onClick = { viewModel.startPlan() }, modifier = Modifier.fillMaxWidth()) { Text("بدء الخطة") }
        }
    }

    if (showDatePicker) {
        val state = rememberDatePickerState(
            initialSelectedDateMillis = data.plan.startEpochDay * 86_400_000L
        )
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { ms ->
                        val day = Instant.ofEpochMilli(ms).atZone(ZoneId.of("UTC")).toLocalDate().toEpochDay()
                        viewModel.setStartDay(day)
                    }
                    showDatePicker = false
                }) { Text("تأكيد") }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("إلغاء") } }
        ) { DatePicker(state = state) }
    }
}

@Composable
private fun PhaseCard(
    index: Int,
    startDay: Long,
    endDay: Long,
    audio: AudioItem?,
    audios: List<AudioItem>,
    onChangeAudio: (String?) -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("الأسبوع ${index + 1}", fontWeight = FontWeight.Bold)
            Text("الصوت: ${audio?.name ?: "لا يوجد"}")
            Text("${startDay.toEpochDayString()} → ${endDay.toEpochDayString()}")
            Row {
                OutlinedButton(onClick = { menuOpen = true }) { Text("تغيير الصوت") }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    audios.forEach { a ->
                        DropdownMenuItem(text = { Text(a.name) }, onClick = {
                            onChangeAudio(a.id)
                            menuOpen = false
                        })
                    }
                    DropdownMenuItem(text = { Text("استخدام الترتيب الافتراضي") }, onClick = {
                        onChangeAudio(null)
                        menuOpen = false
                    })
                }
            }
        }
    }
}

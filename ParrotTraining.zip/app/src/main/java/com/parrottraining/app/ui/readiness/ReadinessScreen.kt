package com.parrottraining.app.ui.readiness

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.parrottraining.app.ui.TrainingViewModel
import com.parrottraining.app.util.rememberNow

private data class Check(val ok: Boolean, val title: String, val hint: String?, val action: (() -> Unit)?)

@Composable
fun ReadinessScreen(viewModel: TrainingViewModel) {
    val data by viewModel.data.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val now by rememberNow(2000L) // re-checks permissions shortly after returning from Settings

    val hasAudio = data.audios.isNotEmpty()
    val hasPlan = data.plan.status != com.parrottraining.app.domain.PlanStatus.NOT_STARTED
    val isActive = data.plan.status == com.parrottraining.app.domain.PlanStatus.ACTIVE

    val notificationsEnabled = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    } else true

    val exactAlarmAvailable = viewModel.canScheduleExact()

    val batteryOk = remember_(now) {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    fun openNotificationSettings() {
        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        context.startActivity(intent)
    }

    fun openExactAlarmSettings() {
        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
            .setData(Uri.parse("package:${context.packageName}"))
        context.startActivity(intent)
    }

    fun openBatterySettings() {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                .setData(Uri.parse("package:${context.packageName}"))
            context.startActivity(intent)
        } catch (_: Exception) {
            context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    val checks = listOf(
        Check(hasAudio, "يوجد ملف صوتي", if (!hasAudio) "أضف صوتاً واحداً على الأقل من شاشة الأصوات" else null, null),
        Check(hasPlan, "توجد خطة تدريب", if (!hasPlan) "ابدأ الخطة من الشاشة الرئيسية" else null, null),
        Check(isActive, "التدريب مفعل", if (!isActive) "الخطة متوقفة مؤقتاً أو لم تبدأ" else null, null),
        Check(
            notificationsEnabled, "الإشعارات مفعلة",
            if (!notificationsEnabled) "السماح بالتنبيهات غير مفعل" else null,
            if (!notificationsEnabled) ::openNotificationSettings else null
        ),
        Check(
            exactAlarmAvailable, "Exact Alarm متاح",
            if (!exactAlarmAvailable) "التنبيهات الدقيقة غير مسموحة لهذا التطبيق" else null,
            if (!exactAlarmAvailable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) ::openExactAlarmSettings else null
        ),
        Check(
            batteryOk, "البطارية مناسبة",
            if (!batteryOk) "قد يوقف النظام أو الشركة المصنعة التطبيق في الخلفية لتوفير البطارية" else null,
            if (!batteryOk) ::openBatterySettings else null
        ),
        Check(true, "خدمة التشغيل جاهزة", null, null)
    )

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("جاهزية التدريب", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "ملاحظة: بعض أجهزة الشركات المصنعة (مثل ASUS) تضيف قيود بطارية إضافية خاصة بها، " +
                "وقد لا تكفي إعدادات Android القياسية وحدها لضمان عمل التطبيق في الخلفية دائماً."
        )
        checks.forEach { c -> CheckRow(c) }
    }
}

@Composable
private fun CheckRow(check: Check) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (check.ok) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
        )
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text((if (check.ok) "✓ " else "✗ ") + check.title, fontWeight = FontWeight.Bold)
            }
            check.hint?.let { Text(it) }
            check.action?.let { action ->
                TextButton(onClick = action) { Text("فتح الإعدادات") }
            }
        }
    }
}

@Composable
private fun <T> remember_(key: Any?, calc: () -> T): T = androidx.compose.runtime.remember(key) { calc() }

package com.parrottraining.app.ui.settings

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.parrottraining.app.domain.MissedPolicy
import com.parrottraining.app.ui.TrainingViewModel
import com.parrottraining.app.util.toClockString
import com.parrottraining.app.util.toEpochDayStringFull
import java.io.OutputStreamWriter

private val phaseDayOptions = listOf(3, 5, 7, 10, 14)
private val sessionMinuteOptions = listOf(1, 5, 10, 15, 30, 60)

@Composable
fun SettingsScreen(viewModel: TrainingViewModel, onOpenReadiness: () -> Unit) {
    val data by viewModel.data.collectAsStateWithLifecycle()
    val settings = data.settings
    val context = LocalContext.current

    var showTimePicker by remember { mutableStateOf(false) }
    var showCustomPhase by remember { mutableStateOf(false) }
    var showCustomSession by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    OutputStreamWriter(out).use { it.write(viewModel.exportPlan()) }
                }
                Toast.makeText(context, "تم تصدير الخطة", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "تعذر تصدير الخطة", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                if (text != null) {
                    val result = viewModel.importPlan(text)
                    Toast.makeText(
                        context,
                        if (result.isSuccess) "تم استيراد الخطة. قد تحتاج لإعادة اختيار ملفات الصوت." else "ملف غير صالح",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "تعذر قراءة الملف", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        SectionTitle("مدة المرحلة (بالأيام)")
        ChipRow(
            options = phaseDayOptions,
            selected = settings.phaseDays,
            onSelect = { viewModel.setPhaseDays(it) },
            onCustom = { showCustomPhase = true }
        )

        SectionTitle("مدة الجلسة (بالدقائق)")
        ChipRow(
            options = sessionMinuteOptions,
            selected = settings.sessionMinutes,
            onSelect = { viewModel.setSessionMinutes(it) },
            onCustom = { showCustomSession = true }
        )

        SectionTitle("أوقات التدريب اليومية")
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            settings.timesOfDay.sorted().forEach { t ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(t.toClockString())
                    IconButton(onClick = { viewModel.removeTime(t) }) {
                        Icon(Icons.Filled.Close, contentDescription = "حذف الوقت")
                    }
                }
            }
            OutlinedButton(onClick = { showTimePicker = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Text(" إضافة وقت")
            }
        }

        SectionTitle("أيام التدريب")
        DaysOfWeekRow(selected = settings.activeDaysOfWeek, onToggle = { viewModel.toggleActiveDay(it) })

        SectionTitle("مستوى صوت التدريب")
        Column {
            Slider(
                value = settings.volumePercent.toFloat(),
                onValueChange = { viewModel.setVolumePercent(it.toInt()) },
                valueRange = 0f..100f,
                steps = 3
            )
            Text("${settings.volumePercent}%")
        }

        SectionTitle("إعادة البرنامج تلقائياً")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("بعد انتهاء آخر أسبوع، تبدأ الخطة من جديد")
            Switch(checked = settings.autoRepeat, onCheckedChange = { viewModel.setAutoRepeat(it) })
        }

        SectionTitle("اهتزاز عند بدء الجلسة")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("اهتزاز قصير عند بداية كل جلسة تدريب فعلية (مفيد لو الهاتف بعيد عنك)")
            Switch(checked = settings.vibrateOnStart, onCheckedChange = { viewModel.setVibrateOnStart(it) })
        }

        SectionTitle("عند تفويت جلسة")
        Column {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                RadioButton(selected = settings.missedPolicy == MissedPolicy.IGNORE, onClick = { viewModel.setMissedPolicy(MissedPolicy.IGNORE) })
                Text("تجاهل الجلسة")
            }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                RadioButton(selected = settings.missedPolicy == MissedPolicy.MAKEUP, onClick = { viewModel.setMissedPolicy(MissedPolicy.MAKEUP) })
                Text("تشغيل جلسة تعويضية لاحقاً")
            }
        }

        SectionTitle("النسخ الاحتياطي")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { exportLauncher.launch("parrot_training_plan.json") }) { Text("تصدير الخطة") }
            OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain")) }) { Text("استيراد الخطة") }
        }

        val autoBackups = viewModel.autoBackups()
        if (autoBackups.isNotEmpty()) {
            SectionTitle("نسخ احتياطية تلقائية")
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("يحفظ التطبيق نسخة تلقائياً كل يوم بدون تدخل منك، للطوارئ فقط.")
                autoBackups.forEach { day ->
                    var showConfirm by remember(day) { mutableStateOf(false) }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(day.toEpochDayStringFull())
                        TextButton(onClick = { showConfirm = true }) { Text("استعادة") }
                    }
                    if (showConfirm) {
                        AlertDialog(
                            onDismissRequest = { showConfirm = false },
                            title = { Text("استعادة نسخة ${day.toEpochDayStringFull()}؟") },
                            text = { Text("سيتم استبدال الخطة والإعدادات الحالية بهذه النسخة. قد تحتاج لإعادة اختيار ملفات الصوت.") },
                            confirmButton = {
                                TextButton(onClick = {
                                    val ok = viewModel.restoreAutoBackup(day)
                                    Toast.makeText(context, if (ok) "تمت الاستعادة" else "تعذرت الاستعادة", Toast.LENGTH_SHORT).show()
                                    showConfirm = false
                                }) { Text("استعادة") }
                            },
                            dismissButton = { TextButton(onClick = { showConfirm = false }) { Text("إلغاء") } }
                        )
                    }
                }
            }
        }

        SectionTitle("جاهزية التطبيق")
        OutlinedButton(onClick = onOpenReadiness, modifier = Modifier.fillMaxWidth()) { Text("فحص جاهزية التدريب") }

        SectionTitle("اختبار")
        OutlinedButton(onClick = { viewModel.startTestSession() }, modifier = Modifier.fillMaxWidth()) {
            Text("اختبار جلسة (دقيقة واحدة)")
        }
    }

    if (showTimePicker) {
        val state = rememberTimePickerState(initialHour = 6, initialMinute = 0, is24Hour = false)
        AlertDialog(
            onDismissRequest = { showTimePicker = false },
            title = { Text("إضافة وقت تدريب") },
            text = { TimePicker(state = state) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.addTime(state.hour * 60 + state.minute)
                    showTimePicker = false
                }) { Text("إضافة") }
            },
            dismissButton = { TextButton(onClick = { showTimePicker = false }) { Text("إلغاء") } }
        )
    }

    if (showCustomPhase) {
        NumberInputDialog(
            title = "عدد أيام المرحلة",
            initial = settings.phaseDays,
            onConfirm = { viewModel.setPhaseDays(it); showCustomPhase = false },
            onDismiss = { showCustomPhase = false }
        )
    }

    if (showCustomSession) {
        NumberInputDialog(
            title = "مدة الجلسة بالدقائق",
            initial = settings.sessionMinutes,
            onConfirm = { viewModel.setSessionMinutes(it); showCustomSession = false },
            onDismiss = { showCustomSession = false }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
}

@Composable
private fun ChipRow(options: List<Int>, selected: Int, onSelect: (Int) -> Unit, onCustom: () -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(options) { value ->
            FilterChip(selected = selected == value, onClick = { onSelect(value) }, label = { Text("$value") })
        }
        item {
            AssistChip(onClick = onCustom, label = { Text(if (selected in options) "مخصص" else "مخصص ($selected)") })
        }
    }
}

private val dayLabels = listOf(1 to "اثنين", 2 to "ثلاثاء", 3 to "أربعاء", 4 to "خميس", 5 to "جمعة", 6 to "سبت", 7 to "أحد")

@Composable
private fun DaysOfWeekRow(selected: Set<Int>, onToggle: (Int) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(dayLabels) { (day, label) ->
            FilterChip(selected = day in selected, onClick = { onToggle(day) }, label = { Text(label) })
        }
    }
}

@Composable
private fun NumberInputDialog(title: String, initial: Int, onConfirm: (Int) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial.toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.filter { c -> c.isDigit() } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        },
        confirmButton = {
            TextButton(onClick = { text.toIntOrNull()?.let(onConfirm) }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

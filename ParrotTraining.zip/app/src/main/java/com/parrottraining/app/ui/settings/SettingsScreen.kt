package com.parrottraining.app.ui.settings

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.parrottraining.app.domain.MissedPolicy
import com.parrottraining.app.domain.ParrotProfile
import com.parrottraining.app.ui.profile.ParrotAvatar
import com.parrottraining.app.ui.TrainingViewModel
import com.parrottraining.app.util.toClockString
import com.parrottraining.app.util.toEpochDayStringFull
import java.io.OutputStreamWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val phaseDayOptions = listOf(3, 5, 7, 10, 14)
private val sessionMinuteOptions = listOf(1, 5, 10, 15, 30, 60)

@Composable
fun SettingsScreen(viewModel: TrainingViewModel, onOpenReadiness: () -> Unit) {
    val data by viewModel.data.collectAsStateWithLifecycle()
    val settings = data.settings
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showTopicDialog by remember { mutableStateOf(false) }
    var showServerDialog by remember { mutableStateOf(false) }

    var showTimePicker by remember { mutableStateOf(false) }
    var showCustomPhase by remember { mutableStateOf(false) }
    var showCustomSession by remember { mutableStateOf(false) }
    var editingTime by remember { mutableStateOf<Int?>(null) }
    var showVideoTimePicker by remember { mutableStateOf(false) }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) viewModel.setRecordSessions(true)
        else Toast.makeText(context, "لا يمكن تفعيل التصوير بدون إذن الكاميرا", Toast.LENGTH_LONG).show()
    }

    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) viewModel.setParrotPhoto(uri)
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    OutputStreamWriter(out).use { it.write(viewModel.exportPlan()) }
                }
                Toast.makeText(context, "تم تصدير الخطة", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "تعذر تصدير الخطة", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val zipExportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            Toast.makeText(context, "جارٍ إنشاء النسخة الكاملة، قد يستغرق ذلك وقتاً…", Toast.LENGTH_LONG).show()
            scope.launch(Dispatchers.IO) {
                val msg = try {
                    val n = context.contentResolver.openOutputStream(uri)?.use { out -> viewModel.exportBackupZip(out) } ?: -1
                    if (n >= 0) "تم إنشاء النسخة الكاملة ($n ملف صوت وفيديو)" else "تعذر إنشاء الملف"
                } catch (e: Exception) {
                    "تعذر إنشاء النسخة الكاملة"
                }
                withContext(Dispatchers.Main) { Toast.makeText(context, msg, Toast.LENGTH_LONG).show() }
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            Toast.makeText(context, "جارٍ الاستيراد…", Toast.LENGTH_SHORT).show()
            scope.launch(Dispatchers.IO) {
                val msg = try {
                    val result = context.contentResolver.openInputStream(uri)?.use { viewModel.importBackup(it) }
                    when {
                        result == null -> "تعذر قراءة الملف"
                        result.isFailure -> "ملف غير صالح"
                        result.getOrDefault(0) > 0 -> "تم استيراد الخطة والملفات (${result.getOrDefault(0)})"
                        else -> "تم استيراد الخطة. قد تحتاج لإعادة اختيار ملفات الصوت."
                    }
                } catch (e: Exception) {
                    "تعذر قراءة الملف"
                }
                withContext(Dispatchers.Main) { Toast.makeText(context, msg, Toast.LENGTH_LONG).show() }
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        SectionTitle("ملف الببغاء")
        ParrotProfileEditor(
            profile = data.profile,
            onSaveName = { viewModel.setParrotName(it) },
            onPickPhoto = { photoLauncher.launch("image/*") },
            onRemovePhoto = { viewModel.setParrotPhoto(null) }
        )

        SectionTitle("مدة المرحلة (بالأيام)")
        ChipRow(
            options = phaseDayOptions,
            selected = settings.phaseDays,
            onSelect = { viewModel.setPhaseDays(it) },
            onCustom = { showCustomPhase = true }
        )

        SectionTitle("المدة الافتراضية للجلسة (بالدقائق)")
        ChipRow(
            options = sessionMinuteOptions,
            selected = settings.sessionMinutes,
            onSelect = { viewModel.setSessionMinutes(it) },
            onCustom = { showCustomSession = true }
        )

        SectionTitle("أوقات التدريب اليومية (وكل وقت له مدته)")
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            settings.timesOfDay.sorted().forEach { t ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(t.toClockString())
                    TextButton(onClick = { editingTime = t }) { Text("${settings.minutesFor(t)} دقيقة") }
                    IconButton(onClick = { viewModel.removeTime(t) }) {
                        Icon(Icons.Filled.Close, contentDescription = "حذف الوقت")
                    }
                }
            }
            OutlinedButton(onClick = { showTimePicker = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Text(" إضافة وقت")
            }
        }

        SectionTitle("أيام التدريب")
        DaysOfWeekRow(selected = settings.activeDaysOfWeek, onToggle = { viewModel.toggleActiveDay(it) })

        SectionTitle("جدول الفيديو (أوقات وأيام مستقلة عن الصوت)")
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("اختر فيديو كل أسبوع من شاشة الخطة. يفتح الفيديو في هذه الأوقات وفي الأيام المحددة فقط، ويشتغل كل فيديو مرة واحدة حتى ينتهي، والجلسة تنتهي بنهاية آخر فيديو.")
            settings.videoTimes.sorted().forEach { t ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(t.toClockString())
                    IconButton(onClick = { viewModel.removeVideoTime(t) }) {
                        Icon(Icons.Filled.Close, contentDescription = "حذف وقت الفيديو")
                    }
                }
            }
            OutlinedButton(onClick = { showVideoTimePicker = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Text(" إضافة وقت فيديو")
            }
            Text("أيام الفيديو")
            DaysOfWeekRow(selected = settings.videoDaysOfWeek, onToggle = { viewModel.toggleVideoDay(it) })
        }

        SectionTitle("مستوى صوت التدريب")
        Column {
            Slider(
                value = settings.volumePercent.toFloat(),
                onValueChange = { viewModel.setVolumePercent(it.toInt()) },
                valueRange = 0f..100f,
                steps = 3
            )
            Text("${settings.volumePercent}%")
        }

        SectionTitle("إعادة البرنامج تلقائياً")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("بعد انتهاء آخر أسبوع، تبدأ الخطة من جديد")
            Switch(checked = settings.autoRepeat, onCheckedChange = { viewModel.setAutoRepeat(it) })
        }

        SectionTitle("اهتزاز عند بدء الجلسة")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("اهتزاز قصير عند بداية كل جلسة تدريب فعلية (مفيد لو الهاتف بعيد عنك)")
            Switch(checked = settings.vibrateOnStart, onCheckedChange = { viewModel.setVibrateOnStart(it) })
        }

        SectionTitle("سؤال عن تفاعل الببغاء")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("بعد كل جلسة يظهر إشعار هادئ بثلاثة أزرار (رد بصوت / قلّد / ما تفاعل) لتسجيل تفاعل الببغاء", modifier = Modifier.weight(1f))
            Switch(checked = settings.askReaction, onCheckedChange = { viewModel.setAskReaction(it) })
        }

        SectionTitle("تصوير الجلسات بالكاميرا الأمامية")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                "تصوير فيديو صامت في الخلفية مع كل جلسة (صوت أو فيديو) لمراقبة الببغاء. يُحفظ في الاستوديو ضمن مجلد ParrotTraining ويُحذف تلقائياً بعد 7 أيام.",
                modifier = Modifier.weight(1f)
            )
            Switch(
                checked = settings.recordSessions,
                onCheckedChange = { on ->
                    when {
                        !on -> viewModel.setRecordSessions(false)
                        com.parrottraining.app.playback.SessionRecorderService.hasCameraPermission(context) -> viewModel.setRecordSessions(true)
                        else -> cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
                    }
                }
            )
        }
        if (settings.recordSessions) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("جودة أعلى (720p، حجم ملفات أكبر)", modifier = Modifier.weight(1f))
                Switch(checked = settings.recordHighQuality, onCheckedChange = { viewModel.setRecordHighQuality(it) })
            }
        }

        SectionTitle("عند تفويت جلسة")
        Column {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                RadioButton(selected = settings.missedPolicy == MissedPolicy.IGNORE, onClick = { viewModel.setMissedPolicy(MissedPolicy.IGNORE) })
                Text("تجاهل الجلسة")
            }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                RadioButton(selected = settings.missedPolicy == MissedPolicy.MAKEUP, onClick = { viewModel.setMissedPolicy(MissedPolicy.MAKEUP) })
                Text("تشغيل جلسة تعويضية لاحقاً")
            }
        }

        SectionTitle("إشعار على جوال آخر (مثل الآيفون)")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                "إرسال إشعار إلى جوالك الثاني عند بدء كل جلسة، عبر تطبيق ntfy المجاني (مفتوح المصدر). يحتاج إنترنت على هذا الجوال.",
                modifier = Modifier.weight(1f)
            )
            Switch(checked = settings.remoteNotify, onCheckedChange = { viewModel.setRemoteNotify(it) })
        }
        if (settings.remoteNotify) {
            Text("اسم الموضوع: ${settings.remoteTopic}")
            Text("الخادم: ${settings.remoteServer}")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { showTopicDialog = true }) { Text("تغيير الاسم") }
                OutlinedButton(onClick = { viewModel.newRemoteTopic() }) { Text("اسم عشوائي جديد") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { showServerDialog = true }) { Text("تغيير الخادم") }
                Button(onClick = {
                    viewModel.sendRemoteTest { msg -> Toast.makeText(context, msg, Toast.LENGTH_LONG).show() }
                }) { Text("إرسال تجربة") }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("إشعار عند انتهاء الجلسة", modifier = Modifier.weight(1f))
                Switch(checked = settings.remoteOnEnd, onCheckedChange = { viewModel.setRemoteOnEnd(it) })
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("إشعار عند حدوث مشكلة (ملف مفقود، فشل الكاميرا…)", modifier = Modifier.weight(1f))
                Switch(checked = settings.remoteOnProblem, onCheckedChange = { viewModel.setRemoteOnProblem(it) })
            }
            Text(
                "على الآيفون: ثبّت تطبيق ntfy من App Store، اضغط +، واكتب اسم الموضوع أعلاه بالضبط، واترك الخادم ntfy.sh. " +
                    "اسم الموضوع يعمل مثل كلمة السر، فلا تشاركه مع أحد."
            )
        }

        SectionTitle("النسخ الاحتياطي")
        Text("النسخة الكاملة تحفظ الخطة مع كل ملفات الصوت والفيديو، فعند الاستعادة لا تحتاج تضيف شيء من جديد. حجمها بحجم ملفاتك.")
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { zipExportLauncher.launch("parrot_training_backup.zip") }) { Text("نسخة كاملة (خطة + صوت + فيديو)") }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { exportLauncher.launch("parrot_training_plan.json") }) { Text("تصدير الخطة فقط") }
                OutlinedButton(onClick = {
                    importLauncher.launch(
                        arrayOf("application/zip", "application/x-zip-compressed", "application/json", "text/plain", "application/octet-stream")
                    )
                }) { Text("استيراد نسخة") }
            }
        }

        val autoBackups = viewModel.autoBackups()
        if (autoBackups.isNotEmpty()) {
            SectionTitle("نسخ احتياطية تلقائية")
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("يحفظ التطبيق نسخة تلقائياً كل يوم بدون تدخل منك، للطوارئ فقط.")
                autoBackups.forEach { day ->
                    var showConfirm by remember(day) { mutableStateOf(false) }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(day.toEpochDayStringFull())
                        TextButton(onClick = { showConfirm = true }) { Text("استعادة") }
                    }
                    if (showConfirm) {
                        AlertDialog(
                            onDismissRequest = { showConfirm = false },
                            title = { Text("استعادة نسخة ${day.toEpochDayStringFull()}؟") },
                            text = { Text("سيتم استبدال الخطة والإعدادات الحالية بهذه النسخة. قد تحتاج لإعادة اختيار ملفات الصوت.") },
                            confirmButton = {
                                TextButton(onClick = {
                                    val ok = viewModel.restoreAutoBackup(day)
                                    Toast.makeText(context, if (ok) "تمت الاستعادة" else "تعذرت الاستعادة", Toast.LENGTH_SHORT).show()
                                    showConfirm = false
                                }) { Text("استعادة") }
                            },
                            dismissButton = { TextButton(onClick = { showConfirm = false }) { Text("إلغاء") } }
                        )
                    }
                }
            }
        }

        SectionTitle("جاهزية التطبيق")
        OutlinedButton(onClick = onOpenReadiness, modifier = Modifier.fillMaxWidth()) { Text("فحص جاهزية التدريب") }

        SectionTitle("اختبار")
        OutlinedButton(onClick = { viewModel.startTestSession() }, modifier = Modifier.fillMaxWidth()) {
            Text("اختبار جلسة (دقيقة واحدة)")
        }
    }

    if (showTimePicker) {
        val state = rememberTimePickerState(initialHour = 6, initialMinute = 0, is24Hour = false)
        AlertDialog(
            onDismissRequest = { showTimePicker = false },
            title = { Text("إضافة وقت تدريب") },
            text = { TimePicker(state = state) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.addTime(state.hour * 60 + state.minute)
                    showTimePicker = false
                }) { Text("إضافة") }
            },
            dismissButton = { TextButton(onClick = { showTimePicker = false }) { Text("إلغاء") } }
        )
    }

    if (showVideoTimePicker) {
        val vState = rememberTimePickerState(initialHour = 9, initialMinute = 0, is24Hour = false)
        AlertDialog(
            onDismissRequest = { showVideoTimePicker = false },
            title = { Text("إضافة وقت فيديو") },
            text = { TimePicker(state = vState) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.addVideoTime(vState.hour * 60 + vState.minute)
                    showVideoTimePicker = false
                }) { Text("إضافة") }
            },
            dismissButton = { TextButton(onClick = { showVideoTimePicker = false }) { Text("إلغاء") } }
        )
    }

    if (showTopicDialog) {
        TextInputDialog(
            title = "اسم الموضوع (حروف إنجليزية وأرقام و - _ فقط)",
            initial = settings.remoteTopic,
            onConfirm = { viewModel.setRemoteTopic(it); showTopicDialog = false },
            onDismiss = { showTopicDialog = false }
        )
    }

    if (showServerDialog) {
        TextInputDialog(
            title = "عنوان خادم ntfy",
            initial = settings.remoteServer,
            onConfirm = { viewModel.setRemoteServer(it); showServerDialog = false },
            onDismiss = { showServerDialog = false }
        )
    }

    editingTime?.let { t ->
        NumberInputDialog(
            title = "مدة جلسة ${t.toClockString()} بالدقائق",
            initial = settings.minutesFor(t),
            onConfirm = { viewModel.setTimeMinutes(t, it); editingTime = null },
            onDismiss = { editingTime = null }
        )
    }

    if (showCustomPhase) {
        NumberInputDialog(
            title = "عدد أيام المرحلة",
            initial = settings.phaseDays,
            onConfirm = { viewModel.setPhaseDays(it); showCustomPhase = false },
            onDismiss = { showCustomPhase = false }
        )
    }

    if (showCustomSession) {
        NumberInputDialog(
            title = "مدة الجلسة بالدقائق",
            initial = settings.sessionMinutes,
            onConfirm = { viewModel.setSessionMinutes(it); showCustomSession = false },
            onDismiss = { showCustomSession = false }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
}

@Composable
private fun ChipRow(options: List<Int>, selected: Int, onSelect: (Int) -> Unit, onCustom: () -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(options) { value ->
            FilterChip(selected = selected == value, onClick = { onSelect(value) }, label = { Text("$value") })
        }
        item {
            AssistChip(onClick = onCustom, label = { Text(if (selected in options) "مخصص" else "مخصص ($selected)") })
        }
    }
}

private val dayLabels = listOf(1 to "اثنين", 2 to "ثلاثاء", 3 to "أربعاء", 4 to "خميس", 5 to "جمعة", 6 to "سبت", 7 to "أحد")

@Composable
private fun DaysOfWeekRow(selected: Set<Int>, onToggle: (Int) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(dayLabels) { (day, label) ->
            FilterChip(selected = day in selected, onClick = { onToggle(day) }, label = { Text(label) })
        }
    }
}

@Composable
private fun NumberInputDialog(title: String, initial: Int, onConfirm: (Int) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial.toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.filter { c -> c.isDigit() } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        },
        confirmButton = {
            TextButton(onClick = { text.toIntOrNull()?.let(onConfirm) }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}


@Composable
private fun TextInputDialog(title: String, initial: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { onConfirm(text.trim()) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun ParrotProfileEditor(
    profile: ParrotProfile,
    onSaveName: (String) -> Unit,
    onPickPhoto: () -> Unit,
    onRemovePhoto: () -> Unit
) {
    var name by remember(profile.name) { mutableStateOf(profile.name) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            ParrotAvatar(profile, 72.dp)
            OutlinedButton(onClick = onPickPhoto) { Text("اختيار صورة") }
            if (profile.photoBase64 != null) TextButton(onClick = onRemovePhoto) { Text("إزالة") }
        }
        OutlinedTextField(
            value = name,
            onValueChange = { name = it.take(40) },
            label = { Text("اسم الببغاء") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        if (name.trim() != profile.name) {
            Button(onClick = { onSaveName(name) }) { Text("حفظ الاسم") }
        }
        Text("الاسم والصورة يُحفظان داخل ملف تصدير الخطة، فيرجعون معك عند تغيير الجوال.")
    }
}

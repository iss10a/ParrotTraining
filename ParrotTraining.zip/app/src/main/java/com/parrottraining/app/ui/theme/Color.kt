package com.parrottraining.app.ui.theme

import androidx.compose.ui.graphics.Color

// Calm purple palette, as requested (لون رئيسي بنفسجي).
val PurplePrimary = Color(0xFF6A3DB8)
val PurplePrimaryDark = Color(0xFFB79CF0)
val PurpleOnPrimary = Color(0xFFFFFFFF)
val PurpleOnPrimaryDark = Color(0xFF1B0E3A)
val PurpleContainer = Color(0xFFE9DDFF)
val PurpleOnContainer = Color(0xFF250F55)

val SecondaryTeal = Color(0xFF5C6472)
val SuccessGreen = Color(0xFF2E7D32)
val WarningAmber = Color(0xFFB26A00)
val ErrorRed = Color(0xFFBA1A1A)

val LightBackground = Color(0xFFFFFCF8)
val LightSurface = Color(0xFFFFFBFF)
val DarkBackground = Color(0xFF141218)
val DarkSurface = Color(0xFF1D1B20)

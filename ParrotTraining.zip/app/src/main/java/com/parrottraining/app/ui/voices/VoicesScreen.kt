package com.parrottraining.app.ui.voices

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.parrottraining.app.domain.AudioItem
import com.parrottraining.app.ui.TrainingViewModel

@Composable
fun VoicesScreen(viewModel: TrainingViewModel) {
    val data by viewModel.data.collectAsStateWithLifecycle()
    var pendingDelete by remember { mutableStateOf<AudioItem?>(null) }

    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.addAudio(it) }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("الأصوات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Button(onClick = { pickAudio.launch(arrayOf("audio/mpeg", "audio/mp3", "audio/wav", "audio/x-wav", "audio/*")) }) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Text(" إضافة صوت")
            }
        }

        if (data.audios.isEmpty()) {
            Text("لا توجد أصوات بعد. أضف ملف MP3 أو WAV لبدء بناء الخطة.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(data.audios, key = { it.id }) { audio ->
                    val available = remember(audio.uri) { viewModel.isAudioAvailable(audio) }
                    VoiceRow(
                        audio = audio,
                        available = available,
                        onPreview = { viewModel.previewAudio(audio.id) },
                        onMoveUp = { viewModel.moveAudioUp(audio.id) },
                        onMoveDown = { viewModel.moveAudioDown(audio.id) },
                        onDelete = { pendingDelete = audio }
                    )
                }
            }
        }
    }

    pendingDelete?.let { audio ->
        val used = viewModel.isAudioUsedInPlan(audio.id)
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("حذف الصوت؟") },
            text = {
                Text(
                    if (used) "هذا الصوت مستخدم في خطة التدريب الحالية. حذفه قد يؤثر على أحد الأسابيع. هل تريد المتابعة؟"
                    else "سيتم حذف \"${audio.name}\" نهائياً من قائمة الأصوات."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.removeAudio(audio.id)
                    pendingDelete = null
                }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun VoiceRow(
    audio: AudioItem,
    available: Boolean,
    onPreview: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDelete: () -> Unit
) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(audio.name, fontWeight = FontWeight.Bold)
            if (!available) {
                Text("تعذر الوصول إلى هذا الملف. قد يكون محذوفاً من الجهاز.", color = MaterialTheme.colorScheme.error)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = onPreview) { Icon(Icons.Filled.PlayArrow, contentDescription = "اختبار الصوت") }
                IconButton(onClick = onMoveUp) { Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "تحريك للأعلى") }
                IconButton(onClick = onMoveDown) { Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "تحريك للأسفل") }
                IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "حذف") }
            }
        }
    }
}

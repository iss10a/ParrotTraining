package com.parrottraining.app.util

import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

private val arabicLocale = Locale("ar")
private val dateFormatter = DateTimeFormatter.ofPattern("dd/MM", arabicLocale)
private val dateFormatterFull = DateTimeFormatter.ofPattern("dd/MM/yyyy", arabicLocale)

/** "6:00 صباحاً" / "6:00 مساءً" — 12-hour clock with an Arabic AM/PM label. */
private fun arabicClock(hour24: Int, minute: Int): String {
    val period = if (hour24 < 12) "صباحاً" else "مساءً"
    val h12 = when {
        hour24 % 12 == 0 -> 12
        else -> hour24 % 12
    }
    return "%d:%02d %s".format(Locale.US, h12, minute, period)
}

fun Int.toClockString(): String {
    val h = this / 60
    val m = this % 60
    return arabicClock(h, m)
}

fun Long.toEpochDayString(): String = LocalDate.ofEpochDay(this).format(dateFormatter)
fun Long.toEpochDayStringFull(): String = LocalDate.ofEpochDay(this).format(dateFormatterFull)

fun Long.toClockStringFromMillis(zone: ZoneId = ZoneId.systemDefault()): String {
    val t = java.time.Instant.ofEpochMilli(this).atZone(zone).toLocalTime()
    return arabicClock(t.hour, t.minute)
}

fun Long.toDateStringFromMillis(zone: ZoneId = ZoneId.systemDefault()): String =
    java.time.Instant.ofEpochMilli(this).atZone(zone).toLocalDate().format(dateFormatter)

fun Long.msToClock(): String {
    val totalSeconds = (this / 1000).coerceAtLeast(0)
    val m = totalSeconds / 60
    val s = totalSeconds % 60
    return String.format(Locale.US, "%02d:%02d", m, s)
}

fun dayNameArabic(epochDay: Long): String =
    LocalDate.ofEpochDay(epochDay).dayOfWeek.getDisplayName(TextStyle.FULL, arabicLocale)

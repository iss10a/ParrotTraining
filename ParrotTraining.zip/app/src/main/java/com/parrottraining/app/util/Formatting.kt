package com.parrottraining.app.util

import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

private val arabicLocale = Locale("ar")
private val dateFormatter = DateTimeFormatter.ofPattern("dd/MM", arabicLocale)
private val dateFormatterFull = DateTimeFormatter.ofPattern("dd/MM/yyyy", arabicLocale)

fun Int.toClockString(): String {
    val h = this / 60
    val m = this % 60
    return LocalTime.of(h, m).format(DateTimeFormatter.ofPattern("HH:mm"))
}

fun Long.toEpochDayString(): String = LocalDate.ofEpochDay(this).format(dateFormatter)
fun Long.toEpochDayStringFull(): String = LocalDate.ofEpochDay(this).format(dateFormatterFull)

fun Long.toClockStringFromMillis(zone: ZoneId = ZoneId.systemDefault()): String =
    java.time.Instant.ofEpochMilli(this).atZone(zone).toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))

fun Long.toDateStringFromMillis(zone: ZoneId = ZoneId.systemDefault()): String =
    java.time.Instant.ofEpochMilli(this).atZone(zone).toLocalDate().format(dateFormatter)

fun Long.msToClock(): String {
    val totalSeconds = (this / 1000).coerceAtLeast(0)
    val m = totalSeconds / 60
    val s = totalSeconds % 60
    return String.format(Locale.US, "%02d:%02d", m, s)
}

fun dayNameArabic(epochDay: Long): String =
    LocalDate.ofEpochDay(epochDay).dayOfWeek.getDisplayName(TextStyle.FULL, arabicLocale)

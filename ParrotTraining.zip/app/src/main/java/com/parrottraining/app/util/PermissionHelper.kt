package com.parrottraining.app.util

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat

/** Everything the app needs the phone's permission for, in the order it is asked. */
object PermissionHelper {

    enum class Step(val title: String, val why: String, val runtime: Boolean) {
        NOTIFICATIONS("الإشعارات", "لإشعار الجلسة وتنبيهك إذا صار خلل", true),
        CAMERA("الكاميرا", "لتصوير الجلسات بالكاميرا الأمامية", true),
        EXACT_ALARM("المنبّهات الدقيقة", "لتبدأ الجلسة في وقتها بالضبط", false),
        BATTERY("العمل في الخلفية", "لئلا يوقف النظام التطبيق لتوفير البطارية", false),
        FULL_SCREEN("فتح الشاشة فوق القفل", "ليفتح الفيديو والتصوير وقت الجلسة والجوال مقفل", false),
        OVERLAY("العرض فوق التطبيقات", "ليظهر الفيديو فوق أي تطبيق مفتوح", false)
    }

    fun isGranted(ctx: Context, step: Step): Boolean = when (step) {
        Step.NOTIFICATIONS ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else true
        Step.CAMERA ->
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        Step.EXACT_ALARM ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
            } else true
        Step.BATTERY ->
            (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
        Step.FULL_SCREEN ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).canUseFullScreenIntent()
            } else true
        Step.OVERLAY -> Settings.canDrawOverlays(ctx)
    }

    /** The permissions that are still missing, in asking order. */
    fun missing(ctx: Context): List<Step> = Step.values().filter { !isGranted(ctx, it) }

    private fun appDetails(ctx: Context): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:${ctx.packageName}"))

    /** Settings screens to try, best first, for the steps that are not a normal pop-up question. */
    fun settingsIntents(ctx: Context, step: Step): List<Intent> {
        val pkg = Uri.parse("package:${ctx.packageName}")
        return when (step) {
            Step.EXACT_ALARM -> listOf(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).setData(pkg), appDetails(ctx))
            Step.BATTERY -> listOf(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).setData(pkg),
                Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
                appDetails(ctx)
            )
            Step.FULL_SCREEN ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    listOf(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT).setData(pkg), appDetails(ctx))
                } else listOf(appDetails(ctx))
            Step.OVERLAY -> listOf(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).setData(pkg), appDetails(ctx))
            Step.NOTIFICATIONS -> listOf(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName),
                appDetails(ctx)
            )
            Step.CAMERA -> listOf(appDetails(ctx))
        }
    }

    /** Opens the first screen that works. Returns false when none could be opened. */
    fun open(ctx: Context, intents: List<Intent>): Boolean {
        for (intent in intents) {
            try {
                if (ctx !is android.app.Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                return true
            } catch (_: Exception) {
            }
        }
        return false
    }
}

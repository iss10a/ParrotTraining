package com.parrottraining.app.util

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import kotlinx.coroutines.delay

/** A [State] of `System.currentTimeMillis()` that refreshes every [intervalMs]. UI-only; never used for scheduling. */
@Composable
fun rememberNow(intervalMs: Long = 1000L): State<Long> {
    val state = remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(intervalMs) {
        while (true) {
            state.longValue = System.currentTimeMillis()
            delay(intervalMs)
        }
    }
    return state
}

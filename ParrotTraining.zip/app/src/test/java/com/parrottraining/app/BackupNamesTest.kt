package com.parrottraining.app

import com.parrottraining.app.data.BackupManager
import org.junit.Assert.assertEquals
import org.junit.Test

class BackupNamesTest {
    @Test
    fun `extension is kept for normal names and dropped for odd ones`() {
        assertEquals(".mp3", BackupManager.extensionOf("صباح الخير باسكو.mp3"))
        assertEquals(".mp4", BackupManager.extensionOf("clip.MP4"))
        assertEquals("", BackupManager.extensionOf("no extension"))
        assertEquals("", BackupManager.extensionOf("weird.ext/../x"))
    }
}

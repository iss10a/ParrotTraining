package com.parrottraining.app

import com.parrottraining.app.domain.LogAnalyzer
import com.parrottraining.app.domain.PhaseInfo
import com.parrottraining.app.domain.PhaseRow
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LogAnalyzerTest {

    private fun row(planned: Int, completed: Int, missed: Int = 0, index: Int = 0) = PhaseRow(
        phase = PhaseInfo(index, 0L, 7),
        audio = null,
        planned = planned,
        completed = completed,
        missed = missed,
        lastSessionMs = null,
        nextSessionMs = null,
        isCurrent = false
    )

    @Test
    fun `no planned sessions yields null instead of a misleading percentage`() {
        assertNull(LogAnalyzer.overallCompletionPercent(emptyList()))
        assertNull(LogAnalyzer.overallCompletionPercent(listOf(row(planned = 0, completed = 0))))
    }

    @Test
    fun `percentage is completed over planned across all weeks combined`() {
        val rows = listOf(row(planned = 14, completed = 13, index = 0), row(planned = 14, completed = 7, index = 1))
        // 20 completed out of 28 planned = 71%
        assertEquals(71, LogAnalyzer.overallCompletionPercent(rows))
    }

    @Test
    fun `percentage is clamped to 100 even if completed exceeds planned`() {
        val rows = listOf(row(planned = 10, completed = 15))
        assertEquals(100, LogAnalyzer.overallCompletionPercent(rows))
    }
}

package com.parrottraining.app

import com.parrottraining.app.domain.MotionAnalyzer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MotionAnalyzerTest {
    private val size = MotionAnalyzer.GRID_W * MotionAnalyzer.GRID_H

    private fun flat(v: Int) = IntArray(size) { v }

    /** A frame where [cells] cells (a small "bird") are much brighter than the background. */
    private fun withBird(start: Int, cells: Int) = flat(100).also { for (i in start until start + cells) it[i] = 220 }

    @Test
    fun `too few frames gives no score`() {
        val a = MotionAnalyzer()
        repeat(5) { a.addGrid(flat(100)) }
        assertNull(a.activityPercent())
    }

    @Test
    fun `still scene scores zero`() {
        val a = MotionAnalyzer()
        repeat(30) { a.addGrid(flat(100)) }
        assertEquals(0, a.activityPercent())
    }

    @Test
    fun `small moving bird scores high`() {
        val a = MotionAnalyzer()
        // The bird jumps to a new place every frame, so every frame differs from the one before.
        for (i in 0 until 30) a.addGrid(withBird(if (i % 2 == 0) 0 else 300, 12))
        assertEquals(100, a.activityPercent())
    }

    @Test
    fun `one movement then stillness scores low`() {
        val a = MotionAnalyzer()
        a.addGrid(flat(100))
        // Frame 1: the bird appears (active). The next 39 frames are identical (still): 1 active of 40.
        repeat(40) { a.addGrid(withBird(0, 12)) }
        assertEquals(2, a.activityPercent())
    }

    @Test
    fun `whole-picture lighting jump is ignored`() {
        val a = MotionAnalyzer()
        a.addGrid(flat(50))
        for (i in 0 until 30) a.addGrid(flat(if (i % 2 == 0) 150 else 50))
        assertNull(a.activityPercent()) // every frame ignored, so nothing valid to score
    }

    @Test
    fun `downsample averages the brightness plane`() {
        val a = MotionAnalyzer()
        val w = 64
        val h = 48
        val plane = java.nio.ByteBuffer.wrap(ByteArray(w * h) { 200.toByte() })
        val g = a.downsample(plane, w, h, w)
        assertEquals(size, g.size)
        assertEquals(true, g.all { it == 200 })
    }
}

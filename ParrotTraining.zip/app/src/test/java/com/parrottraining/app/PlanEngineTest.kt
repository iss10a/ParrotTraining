package com.parrottraining.app

import com.parrottraining.app.domain.AudioItem
import com.parrottraining.app.domain.PlanEngine
import com.parrottraining.app.domain.PlanPosition
import com.parrottraining.app.domain.PlanState
import com.parrottraining.app.domain.PlanStatus
import com.parrottraining.app.domain.Settings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId

/** Pure-logic tests for [PlanEngine]. No Android dependencies, so these run as plain JVM unit tests. */
class PlanEngineTest {

    private val zone: ZoneId = ZoneId.of("UTC")

    private fun audios(n: Int) = (1..n).map { AudioItem(id = "a$it", uri = "content://audio$it", name = "audio_0$it.mp3") }

    private fun day(offset: Long, base: Long = 0L) = base + offset

    // ------------------------------------------------------- current week

    @Test
    fun `week 1 uses the first audio for every day of the first phase`() {
        val a = audios(3)
        val plan = PlanState(status = PlanStatus.ACTIVE, startEpochDay = 100L)
        val settings = Settings(phaseDays = 7)

        for (d in 0..6) {
            val pos = PlanEngine.positionOn(100L + d, a, plan, settings) as PlanPosition.Active
            assertEquals("day $d should still be week 1", 0, pos.phaseIndex)
            assertEquals(a[0].id, pos.audio.id)
        }
    }

    @Test
    fun `one week equals one audio, never mixed within the same week`() {
        val a = audios(2)
        val plan = PlanState(status = PlanStatus.ACTIVE, startEpochDay = 0L)
        val settings = Settings(phaseDays = 7)

        val audioIdsInWeek1 = (0..6).map {
            (PlanEngine.positionOn(it.toLong(), a, plan, settings) as PlanPosition.Active).audio.id
        }.distinct()
        assertEquals(1, audioIdsInWeek1.size)
        assertEquals(a[0].id, audioIdsInWeek1.first())
    }

    // -------------------------------------------------- transition between weeks

    @Test
    fun `transitions to the next audio exactly on the first day of week 2`() {
        val a = audios(3)
        val plan = PlanState(status = PlanStatus.ACTIVE, startEpochDay = 0L)
        val settings = Settings(phaseDays = 7)

        val lastDayOfWeek1 = PlanEngine.positionOn(6L, a, plan, settings) as PlanPosition.Active
        val firstDayOfWeek2 = PlanEngine.positionOn(7L, a, plan, settings) as PlanPosition.Active

        assertEquals(0, lastDayOfWeek1.phaseIndex)
        assertEquals(a[0].id, lastDayOfWeek1.audio.id)
        assertEquals(1, firstDayOfWeek2.phaseIndex)
        assertEquals(a[1].id, firstDayOfWeek2.audio.id)
    }

    @Test
    fun `custom phase length of 10 days is respected`() {
        val a = audios(2)
        val plan = PlanState(status = PlanStatus.ACTIVE, startEpochDay = 0L)
        val settings = Settings(phaseDays = 10)

        val day9 = PlanEngine.positionOn(9L, a, plan, settings) as PlanPosition.Active
        val day10 = PlanEngine.positionOn(10L, a, plan, settings) as PlanPosition.Active
        assertEquals(0, day9.phaseIndex)
        assertEquals(1, day10.phaseIndex)
    }

    // ------------------------------------------------------ next session

    @Test
    fun `next session picks the nearest upcoming time slot`() {
        val a = audios(1)
        val plan = PlanState(status = PlanStatus.ACTIVE, startEpochDay = 0L)
        val settings = Settings(phaseDays = 7, timesOfDay = listOf(6 * 60, 18 * 60))

        // 10:00 on day 0 -> next slot should be 18:00 on day 0.
        val afterMs = PlanEngine.slotMillis(0L, 10 * 60, zone)
        val slot = PlanEngine.nextSession(afterMs, zone, a, plan, settings)!!
        assertEquals(0L, slot.epochDay)
        assertEquals(18 * 60, slot.minuteOfDay)
    }

    @Test
    fun `next session rolls over to the next day after the last daily slot`() {
        val a = audios(2)
        val plan = PlanState(status = PlanStatus.ACTIVE, startEpochDay = 0L)
        val settings = Settings(phaseDays = 7, timesOfDay = listOf(6 * 60, 18 * 60))

        val afterMs = PlanEngine.slotMillis(0L, 19 * 60, zone) // after 18:00 on day 0
        val slot = PlanEngine.nextSession(afterMs, zone, a, plan, settings)!!
        assertEquals(1L, slot.epochDay)
        assertEquals(6 * 60, slot.minuteOfDay)
    }

    // ----------------------------------------------------------- skip week

    @Test
    fun `skip current week ends today so the next phase starts today`() {
        val a = audios(3)
        var plan = PlanState(status = PlanStatus.ACTIVE, startEpochDay = 0L)
        val settings = Settings(phaseDays = 7)

        // Day 2 into week 1 (0-indexed): skip should end week 1 after day 2.
        plan = PlanEngine.skipCurrent(plan, a, settings, todayEpochDay = 2L)
        val posOnDay2 = PlanEngine.positionOn(2L, a, plan, settings)
        val posOnDay3 = PlanEngine.positionOn(3L, a, plan, settings) as PlanPosition.Active

        assertTrue(posOnDay2 is PlanPosition.Active)
        assertEquals(1, posOnDay3.phaseIndex) // already week 2
    }

    // --------------------------------------------------------- repeat week

    @Test
    fun `repeat current week extends the phase by one more full length`() {
        val a = audios(2)
        var plan = PlanState(status = PlanStatus.ACTIVE, startEpochDay = 0L)
        val settings = Settings(phaseDays = 7)

        plan = PlanEngine.repeatCurrent(plan, a, settings, todayEpochDay = 3L)
        // Week 1 should now last 14 days instead of 7.
        val day10 = PlanEngine.positionOn(10L, a, plan, settings) as PlanPosition.Active
        val day14 = PlanEngine.positionOn(14L, a, plan, settings) as PlanPosition.Active

        assertEquals(0, day10.phaseIndex) // still week 1 (extended)
        assertEquals(1, day14.phaseIndex) // week 2 now starts on day 14
    }

    // ------------------------------------------------------ pause / resume

    @Test
    fun `pause freezes the current day and resume shifts the start date forward`() {
        val a = audios(2)
        var plan = PlanState(status = PlanStatus.ACTIVE, startEpochDay = 0L)
        val settings = Settings(phaseDays = 7)

        plan = PlanEngine.pause(plan, todayEpochDay = 3L)
        assertEquals(PlanStatus.PAUSED, plan.status)
        assertEquals(3L, plan.pausedOnEpochDay)

        // Resuming 4 days later shifts the whole plan forward by 4 days, so day-in-phase is preserved.
        plan = PlanEngine.resume(plan, todayEpochDay = 7L, nowMs = 0L)
        assertEquals(PlanStatus.ACTIVE, plan.status)
        assertEquals(4L, plan.startEpochDay) // shifted by (7 - 3)

        val posAfterResume = PlanEngine.positionOn(7L, a, plan, settings) as PlanPosition.Active
        assertEquals(4, posAfterResume.dayInPhase) // same day-in-phase as when paused (day 3 = 4th day)
    }

    // -------------------------------------------------------- plan completion

    @Test
    fun `plan completes after the last week when auto-repeat is off`() {
        val a = audios(2)
        val plan = PlanState(status = PlanStatus.ACTIVE, startEpochDay = 0L)
        val settings = Settings(phaseDays = 7, autoRepeat = false)

        // 2 weeks * 7 days = 14 days total; day 14 is past the end.
        val pos = PlanEngine.positionOn(14L, a, plan, settings)
        assertTrue(pos is PlanPosition.Completed)
    }

    // -------------------------------------------------------------- auto repeat

    @Test
    fun `auto repeat restarts from the first audio after the plan completes`() {
        val a = audios(2)
        val plan = PlanState(status = PlanStatus.ACTIVE, startEpochDay = 0L)
        val settings = Settings(phaseDays = 7, autoRepeat = true)

        // Day 14 is the first day of the second cycle -> back to audio 1.
        val pos = PlanEngine.positionOn(14L, a, plan, settings) as PlanPosition.Active
        assertEquals(0, pos.phaseIndex)
        assertEquals(a[0].id, pos.audio.id)
        assertEquals(1L, pos.cycle)
    }

    @Test
    fun `plan not started before its start date`() {
        val a = audios(1)
        val plan = PlanState(status = PlanStatus.ACTIVE, startEpochDay = 10L)
        val settings = Settings(phaseDays = 7)
        val pos = PlanEngine.positionOn(5L, a, plan, settings)
        assertTrue(pos is PlanPosition.BeforeStart)
    }

    @Test
    fun `no audio yields NoAudio position even when the plan is active`() {
        val plan = PlanState(status = PlanStatus.ACTIVE, startEpochDay = 0L)
        val settings = Settings()
        val pos = PlanEngine.positionOn(0L, emptyList(), plan, settings)
        assertTrue(pos is PlanPosition.NoAudio)
    }
}

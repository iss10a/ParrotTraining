package com.parrottraining.app

import com.parrottraining.app.domain.RecorderMath
import org.junit.Assert.assertEquals
import org.junit.Test

class RecorderMathTest {

    @Test
    fun `orientation hint follows sensor and screen rotation`() {
        assertEquals(270, RecorderMath.orientationHint(270, 0))
        assertEquals(180, RecorderMath.orientationHint(270, 90))
        assertEquals(90, RecorderMath.orientationHint(90, 0))
        assertEquals(270, RecorderMath.orientationHint(90, 180))
    }

    @Test
    fun `picks the largest size that fits the quality`() {
        val sizes = listOf(1920 to 1080, 1280 to 720, 960 to 720, 720 to 480, 640 to 480, 320 to 240)
        assertEquals(720 to 480, RecorderMath.chooseSize(sizes, 480))
        assertEquals(1280 to 720, RecorderMath.chooseSize(sizes, 720))
    }

    @Test
    fun `falls back when nothing fits or nothing is reported`() {
        assertEquals(1280 to 720, RecorderMath.chooseSize(listOf(1920 to 1080, 1280 to 720), 480))
        assertEquals(640 to 480, RecorderMath.chooseSize(emptyList(), 480))
    }

    @Test
    fun `wide size keeps the sensor shape so the picture is not cropped`() {
        val sizes = listOf(1280 to 720, 640 to 480, 960 to 720, 1920 to 1080)
        // Sensor is 4:3: prefer 640x480 (480) / 960x720 (720) over the 16:9 sizes.
        assertEquals(640 to 480, RecorderMath.chooseWideSize(sizes, 480, 4000, 3000))
        assertEquals(960 to 720, RecorderMath.chooseWideSize(sizes, 720, 4000, 3000))
        // Unknown sensor size falls back to the normal choice.
        assertEquals(RecorderMath.chooseSize(sizes, 480), RecorderMath.chooseWideSize(sizes, 480, 0, 0))
    }

    @Test
    fun `shorter focal length means a wider view`() {
        val normal = RecorderMath.fieldOfViewDegrees(4.0f, 3.0f)
        val ultraWide = RecorderMath.fieldOfViewDegrees(4.0f, 1.5f)
        assertEquals(true, ultraWide > normal)
        assertEquals(90.0, RecorderMath.fieldOfViewDegrees(4.0f, 2.0f), 0.001)
    }
}

package com.parrottraining.app

import com.parrottraining.app.domain.RemoteMessages
import com.parrottraining.app.domain.SessionStatus
import com.parrottraining.app.domain.SessionType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random

class RemoteMessagesTest {

    @Test
    fun `start message names the parrot, the audio, the length and the week`() {
        val (title, body) = RemoteMessages.sessionStarted("كوكو", SessionType.SCHEDULED, false, listOf("صباح الخير"), 10 * 60_000L, 2)
        assertTrue(title.contains("كوكو"))
        assertEquals("صوت: صباح الخير • المدة 10 دقيقة • الأسبوع 3", body)
    }

    @Test
    fun `start message works without a parrot name and marks video and manual sessions`() {
        val (title, body) = RemoteMessages.sessionStarted("", SessionType.MANUAL, true, listOf("a", "b"), 12 * 60_000L, -1)
        assertEquals("🦜 بدأت جلسة التدريب", title)
        assertEquals("فيديو: a + b • المدة 12 دقيقة • تشغيل يدوي", body)
    }

    @Test
    fun `end message tells if the session finished or was stopped`() {
        assertTrue(RemoteMessages.sessionEnded("", SessionStatus.COMPLETED, 600_000L).first.startsWith("✅"))
        assertTrue(RemoteMessages.sessionEnded("", SessionStatus.STOPPED, 60_000L).first.startsWith("⏹"))
    }

    @Test
    fun `random topic is long, safe for ntfy and different each time`() {
        val rnd = Random(42)
        val a = RemoteMessages.randomTopic(rnd)
        val b = RemoteMessages.randomTopic(rnd)
        assertTrue(a.startsWith("parrot-") && a.length == 21)
        assertTrue(a.all { it in 'a'..'z' || it in '0'..'9' || it == '-' })
        assertTrue(a != b)
    }
}

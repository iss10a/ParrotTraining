package com.parrottraining.app

import com.parrottraining.app.domain.AudioItem
import com.parrottraining.app.domain.LogAnalyzer
import com.parrottraining.app.domain.PhaseInfo
import com.parrottraining.app.domain.PhaseRow
import com.parrottraining.app.domain.PlanState
import com.parrottraining.app.domain.PlanStatus
import com.parrottraining.app.domain.SessionReaction
import com.parrottraining.app.domain.SessionRecord
import com.parrottraining.app.domain.SessionStatus
import com.parrottraining.app.domain.SessionType
import com.parrottraining.app.domain.Settings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneOffset

class ReportTest {
    private val startDay = 100L
    private val dayMs = 86_400_000L

    private fun record(
        id: String,
        status: SessionStatus = SessionStatus.COMPLETED,
        activity: Int? = null,
        reaction: SessionReaction? = null,
        error: String? = null,
        dayOffset: Long = 0L,
        hourMs: Long = 3_600_000L
    ) = SessionRecord(
        id = id, type = SessionType.SCHEDULED, status = status,
        slotAtMs = (startDay + dayOffset) * dayMs + hourMs,
        startedAtMs = (startDay + dayOffset) * dayMs + hourMs,
        plannedMs = 600_000L, playedMs = 600_000L,
        audioId = "a1", audioName = "audio", phaseIndex = 0,
        errorMessage = error, activityPercent = activity, reaction = reaction
    )

    private fun rows(log: List<SessionRecord>): List<PhaseRow> = LogAnalyzer.rows(
        audios = listOf(AudioItem("a1", "content://x", "audio")),
        plan = PlanState(status = PlanStatus.ACTIVE, startEpochDay = startDay),
        settings = Settings(),
        log = log,
        zone = ZoneOffset.UTC,
        next = null,
        currentIndex = 0
    )

    @Test
    fun `week row counts the reactions of completed sessions only`() {
        val r = rows(
            listOf(
                record("1", reaction = SessionReaction.VOICE),
                record("2", reaction = SessionReaction.VOICE, dayOffset = 1),
                record("3", reaction = SessionReaction.MIMIC, dayOffset = 2),
                record("4", reaction = SessionReaction.NONE, dayOffset = 3),
                // a failed session with a note must not be counted
                record("5", status = SessionStatus.FAILED, reaction = SessionReaction.VOICE, dayOffset = 4)
            )
        ).single()
        assertEquals(2, r.voiceCount)
        assertEquals(1, r.mimicCount)
        assertEquals(1, r.noneCount)
        assertTrue(r.hasReport)
    }

    @Test
    fun `week row averages activity and reports the latest error`() {
        val r = rows(
            listOf(
                record("1", activity = 20),
                record("2", activity = 40, dayOffset = 1),
                record("3", status = SessionStatus.FAILED, error = "old error", dayOffset = 2),
                record("4", status = SessionStatus.FAILED, error = "new error", dayOffset = 3)
            )
        ).single()
        assertEquals(30, r.avgActivityPercent)
        assertEquals("new error", r.lastError)
    }

    @Test
    fun `week without notes or camera has no report`() {
        val r = rows(listOf(record("1"))).single()
        assertNull(r.avgActivityPercent)
        assertEquals(false, r.hasReport)
        assertNull(r.lastError)
    }

    private fun row(index: Int, activity: Int?) = PhaseRow(
        phase = PhaseInfo(index, 0L, 7), audio = null, planned = 0, completed = 0, missed = 0,
        lastSessionMs = null, nextSessionMs = null, isCurrent = false, avgActivityPercent = activity
    )

    @Test
    fun `most active week is the highest average`() {
        val best = LogAnalyzer.mostActiveRow(listOf(row(0, 10), row(1, 55), row(2, null), row(3, 30)))
        assertEquals(1, best?.phase?.index)
        assertNull(LogAnalyzer.mostActiveRow(listOf(row(0, null))))
    }
}

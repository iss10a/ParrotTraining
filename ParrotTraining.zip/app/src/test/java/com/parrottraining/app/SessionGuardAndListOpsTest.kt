package com.parrottraining.app

import com.parrottraining.app.domain.AudioItem
import com.parrottraining.app.domain.SessionGuard
import com.parrottraining.app.domain.SessionType
import com.parrottraining.app.domain.movedBy
import org.junit.Assert.assertEquals
import org.junit.Test

/** Two sessions must never play at the same time; a preview must never interrupt real training. */
class SessionGuardTest {

    @Test
    fun `starts immediately when nothing is currently playing`() {
        assertEquals(SessionGuard.Decision.START, SessionGuard.onNewSession(null, SessionType.SCHEDULED))
    }

    @Test
    fun `a new scheduled session replaces whatever is currently playing, preventing overlap`() {
        assertEquals(
            SessionGuard.Decision.REPLACE_CURRENT,
            SessionGuard.onNewSession(SessionType.MANUAL, SessionType.SCHEDULED)
        )
        assertEquals(
            SessionGuard.Decision.REPLACE_CURRENT,
            SessionGuard.onNewSession(SessionType.SCHEDULED, SessionType.SCHEDULED)
        )
    }

    @Test
    fun `a preview never interrupts a real training session`() {
        assertEquals(
            SessionGuard.Decision.REJECT_INCOMING,
            SessionGuard.onNewSession(SessionType.SCHEDULED, SessionType.PREVIEW)
        )
        assertEquals(
            SessionGuard.Decision.REJECT_INCOMING,
            SessionGuard.onNewSession(SessionType.MANUAL, SessionType.PREVIEW)
        )
    }

    @Test
    fun `a new preview replaces an old preview`() {
        assertEquals(
            SessionGuard.Decision.REPLACE_CURRENT,
            SessionGuard.onNewSession(SessionType.PREVIEW, SessionType.PREVIEW)
        )
    }
}

/** Reordering audios (move up / move down) must be stable and safe at the list boundaries. */
class ListOpsTest {

    private fun items() = listOf(
        AudioItem("1", "uri1", "one"),
        AudioItem("2", "uri2", "two"),
        AudioItem("3", "uri3", "three")
    )

    @Test
    fun `moving an item down swaps it with its neighbor`() {
        val result = items().movedBy({ it.id }, "1", +1)
        assertEquals(listOf("2", "1", "3"), result.map { it.id })
    }

    @Test
    fun `moving an item up swaps it with its neighbor`() {
        val result = items().movedBy({ it.id }, "3", -1)
        assertEquals(listOf("1", "3", "2"), result.map { it.id })
    }

    @Test
    fun `moving the first item up is a no-op`() {
        val result = items().movedBy({ it.id }, "1", -1)
        assertEquals(listOf("1", "2", "3"), result.map { it.id })
    }

    @Test
    fun `moving the last item down is a no-op`() {
        val result = items().movedBy({ it.id }, "3", +1)
        assertEquals(listOf("1", "2", "3"), result.map { it.id })
    }
}

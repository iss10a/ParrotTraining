package com.parrottraining.app

import com.parrottraining.app.domain.AdviceBasis
import com.parrottraining.app.domain.SessionReaction
import com.parrottraining.app.domain.SessionRecord
import com.parrottraining.app.domain.SessionStatus
import com.parrottraining.app.domain.SessionType
import com.parrottraining.app.domain.TimeAdvisor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.ZoneOffset

class TimeAdvisorTest {
    private val dayMs = 86_400_000L
    private var n = 0

    /** A finished scheduled session on [day] at [minute] minutes after midnight (UTC). */
    private fun session(day: Long, minute: Int, activity: Int? = null, reaction: SessionReaction? = null): SessionRecord {
        val at = (100 + day) * dayMs + minute * 60_000L
        return SessionRecord(
            id = "s${n++}", type = SessionType.SCHEDULED, status = SessionStatus.COMPLETED,
            slotAtMs = at, startedAtMs = at, plannedMs = 600_000L, playedMs = 600_000L,
            audioId = "a", audioName = "a", phaseIndex = 0, activityPercent = activity, reaction = reaction
        )
    }

    private fun analyze(log: List<SessionRecord>) = TimeAdvisor.analyze(log, ZoneOffset.UTC)

    @Test
    fun `picks the slot with the higher activity when both have enough sessions`() {
        val log = (0L until 3L).flatMap { d -> listOf(session(d, 360, activity = 20), session(d, 1080, activity = 50)) }
        val advice = analyze(log)
        assertEquals(1080, advice.best?.minuteOfDay)
        assertEquals(AdviceBasis.ACTIVITY, advice.basis)
        assertEquals(2, advice.slots.size)
        assertEquals(20, advice.slots.first().avgActivityPercent)
    }

    @Test
    fun `no advice when a slot has too few sessions`() {
        val log = listOf(
            session(0, 360, activity = 20), session(1, 360, activity = 20), session(2, 360, activity = 20),
            session(0, 1080, activity = 60)
        )
        assertNull(analyze(log).best)
    }

    @Test
    fun `no advice when the slots are almost the same`() {
        val log = (0L until 3L).flatMap { d -> listOf(session(d, 360, activity = 40), session(d, 1080, activity = 42)) }
        assertNull(analyze(log).best)
    }

    @Test
    fun `falls back to the reaction notes when there is no camera data`() {
        val log = (0L until 4L).flatMap { d ->
            listOf(
                session(d, 360, reaction = SessionReaction.NONE),
                session(d, 1080, reaction = SessionReaction.VOICE)
            )
        }
        val advice = analyze(log)
        assertEquals(1080, advice.best?.minuteOfDay)
        assertEquals(AdviceBasis.RESPONSE, advice.basis)
        assertEquals(100, advice.best?.responsePercent)
    }

    @Test
    fun `manual and failed sessions are ignored`() {
        val manual = session(0, 360, activity = 90).copy(type = SessionType.MANUAL, slotAtMs = 0L)
        val failed = session(0, 360, activity = 90).copy(status = SessionStatus.FAILED)
        assertEquals(0, analyze(listOf(manual, failed)).slots.size)
    }
}
